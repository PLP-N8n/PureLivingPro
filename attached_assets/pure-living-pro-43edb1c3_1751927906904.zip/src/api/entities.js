import { base44 } from './base44Client';


export const BlogPost = base44.entities.BlogPost;

export const WellnessPick = base44.entities.WellnessPick;

export const Comment = base44.entities.Comment;

export const Challenge = base44.entities.Challenge;

export const ChallengeTask = base44.entities.ChallengeTask;

export const UserChallengeProgress = base44.entities.UserChallengeProgress;

export const DailyWellnessLog = base44.entities.DailyWellnessLog;



// auth sdk:
export const User = base44.auth;