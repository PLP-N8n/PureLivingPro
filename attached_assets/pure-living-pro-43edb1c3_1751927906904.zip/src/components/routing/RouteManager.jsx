import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

// Import all pages with correct file extensions
import Home from '@/pages/Home.js';
import Blog from '@/pages/Blog.js';
import BlogPost from '@/pages/BlogPost.js';
import WellnessPicks from '@/pages/WellnessPicks.js';
import About from '@/pages/About.js';
import Contact from '@/pages/Contact.js';
import Premium from '@/pages/Premium.js';
import Challenges from '@/pages/Challenges.js';
import ChallengeDetail from '@/pages/ChallengeDetail.js';
import Dashboard from '@/pages/Dashboard.js';
import WellnessPlan from '@/pages/WellnessPlan.js';
import WellnessQuiz from '@/pages/WellnessQuiz.js';
import MealPlanner from '@/pages/MealPlanner.js';
import MeditationTimer from '@/pages/MeditationTimer.js';
import Admin from '@/pages/Admin.js';

// Protected route wrapper for admin pages
import { useAuth } from '@/components/contexts/AuthContext';

function ProtectedRoute({ children, adminOnly = false }) {
  const { isAuthenticated, user } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  if (adminOnly && user?.role !== 'admin') {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
}

export default function RouteManager() {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<Home />} />
      <Route path="/home" element={<Navigate to="/" replace />} />
      
      {/* Blog Routes */}
      <Route path="/blog" element={<Blog />} />
      <Route path="/blog/:slug" element={<BlogPost />} />
      <Route path="/insights" element={<Navigate to="/blog" replace />} />
      
      {/* Product Routes */}
      <Route path="/wellness-picks" element={<WellnessPicks />} />
      <Route path="/wellnesspicks" element={<Navigate to="/wellness-picks" replace />} />
      <Route path="/our-picks" element={<Navigate to="/wellness-picks" replace />} />
      
      {/* Information Pages */}
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      
      {/* Premium & Membership */}
      <Route path="/premium" element={<Premium />} />
      <Route path="/wellness-quiz" element={<WellnessQuiz />} />
      
      {/* Challenges */}
      <Route path="/challenges" element={<Challenges />} />
      <Route path="/challenges/:id" element={<ChallengeDetail />} />
      
      {/* Protected User Routes */}
      <Route 
        path="/dashboard" 
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/my-hub" 
        element={
          <ProtectedRoute>
            <Navigate to="/dashboard" replace />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/wellness-plan" 
        element={
          <ProtectedRoute>
            <WellnessPlan />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/my-plan" 
        element={
          <ProtectedRoute>
            <Navigate to="/wellness-plan" replace />
          </ProtectedRoute>
        } 
      />
      
      {/* Tools & Features */}
      <Route 
        path="/meal-planner" 
        element={
          <ProtectedRoute>
            <MealPlanner />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/meditation-timer" 
        element={<MeditationTimer />} 
      />
      <Route 
        path="/meditation" 
        element={<Navigate to="/meditation-timer" replace />} 
      />
      
      {/* Admin Routes */}
      <Route 
        path="/admin" 
        element={
          <ProtectedRoute adminOnly>
            <Admin />
          </ProtectedRoute>
        } 
      />
      
      {/* Legacy route redirects */}
      <Route path="/BlogPost/:slug" element={<Navigate to="/blog/:slug" replace />} />
      <Route path="/ChallengeDetail/:id" element={<Navigate to="/challenges/:id" replace />} />
      
      {/* 404 - Redirect to home */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}