import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Database, 
  Trash2, 
  RefreshCw, 
  Info,
  Clock,
  HardDrive
} from "lucide-react";
import { enhancedBase44Client } from "../api/EnhancedBase44Client";

export default function CacheManagerUI({ isVisible = true }) {
  const [cacheStats, setCacheStats] = useState(null);
  const [isClearing, setIsClearing] = useState(false);

  useEffect(() => {
    if (isVisible) {
      loadCacheStats();
      const interval = setInterval(loadCacheStats, 5000);
      return () => clearInterval(interval);
    }
  }, [isVisible]);

  const loadCacheStats = () => {
    try {
      const stats = enhancedBase44Client.getCacheStats();
      setCacheStats(stats);
    } catch (error) {
      console.error('Failed to load cache stats:', error);
    }
  };

  const clearCache = async () => {
    setIsClearing(true);
    try {
      enhancedBase44Client.clearCache();
      loadCacheStats();
    } catch (error) {
      console.error('Failed to clear cache:', error);
    } finally {
      setIsClearing(false);
    }
  };

  const clearExpiredCache = async () => {
    setIsClearing(true);
    try {
      // Clear only expired entries
      const stats = enhancedBase44Client.getCacheStats();
      const now = Date.now();
      
      stats.entries.forEach(entry => {
        if (now - entry.age > entry.ttl) {
          // This would need to be implemented in the client
          // enhancedBase44Client.deleteCacheEntry(entry.key);
        }
      });
      
      loadCacheStats();
    } catch (error) {
      console.error('Failed to clear expired cache:', error);
    } finally {
      setIsClearing(false);
    }
  };

  if (!isVisible || !cacheStats) return null;

  const usagePercentage = (cacheStats.size / cacheStats.maxSize) * 100;
  const expiredCount = cacheStats.entries.filter(entry => {
    const now = Date.now();
    return now - entry.age > entry.ttl;
  }).length;

  return (
    <Card className="bg-white/95 backdrop-blur-sm border-sage-200 shadow-lg">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center justify-between">
          <div className="flex items-center">
            <Database className="w-4 h-4 mr-2 text-sage-600" />
            Cache Manager
          </div>
          <Badge className={`text-xs ${cacheStats.enabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
            {cacheStats.enabled ? 'Enabled' : 'Disabled'}
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-3">
        {/* Cache Usage */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs font-semibold">Cache Usage</span>
            <span className="text-xs text-muted-foreground">
              {cacheStats.size}/{cacheStats.maxSize}
            </span>
          </div>
          <Progress value={usagePercentage} className="h-2" />
          <div className="text-xs text-muted-foreground">
            {Math.round(usagePercentage)}% full
          </div>
        </div>

        {/* Cache Statistics */}
        <div className="grid grid-cols-2 gap-2">
          <div className="text-center p-2 bg-sage-50 rounded">
            <div className="flex items-center justify-center mb-1">
              <HardDrive className="w-3 h-3 mr-1 text-sage-600" />
            </div>
            <div className="text-xs font-semibold">{cacheStats.entries.length}</div>
            <div className="text-xs text-sage-600">Entries</div>
          </div>
          <div className="text-center p-2 bg-amber-50 rounded">
            <div className="flex items-center justify-center mb-1">
              <Clock className="w-3 h-3 mr-1 text-amber-600" />
            </div>
            <div className="text-xs font-semibold">{expiredCount}</div>
            <div className="text-xs text-amber-600">Expired</div>
          </div>
        </div>

        {/* Recent Cache Entries */}
        <div className="space-y-1">
          <div className="text-xs font-semibold">Recent Entries</div>
          <div className="max-h-24 overflow-y-auto space-y-1">
            {cacheStats.entries.slice(0, 3).map((entry, index) => {
              const isExpired = Date.now() - entry.age > entry.ttl;
              return (
                <div key={index} className={`text-xs p-1 rounded ${isExpired ? 'bg-red-50 text-red-700' : 'bg-gray-50'}`}>
                  <div className="font-semibold truncate">{entry.key}</div>
                  <div className="text-gray-500">
                    Age: {Math.round(entry.age / 1000)}s | TTL: {Math.round(entry.ttl / 1000)}s
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Controls */}
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={clearExpiredCache}
            disabled={isClearing || expiredCount === 0}
            className="text-xs flex-1"
          >
            <Clock className="w-3 h-3 mr-1" />
            Clear Expired
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={clearCache}
            disabled={isClearing}
            className="text-xs"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={loadCacheStats}
            className="text-xs"
          >
            <RefreshCw className="w-3 h-3" />
          </Button>
        </div>

        {/* Cache Health Indicator */}
        <div className="flex items-center justify-center pt-2 border-t">
          <div className={`flex items-center text-xs ${
            usagePercentage > 90 ? 'text-red-600' :
            usagePercentage > 70 ? 'text-yellow-600' : 'text-green-600'
          }`}>
            <Info className="w-3 h-3 mr-1" />
            <span>
              {usagePercentage > 90 ? 'Cache Nearly Full' :
               usagePercentage > 70 ? 'Cache Getting Full' : 'Cache Healthy'}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}