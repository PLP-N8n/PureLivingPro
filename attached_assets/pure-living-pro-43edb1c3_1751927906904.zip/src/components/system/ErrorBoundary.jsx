import React from 'react';
import { AlertTriangle, RefreshCw, Home, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      hasError: false, 
      error: null,
      errorInfo: null,
      errorId: null
    };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI
    return { 
      hasError: true,
      errorId: Date.now().toString(36) + Math.random().toString(36).substr(2)
    };
  }

  componentDidCatch(error, errorInfo) {
    // Log error details
    this.setState({
      error: error,
      errorInfo: errorInfo
    });

    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.error('ErrorBoundary caught an error:', error, errorInfo);
    }

    // In production, you might want to log to an error reporting service
    // Example: logErrorToService(error, errorInfo);
  }

  handleRetry = () => {
    this.setState({ 
      hasError: false, 
      error: null, 
      errorInfo: null,
      errorId: null 
    });
  };

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      const isDevelopment = process.env.NODE_ENV === 'development';
      
      return (
        <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
          <Card className="max-w-2xl w-full shadow-2xl border-red-200">
            <CardHeader className="text-center pb-6">
              <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="w-10 h-10 text-red-600" />
              </div>
              <CardTitle className="text-2xl font-bold text-red-800 mb-2">
                Oops! Something went wrong
              </CardTitle>
              <p className="text-red-600">
                We encountered an unexpected error. Don't worry, our team has been notified.
              </p>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Error ID for support */}
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-red-800">Error ID:</span>
                  <Badge variant="outline" className="border-red-300 text-red-700 font-mono">
                    {this.state.errorId}
                  </Badge>
                </div>
                <p className="text-xs text-red-600 mt-2">
                  Please include this ID when contacting support
                </p>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  onClick={this.handleRetry}
                  className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
                <Button 
                  onClick={this.handleReload}
                  variant="outline"
                  className="flex-1 border-red-300 text-red-700 hover:bg-red-50"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reload Page
                </Button>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  onClick={() => window.location.href = '/'}
                  variant="outline"
                  className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Go Home
                </Button>
                <Button 
                  onClick={() => window.location.href = '/contact'}
                  variant="outline"
                  className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Contact Support
                </Button>
              </div>

              {/* Development error details */}
              {isDevelopment && this.state.error && (
                <details className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <summary className="font-medium text-gray-800 cursor-pointer hover:text-gray-600">
                    🔧 Development Error Details (Click to expand)
                  </summary>
                  <div className="mt-4 space-y-3">
                    <div>
                      <h4 className="font-semibold text-gray-800">Error:</h4>
                      <pre className="text-sm text-red-600 bg-red-50 p-2 rounded border overflow-x-auto">
                        {this.state.error.toString()}
                      </pre>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800">Stack Trace:</h4>
                      <pre className="text-xs text-gray-600 bg-gray-100 p-2 rounded border overflow-x-auto max-h-64">
                        {this.state.errorInfo.componentStack}
                      </pre>
                    </div>
                  </div>
                </details>
              )}

              {/* Help text */}
              <div className="text-center text-sm text-gray-600 pt-4 border-t border-gray-200">
                <p>
                  If this problem persists, please{' '}
                  <a href="/contact" className="text-red-600 hover:text-red-700 underline">
                    contact our support team
                  </a>{' '}
                  with the error ID above.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;