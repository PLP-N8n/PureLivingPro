import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Activity, 
  Wifi, 
  Server, 
  Database,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Settings
} from "lucide-react";

import PerformanceMonitor from "./PerformanceMonitor";
import CacheManagerUI from "./CacheManager";
import TestRunner from "./TestRunner";
import ErrorBoundary from "./ErrorBoundary";

class SystemHealthMonitor {
  constructor() {
    this.checks = [];
    this.status = 'unknown';
    this.lastCheck = null;
  }

  addHealthCheck(name, checkFunction, critical = false) {
    this.checks.push({
      name,
      checkFunction,
      critical,
      id: Date.now() + Math.random()
    });
  }

  async runHealthChecks() {
    const results = [];
    let criticalFailures = 0;
    let warnings = 0;

    for (const check of this.checks) {
      const startTime = performance.now();
      let result = {
        name: check.name,
        status: 'checking',
        critical: check.critical,
        duration: 0,
        message: '',
        timestamp: new Date()
      };

      try {
        const checkResult = await check.checkFunction();
        result.status = checkResult === true || checkResult?.status === 'ok' ? 'healthy' : 'warning';
        result.message = typeof checkResult === 'string' ? checkResult : checkResult?.message || '';
        
        if (result.status === 'warning') warnings++;
      } catch (error) {
        result.status = 'error';
        result.message = error.message;
        if (check.critical) criticalFailures++;
      }

      result.duration = performance.now() - startTime;
      results.push(result);
    }

    if (criticalFailures > 0) {
      this.status = 'critical';
    } else if (warnings > 0) {
      this.status = 'warning';
    } else {
      this.status = 'healthy';
    }

    this.lastCheck = new Date();
    return results;
  }

  getSystemInfo() {
    return {
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      language: navigator.language,
      cookieEnabled: navigator.cookieEnabled,
      onLine: navigator.onLine,
      memory: performance.memory ? {
        used: Math.round(performance.memory.usedJSHeapSize / 1024 / 1024),
        total: Math.round(performance.memory.totalJSHeapSize / 1024 / 1024),
        limit: Math.round(performance.memory.jsHeapSizeLimit / 1024 / 1024)
      } : null,
      connection: navigator.connection ? {
        effectiveType: navigator.connection.effectiveType,
        downlink: navigator.connection.downlink,
        rtt: navigator.connection.rtt
      } : null
    };
  }
}

const initializeHealthChecks = (monitor) => {
  monitor.addHealthCheck('Network Connectivity', async () => {
    if (!navigator.onLine) throw new Error('No network connection');
    return 'Network connection active';
  }, true);

  monitor.addHealthCheck('Local Storage', async () => {
    try {
      localStorage.setItem('health_check', 'test');
      localStorage.removeItem('health_check');
      return 'Local storage working';
    } catch (error) {
      throw new Error('Local storage not available');
    }
  }, true);

  monitor.addHealthCheck('Performance Metrics', () => {
    if (!window.performanceTracker) return 'Performance tracker not initialized';
    const metrics = window.performanceTracker.getMetrics();
    if (metrics.errors.length > 5) return 'High error count detected';
    return 'Performance metrics healthy';
  });

  monitor.addHealthCheck('Cache System', () => {
    if (!window.cacheManager) return 'Cache manager not initialized';
    const stats = window.cacheManager.getStats();
    if (stats.expiredCount > 10) return 'Many expired cache items';
    return 'Cache system healthy';
  });

  monitor.addHealthCheck('Memory Usage', () => {
    if (!performance.memory) return 'Memory info not available';
    const usage = performance.memory.usedJSHeapSize / performance.memory.jsHeapSizeLimit;
    if (usage > 0.8) return 'High memory usage detected';
    return `Memory usage: ${Math.round(usage * 100)}%`;
  });
};

window.healthMonitor = window.healthMonitor || (() => {
  const monitor = new SystemHealthMonitor();
  initializeHealthChecks(monitor);
  return monitor;
})();

export default function SystemStatus({ isVisible = false }) {
  const [healthResults, setHealthResults] = useState([]);
  const [systemInfo, setSystemInfo] = useState({});
  const [overallStatus, setOverallStatus] = useState('unknown');
  const [isChecking, setIsChecking] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [showTools, setShowTools] = useState(false);

  useEffect(() => {
    if (isVisible) {
      setSystemInfo(window.healthMonitor.getSystemInfo());
      runHealthCheck();
      const interval = setInterval(runHealthCheck, 30000);
      return () => clearInterval(interval);
    }
  }, [isVisible]);

  const runHealthCheck = async () => {
    setIsChecking(true);
    try {
      const results = await window.healthMonitor.runHealthChecks();
      setHealthResults(results);
      setOverallStatus(window.healthMonitor.status);
    } catch (error) {
      console.error('Health check failed:', error);
    } finally {
      setIsChecking(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'healthy': return 'text-green-600 bg-green-50 border-green-200';
      case 'warning': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'error': return 'text-red-600 bg-red-50 border-red-200';
      case 'critical': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'healthy': return <CheckCircle2 className="w-4 h-4" />;
      case 'warning': return <AlertTriangle className="w-4 h-4" />;
      case 'error': 
      case 'critical': return <AlertTriangle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  if (!isVisible) return null;

  return (
    <ErrorBoundary>
      <div className="fixed top-4 left-4 z-50 max-w-md">
        <Card className="bg-white/95 backdrop-blur-sm border-sage-200 shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center justify-between">
              <div className="flex items-center">
                <Activity className="w-4 h-4 mr-2 text-sage-600" />
                System Status
              </div>
              <div className="flex items-center gap-2">
                <Badge className={`text-xs ${getStatusColor(overallStatus)}`}>
                  {getStatusIcon(overallStatus)}
                  <span className="ml-1 capitalize">{isChecking ? 'Checking' : overallStatus}</span>
                </Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowTools(!showTools)}
                  className="p-1 h-6 w-6"
                >
                  <Settings className="w-3 h-3" />
                </Button>
              </div>
            </CardTitle>
          </CardHeader>

          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="text-center p-2 bg-sage-50 rounded">
                <div className="flex items-center justify-center mb-1">
                  <Wifi className="w-3 h-3 mr-1 text-sage-600" />
                </div>
                <div className="text-xs font-semibold">{navigator.onLine ? 'Online' : 'Offline'}</div>
                <div className="text-xs text-sage-600">Connection</div>
              </div>
              <div className="text-center p-2 bg-sage-50 rounded">
                <div className="flex items-center justify-center mb-1">
                  <Database className="w-3 h-3 mr-1 text-sage-600" />
                </div>
                <div className="text-xs font-semibold">
                  {systemInfo.memory ? `${systemInfo.memory.used}MB` : 'N/A'}
                </div>
                <div className="text-xs text-sage-600">Memory</div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold">Health Checks</div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowDetails(!showDetails)}
                  className="text-xs p-1 h-5"
                >
                  {showDetails ? 'Hide' : 'Show'} Details
                </Button>
              </div>
              
              {showDetails && (
                <div className="space-y-1 max-h-32 overflow-y-auto">
                  {healthResults.map((result, index) => (
                    <div key={index} className="text-xs flex items-center justify-between p-1 rounded bg-gray-50">
                      <div className="flex items-center">
                        {getStatusIcon(result.status)}
                        <span className="ml-1 truncate">{result.name}</span>
                      </div>
                      <span className="text-sage-600">{result.duration.toFixed(0)}ms</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <Button 
                size="sm" 
                variant="outline" 
                onClick={runHealthCheck}
                disabled={isChecking}
                className="text-xs flex-1"
              >
                {isChecking ? 'Checking...' : 'Refresh'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {showTools && (
          <div className="mt-2 space-y-2">
            <PerformanceMonitor isVisible={true} />
            <CacheManagerUI isVisible={true} />
            <TestRunner isVisible={true} />
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
}