import React from 'react';
import { Loader2, Heart, BookOpen, Star, Clock } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

// Global loading overlay
export function GlobalLoading({ message = "Loading..." }) {
  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <div className="bg-card p-8 rounded-2xl shadow-2xl border border-border">
        <div className="flex flex-col items-center space-y-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-foreground font-medium">{message}</p>
        </div>
      </div>
    </div>
  );
}

// Inline loading spinner
export function InlineLoading({ size = "md", message }) {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-6 h-6", 
    lg: "w-8 h-8"
  };

  return (
    <div className="flex items-center justify-center space-x-2 py-4">
      <Loader2 className={`${sizeClasses[size]} animate-spin text-primary`} />
      {message && <span className="text-muted-foreground">{message}</span>}
    </div>
  );
}

// Blog card skeleton
export function BlogCardSkeleton() {
  return (
    <Card className="shadow-lg border-0 bg-card rounded-2xl overflow-hidden h-full">
      <CardContent className="p-0 h-full flex flex-col">
        <Skeleton className="h-48 w-full" />
        <div className="p-6 flex-1 flex flex-col space-y-4">
          <Skeleton className="h-6 w-3/4" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-2/3" />
          <div className="flex justify-between items-center pt-4 border-t border-border">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-4 w-16" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Product card skeleton
export function ProductCardSkeleton() {
  return (
    <Card className="shadow-lg border-0 bg-card rounded-2xl overflow-hidden h-full">
      <CardContent className="p-0 h-full flex flex-col">
        <Skeleton className="h-48 w-full" />
        <div className="p-6 flex-1 flex flex-col space-y-4">
          <Skeleton className="h-6 w-2/3" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
          <div className="flex justify-between items-center pt-4">
            <Skeleton className="h-6 w-16" />
            <div className="flex space-x-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-4 w-4 rounded-full" />
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Challenge card skeleton
export function ChallengeCardSkeleton() {
  return (
    <Card className="shadow-lg border-0 bg-card rounded-2xl overflow-hidden h-full">
      <CardContent className="p-0 h-full flex flex-col">
        <Skeleton className="h-40 w-full" />
        <div className="p-6 flex-1 flex flex-col space-y-4">
          <div className="flex items-center space-x-2">
            <Skeleton className="h-6 w-20" />
            <Skeleton className="h-6 w-16" />
          </div>
          <Skeleton className="h-6 w-3/4" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-2/3" />
          <div className="flex justify-between items-center pt-4">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-8 w-20" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// List item skeleton
export function ListItemSkeleton() {
  return (
    <div className="flex items-center space-x-4 p-4 border-b border-border">
      <Skeleton className="h-12 w-12 rounded-full" />
      <div className="flex-1 space-y-2">
        <Skeleton className="h-4 w-2/3" />
        <Skeleton className="h-3 w-1/2" />
      </div>
      <Skeleton className="h-8 w-20" />
    </div>
  );
}

// Dashboard widget skeleton
export function DashboardWidgetSkeleton() {
  return (
    <Card className="shadow-lg border-0 bg-card rounded-2xl">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <Skeleton className="h-5 w-24" />
          <Skeleton className="h-8 w-8 rounded-full" />
        </div>
        <Skeleton className="h-8 w-16 mb-2" />
        <Skeleton className="h-4 w-32" />
      </CardContent>
    </Card>
  );
}

// Form skeleton
export function FormSkeleton({ fields = 3 }) {
  return (
    <div className="space-y-6">
      {Array.from({ length: fields }).map((_, i) => (
        <div key={i} className="space-y-2">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-10 w-full" />
        </div>
      ))}
      <div className="flex space-x-4">
        <Skeleton className="h-10 w-24" />
        <Skeleton className="h-10 w-20" />
      </div>
    </div>
  );
}

// Table skeleton
export function TableSkeleton({ rows = 5, columns = 4 }) {
  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex space-x-4 p-4 border-b border-border">
        {Array.from({ length: columns }).map((_, i) => (
          <Skeleton key={i} className="h-4 flex-1" />
        ))}
      </div>
      
      {/* Rows */}
      {Array.from({ length: rows }).map((_, rowIndex) => (
        <div key={rowIndex} className="flex space-x-4 p-4 border-b border-border">
          {Array.from({ length: columns }).map((_, colIndex) => (
            <Skeleton key={colIndex} className="h-4 flex-1" />
          ))}
        </div>
      ))}
    </div>
  );
}

// Loading grid
export function LoadingGrid({ type = "blog", count = 9 }) {
  const SkeletonComponent = {
    blog: BlogCardSkeleton,
    product: ProductCardSkeleton,
    challenge: ChallengeCardSkeleton,
    widget: DashboardWidgetSkeleton,
    list: ListItemSkeleton
  }[type] || BlogCardSkeleton;

  if (type === 'list') {
    return (
      <div className="space-y-0">
        {Array.from({ length: count }).map((_, i) => (
          <SkeletonComponent key={i} />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <SkeletonComponent key={i} />
      ))}
    </div>
  );
}

// Pulse animation for loading states
export function PulseAnimation({ children, isLoading = true }) {
  return (
    <div className={`${isLoading ? 'animate-pulse' : ''}`}>
      {children}
    </div>
  );
}

// Empty state component
export function EmptyState({ 
  icon: Icon = BookOpen,
  title = "No content found",
  description = "There's nothing here yet.",
  action,
  actionLabel = "Get Started"
}) {
  return (
    <div className="text-center py-16">
      <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
        <Icon className="w-8 h-8 text-muted-foreground" />
      </div>
      <h3 className="text-xl font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-muted-foreground mb-6 max-w-md mx-auto">{description}</p>
      {action && (
        <button
          onClick={action}
          className="inline-flex items-center px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}