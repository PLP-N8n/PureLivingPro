import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  Play, 
  CheckCircle2, 
  XCircle, 
  Clock,
  Zap,
  AlertTriangle
} from "lucide-react";

const TEST_SUITES = [
  {
    name: 'API Connection Tests',
    tests: [
      { name: 'BlogPost API', test: () => import('@/api/entities').then(m => m.BlogPost.list('-created_date', 1)) },
      { name: 'WellnessPick API', test: () => import('@/api/entities').then(m => m.WellnessPick.list('-created_date', 1)) },
      { name: 'User API', test: () => import('@/api/entities').then(m => m.User.me().catch(() => 'Not authenticated - OK')) }
    ]
  },
  {
    name: 'Performance Tests',
    tests: [
      { 
        name: 'Memory Usage', 
        test: () => {
          if (!performance.memory) throw new Error('Memory API not available');
          const usage = (performance.memory.usedJSHeapSize / performance.memory.jsHeapSizeLimit) * 100;
          if (usage > 90) throw new Error(`High memory usage: ${usage.toFixed(1)}%`);
          return `Memory usage: ${usage.toFixed(1)}%`;
        }
      },
      { 
        name: 'Local Storage', 
        test: () => {
          const testKey = 'perf_test_' + Date.now();
          localStorage.setItem(testKey, 'test');
          const retrieved = localStorage.getItem(testKey);
          localStorage.removeItem(testKey);
          if (retrieved !== 'test') throw new Error('Local storage read/write failed');
          return 'Local storage working';
        }
      },
      {
        name: 'Network Connection',
        test: () => {
          if (!navigator.onLine) throw new Error('No network connection');
          return `Online - ${navigator.connection?.effectiveType || 'Unknown'} connection`;
        }
      }
    ]
  },
  {
    name: 'Feature Tests',
    tests: [
      {
        name: 'Analytics Integration',
        test: () => {
          if (typeof window.gtag === 'function') return 'Google Analytics loaded';
          if (typeof window.fbq === 'function') return 'Facebook Pixel loaded';
          return 'No analytics detected - OK for development';
        }
      },
      {
        name: 'Performance Monitor',
        test: () => {
          if (window.performanceTracker) return 'Performance tracker active';
          throw new Error('Performance tracker not initialized');
        }
      },
      {
        name: 'Error Boundary',
        test: () => {
          // Test that error boundaries are properly set up
          const errorBoundaries = document.querySelectorAll('[data-error-boundary]');
          return errorBoundaries.length > 0 ? 'Error boundaries active' : 'Error boundaries not detected';
        }
      }
    ]
  }
];

export default function TestRunner({ isVisible = true }) {
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState({});
  const [progress, setProgress] = useState(0);
  const [currentTest, setCurrentTest] = useState('');

  const runTests = async () => {
    setIsRunning(true);
    setResults({});
    setProgress(0);
    
    const allTests = TEST_SUITES.flatMap(suite => 
      suite.tests.map(test => ({ ...test, suite: suite.name }))
    );
    
    const totalTests = allTests.length;
    let completedTests = 0;
    const testResults = {};

    for (const suite of TEST_SUITES) {
      testResults[suite.name] = [];
      
      for (const test of suite.tests) {
        setCurrentTest(`${suite.name}: ${test.name}`);
        const startTime = performance.now();
        
        try {
          const result = await test.test();
          const duration = performance.now() - startTime;
          
          testResults[suite.name].push({
            name: test.name,
            status: 'passed',
            message: typeof result === 'string' ? result : 'Test passed',
            duration: Math.round(duration)
          });
        } catch (error) {
          const duration = performance.now() - startTime;
          
          testResults[suite.name].push({
            name: test.name,
            status: 'failed',
            message: error.message,
            duration: Math.round(duration)
          });
        }
        
        completedTests++;
        setProgress((completedTests / totalTests) * 100);
        setResults({ ...testResults });
        
        // Small delay to prevent blocking the UI
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    }
    
    setIsRunning(false);
    setCurrentTest('');
  };

  const getTestIcon = (status) => {
    switch (status) {
      case 'passed': return <CheckCircle2 className="w-3 h-3 text-green-600" />;
      case 'failed': return <XCircle className="w-3 h-3 text-red-600" />;
      default: return <Clock className="w-3 h-3 text-gray-400" />;
    }
  };

  const getTotalStats = () => {
    let passed = 0;
    let failed = 0;
    let totalDuration = 0;
    
    Object.values(results).forEach(suiteResults => {
      suiteResults.forEach(test => {
        if (test.status === 'passed') passed++;
        if (test.status === 'failed') failed++;
        totalDuration += test.duration;
      });
    });
    
    return { passed, failed, totalDuration };
  };

  if (!isVisible) return null;

  const stats = getTotalStats();
  const hasResults = Object.keys(results).length > 0;

  return (
    <Card className="bg-white/95 backdrop-blur-sm border-sage-200 shadow-lg">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center justify-between">
          <div className="flex items-center">
            <Zap className="w-4 h-4 mr-2 text-sage-600" />
            System Tests
          </div>
          <Badge className={`text-xs ${
            hasResults ? 
              (stats.failed > 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800') :
              'bg-gray-100 text-gray-800'
          }`}>
            {hasResults ? 
              (stats.failed > 0 ? `${stats.failed} Failed` : 'All Passed') :
              'Not Run'
            }
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-3">
        {/* Test Progress */}
        {isRunning && (
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span>Running Tests...</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
            <div className="text-xs text-muted-foreground truncate">
              {currentTest}
            </div>
          </div>
        )}

        {/* Test Statistics */}
        {hasResults && (
          <div className="grid grid-cols-3 gap-2">
            <div className="text-center p-2 bg-green-50 rounded">
              <div className="text-xs font-semibold text-green-700">{stats.passed}</div>
              <div className="text-xs text-green-600">Passed</div>
            </div>
            <div className="text-center p-2 bg-red-50 rounded">
              <div className="text-xs font-semibold text-red-700">{stats.failed}</div>
              <div className="text-xs text-red-600">Failed</div>
            </div>
            <div className="text-center p-2 bg-blue-50 rounded">
              <div className="text-xs font-semibold text-blue-700">{stats.totalDuration}ms</div>
              <div className="text-xs text-blue-600">Duration</div>
            </div>
          </div>
        )}

        {/* Test Results */}
        {hasResults && (
          <div className="max-h-40 overflow-y-auto space-y-2">
            {Object.entries(results).map(([suiteName, suiteResults]) => (
              <div key={suiteName} className="space-y-1">
                <div className="text-xs font-semibold text-muted-foreground">{suiteName}</div>
                {suiteResults.map((test, index) => (
                  <div key={index} className="flex items-center justify-between text-xs p-1 rounded bg-gray-50">
                    <div className="flex items-center">
                      {getTestIcon(test.status)}
                      <span className="ml-1 truncate">{test.name}</span>
                    </div>
                    <span className="text-muted-foreground">{test.duration}ms</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
        )}

        {/* Failed Test Details */}
        {hasResults && stats.failed > 0 && (
          <div className="border-t pt-2">
            <div className="text-xs font-semibold text-red-600 mb-1 flex items-center">
              <AlertTriangle className="w-3 h-3 mr-1" />
              Failed Tests
            </div>
            <div className="space-y-1 max-h-20 overflow-y-auto">
              {Object.values(results).flat()
                .filter(test => test.status === 'failed')
                .map((test, index) => (
                  <div key={index} className="text-xs p-1 bg-red-50 rounded text-red-700">
                    <div className="font-semibold">{test.name}</div>
                    <div className="truncate">{test.message}</div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* Controls */}
        <Button
          size="sm"
          onClick={runTests}
          disabled={isRunning}
          className="w-full text-xs bg-sage-600 hover:bg-sage-700"
        >
          <Play className="w-3 h-3 mr-1" />
          {isRunning ? 'Running Tests...' : 'Run System Tests'}
        </Button>
      </CardContent>
    </Card>
  );
}