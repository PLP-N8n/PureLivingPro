import React, { useEffect, useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Activity, 
  Zap, 
  Clock, 
  Wifi, 
  Database, 
  Eye,
  EyeOff,
  Download,
  AlertTriangle
} from 'lucide-react';

// Performance metrics hook
export function usePerformanceMetrics() {
  const [metrics, setMetrics] = useState({
    renderTime: 0,
    loadTime: 0,
    memoryUsage: 0,
    networkRequests: 0,
    cacheHits: 0,
    errors: 0
  });

  const startTime = useRef(Date.now());

  useEffect(() => {
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.entryType === 'navigation') {
          setMetrics(prev => ({
            ...prev,
            loadTime: entry.loadEventEnd - entry.loadEventStart
          }));
        }
        
        if (entry.entryType === 'resource') {
          setMetrics(prev => ({
            ...prev,
            networkRequests: prev.networkRequests + 1
          }));
        }
      }
    });

    observer.observe({ entryTypes: ['navigation', 'resource'] });

    // Memory usage (if available)
    if (performance.memory) {
      const updateMemory = () => {
        setMetrics(prev => ({
          ...prev,
          memoryUsage: performance.memory.usedJSHeapSize / 1024 / 1024 // MB
        }));
      };
      
      const interval = setInterval(updateMemory, 1000);
      return () => {
        clearInterval(interval);
        observer.disconnect();
      };
    }

    return () => observer.disconnect();
  }, []);

  return metrics;
}

// Performance monitor component
export default function PerformanceMonitor({ isVisible = false }) {
  const [visible, setVisible] = useState(isVisible);
  const [expanded, setExpanded] = useState(false);
  const metrics = usePerformanceMetrics();

  const getPerformanceScore = () => {
    const { loadTime, memoryUsage, networkRequests } = metrics;
    let score = 100;
    
    // Deduct points for slow load times
    if (loadTime > 3000) score -= 30;
    else if (loadTime > 1000) score -= 15;
    
    // Deduct points for high memory usage
    if (memoryUsage > 50) score -= 20;
    else if (memoryUsage > 20) score -= 10;
    
    // Deduct points for too many requests
    if (networkRequests > 50) score -= 20;
    else if (networkRequests > 20) score -= 10;
    
    return Math.max(0, score);
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 70) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const exportMetrics = () => {
    const data = {
      timestamp: new Date().toISOString(),
      url: window.location.href,
      userAgent: navigator.userAgent,
      metrics: {
        ...metrics,
        performanceScore: getPerformanceScore(),
        connection: navigator.connection ? {
          effectiveType: navigator.connection.effectiveType,
          downlink: navigator.connection.downlink,
          rtt: navigator.connection.rtt
        } : null,
        timing: performance.timing ? {
          domContentLoaded: performance.timing.domContentLoadedEventEnd - performance.timing.navigationStart,
          firstPaint: performance.getEntriesByName('first-paint')[0]?.startTime || 0,
          firstContentfulPaint: performance.getEntriesByName('first-contentful-paint')[0]?.startTime || 0
        } : null
      }
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `performance-metrics-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!visible) {
    return (
      <Button
        onClick={() => setVisible(true)}
        size="sm"
        variant="outline"
        className="fixed bottom-4 right-4 z-50 bg-background/80 backdrop-blur-sm"
      >
        <Activity className="w-4 h-4" />
      </Button>
    );
  }

  const performanceScore = getPerformanceScore();

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm">
      <Card className="bg-background/95 backdrop-blur-sm border shadow-lg">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium flex items-center">
              <Activity className="w-4 h-4 mr-2" />
              Performance
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Badge className={`${getScoreColor(performanceScore)} px-2 py-1 text-xs`}>
                {performanceScore}/100
              </Badge>
              <Button
                onClick={() => setVisible(false)}
                size="sm"
                variant="ghost"
                className="p-1 h-6 w-6"
              >
                <EyeOff className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center">
              <Clock className="w-3 h-3 mr-1 text-blue-500" />
              <span>{Math.round(metrics.loadTime)}ms</span>
            </div>
            <div className="flex items-center">
              <Zap className="w-3 h-3 mr-1 text-yellow-500" />
              <span>{Math.round(metrics.memoryUsage)}MB</span>
            </div>
            <div className="flex items-center">
              <Wifi className="w-3 h-3 mr-1 text-green-500" />
              <span>{metrics.networkRequests} req</span>
            </div>
            <div className="flex items-center">
              <Database className="w-3 h-3 mr-1 text-purple-500" />
              <span>{metrics.cacheHits} cache</span>
            </div>
          </div>

          {expanded && (
            <div className="space-y-2 text-xs border-t pt-3">
              <div className="flex justify-between">
                <span>First Paint:</span>
                <span>{Math.round(performance.getEntriesByName('first-paint')[0]?.startTime || 0)}ms</span>
              </div>
              <div className="flex justify-between">
                <span>FCP:</span>
                <span>{Math.round(performance.getEntriesByName('first-contentful-paint')[0]?.startTime || 0)}ms</span>
              </div>
              <div className="flex justify-between">
                <span>DOM Ready:</span>
                <span>{Math.round((performance.timing?.domContentLoadedEventEnd - performance.timing?.navigationStart) || 0)}ms</span>
              </div>
              {navigator.connection && (
                <div className="flex justify-between">
                  <span>Connection:</span>
                  <span>{navigator.connection.effectiveType}</span>
                </div>
              )}
            </div>
          )}

          <div className="flex justify-between items-center">
            <Button
              onClick={() => setExpanded(!expanded)}
              size="sm"
              variant="outline"
              className="text-xs h-6 px-2"
            >
              {expanded ? 'Less' : 'More'}
            </Button>
            <Button
              onClick={exportMetrics}
              size="sm"
              variant="outline"
              className="text-xs h-6 px-2"
            >
              <Download className="w-3 h-3 mr-1" />
              Export
            </Button>
          </div>

          {performanceScore < 70 && (
            <div className="flex items-start space-x-2 p-2 bg-yellow-50 rounded border-yellow-200 border">
              <AlertTriangle className="w-3 h-3 text-yellow-600 mt-0.5" />
              <div className="text-xs text-yellow-800">
                <p className="font-medium">Performance Warning</p>
                <p>Page performance is below optimal. Consider optimizing images, reducing bundle size, or improving caching.</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// React component performance tracker
export function withPerformanceTracking(Component, componentName) {
  return React.forwardRef((props, ref) => {
    const startTime = useRef();
    const renderCount = useRef(0);

    useEffect(() => {
      startTime.current = performance.now();
      renderCount.current += 1;
    });

    useEffect(() => {
      const endTime = performance.now();
      const renderTime = endTime - startTime.current;
      
      // Log performance in development
      if (process.env.NODE_ENV === 'development') {
        console.log(`${componentName} render #${renderCount.current}: ${renderTime.toFixed(2)}ms`);
      }
      
      // Track slow renders
      if (renderTime > 16) { // 16ms = 60fps threshold
        console.warn(`Slow render detected in ${componentName}: ${renderTime.toFixed(2)}ms`);
      }
    });

    return <Component {...props} ref={ref} />;
  });
}