
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BlogPost, WellnessPick, User } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, Heart, BookOpen, ArrowRight, Clock, Star, ExternalLink } from "lucide-react";
import { format } from "date-fns";

const categoryMapping = {
  "nutrition": ["nutrition", "healthy-recipes"],
  "meditation": ["meditation-mindfulness"],
  "fitness": ["fitness"],
  "recipes": ["healthy-recipes"],
  "supplements": ["supplements"],
  "skincare": ["skin-selfcare"]
};

const categoryColors = {
  "nutrition": "bg-green-100 text-green-800 border-green-200",
  "meditation-mindfulness": "bg-purple-100 text-purple-800 border-purple-200",
  "fitness": "bg-orange-100 text-orange-800 border-orange-200",
  "natural-remedies": "bg-sage-100 text-sage-800 border-sage-200",
  "healthy-recipes": "bg-amber-100 text-amber-800 border-amber-200",
  "supplements": "bg-blue-100 text-blue-800 border-blue-200",
  "skin-selfcare": "bg-pink-100 text-pink-800 border-pink-200"
};

// Function to get recent categories from reading history
const getReadingHistory = () => {
  try {
    const history = localStorage.getItem('readingHistory');
    return history ? JSON.parse(history) : [];
  } catch (e) {
    console.error("Error parsing reading history from localStorage:", e);
    return [];
  }
};

export default function ForYouSection() {
  const [user, setUser] = useState(null);
  const [personalizedPosts, setPersonalizedPosts] = useState([]);
  const [personalizedProducts, setPersonalizedProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPersonalizedContent();
  }, []);

  const loadPersonalizedContent = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      if (currentUser.wellness_profile) {
        await loadPersonalizedData(currentUser.wellness_profile);
      }
    } catch (error) {
      console.error("Error loading user or personalized content:", error);
      // Set user to null if loading fails
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  const loadPersonalizedData = async (profile) => {
    try {
      const readingHistory = getReadingHistory();

      // Combine preferences from quiz and reading history for a smarter recommendation
      let preferredCategories = [];
      profile.content_preferences?.forEach(pref => {
        if (categoryMapping[pref]) {
          preferredCategories.push(...categoryMapping[pref]);
        }
      });
      
      // Give weight to recent reading history
      const combinedPrefs = [...preferredCategories, ...readingHistory];
      const uniquePrefs = [...new Set(combinedPrefs)];


      // If no specific preferences, use wellness goals as fallback
      if (uniquePrefs.length === 0 && profile.wellness_goals) {
        profile.wellness_goals.forEach(goal => {
          switch (goal) {
            case "stress_management":
              preferredCategories.push("meditation-mindfulness");
              break;
            case "better_nutrition":
              preferredCategories.push("nutrition", "healthy-recipes");
              break;
            case "fitness_energy":
              preferredCategories.push("fitness");
              break;
            case "natural_remedies":
              preferredCategories.push("natural-remedies", "supplements");
              break;
            case "better_sleep":
              preferredCategories.push("meditation-mindfulness", "natural-remedies");
              break;
          }
        });
        // Update uniquePrefs if wellness goals were used as fallback
        if (preferredCategories.length > 0) {
          uniquePrefs.push(...new Set(preferredCategories)); // Add these to uniquePrefs
        }
      }

      // Load posts and products based on enhanced preferences
      if (uniquePrefs.length > 0) {
        let posts = [];
        let products = [];

        try {
          posts = await BlogPost.filter({ published: true }, "-created_date", 50);
        } catch (error) {
          console.error("Error loading posts for personalization:", error);
        }

        try {
          products = await WellnessPick.list("-created_date", 50);
        } catch (error) {
          console.error("Error loading products for personalization:", error);
        }

        // Filter by preferred categories
        const filteredPosts = posts.filter(post => 
          uniquePrefs.includes(post?.category)
        ).slice(0, 6);

        const filteredProducts = products.filter(product => 
          uniquePrefs.some(cat => 
            product?.category?.includes(cat) || 
            product?.benefits?.some(benefit => 
              benefit?.toLowerCase().includes(cat.replace('-', ' '))
            )
          )
        ).slice(0, 4);

        setPersonalizedPosts(filteredPosts);
        setPersonalizedProducts(filteredProducts);
      }
    } catch (error) {
      console.error("Error loading personalized data:", error);
    }
  };

  if (isLoading) {
    return (
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center mb-8">
            <Skeleton className="w-6 h-6 mr-3" />
            <Skeleton className="h-8 w-48" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-64 organic-border" />
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (!user?.wellness_profile?.quiz_completed) {
    return (
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-sage-50 to-amber-50/30">
        <div className="max-w-4xl mx-auto text-center">
          <Card className="premium-shadow organic-border bg-white/90 backdrop-blur-sm">
            <CardContent className="p-12">
              <div className="w-20 h-20 bg-gradient-to-br from-sage-500 to-sage-600 organic-border flex items-center justify-center mx-auto mb-6">
                <Sparkles className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-sage-700 mb-4">
                Unlock Your Personal Wellness Journey
              </h3>
              <p className="text-lg text-sage-600 mb-8 leading-relaxed">
                Take our 2-minute wellness quiz to get personalized article recommendations, 
                curated product picks, and content tailored specifically for your wellness goals.
              </p>
              <Link to={createPageUrl("WellnessQuiz")}>
                <Button className="bg-sage-600 hover:bg-sage-700 text-white px-8 py-4 text-lg organic-border premium-shadow">
                  Take the Wellness Quiz
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <p className="text-sm text-sage-500 mt-4">
                ✨ Completely free • Takes less than 2 minutes • Instant results
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    );
  }

  if (personalizedPosts.length === 0 && personalizedProducts.length === 0) {
    return null;
  }

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-sage-50/50 to-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Heart className="w-6 h-6 text-sage-600 mr-2" />
            <span className="text-sage-600 font-medium uppercase tracking-wider text-sm">
              Personalized For You
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-sage-700 mb-4">
            Your Wellness Recommendations
          </h2>
          <p className="text-lg text-sage-600 max-w-2xl mx-auto">
            Based on your wellness quiz results, here are articles and products 
            specifically chosen to support your journey.
          </p>
        </div>

        {/* Personalized Articles */}
        {personalizedPosts.length > 0 && (
          <div className="mb-16">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-bold text-sage-700 flex items-center">
                <BookOpen className="w-6 h-6 mr-2" />
                Articles for You
              </h3>
              <Link to={createPageUrl("Blog") + "?filter=for-you"}>
                <Button variant="outline" className="border-sage-300 text-sage-700 hover:bg-sage-50">
                  See All
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {personalizedPosts.map((post) => (
                <Link key={post.id} to={`${createPageUrl("BlogPost")}/${post.slug || post.id}`} className="group">
                  <Card className="premium-shadow organic-border border-0 bg-white group-hover:scale-105 transition-all duration-300 overflow-hidden h-full">
                    <CardContent className="p-0 h-full flex flex-col">
                      <div className="relative h-40 overflow-hidden">
                        <img
                          src={post.featured_image || "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"}
                          alt={post.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                          loading="lazy"
                        />
                        {post.category && (
                          <Badge className={`absolute top-3 left-3 ${categoryColors[post.category]} border organic-border`}>
                            {post.category.replace('-', ' ')}
                          </Badge>
                        )}
                      </div>
                      <div className="p-4 flex-1 flex flex-col">
                        <h4 className="font-bold text-sage-700 mb-2 line-clamp-2 group-hover:text-sage-800 transition-colors">
                          {post.title}
                        </h4>
                        <p className="text-sm text-sage-600 mb-3 line-clamp-2 flex-1">
                          {post.excerpt}
                        </p>
                        <div className="flex items-center justify-between text-sm text-sage-500">
                          <div className="flex items-center">
                            <Clock className="w-3 h-3 mr-1" />
                            {post.read_time || 5} min
                          </div>
                          <span>{format(new Date(post.created_date), "MMM d")}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Personalized Products */}
        {personalizedProducts.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-bold text-sage-700 flex items-center">
                <Sparkles className="w-6 h-6 mr-2" />
                Products for You
              </h3>
              <Link to={createPageUrl("WellnessPicks")}>
                <Button variant="outline" className="border-sage-300 text-sage-700 hover:bg-sage-50">
                  See All
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {personalizedProducts.map((product) => (
                <Card key={product.id} className="premium-shadow organic-border border-0 bg-white group hover:scale-105 transition-all duration-300 overflow-hidden">
                  <CardContent className="p-0">
                    <div className="relative h-40 overflow-hidden">
                      <img
                        src={product.image_url || "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        loading="lazy"
                      />
                    </div>
                    <div className="p-4">
                      <h4 className="font-bold text-sage-700 mb-2 line-clamp-2">{product.name}</h4>
                      <p className="text-sm text-sage-600 mb-3 line-clamp-2">{product.description}</p>
                      
                      {product.rating && (
                        <div className="flex items-center mb-2">
                          <div className="flex items-center">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${
                                  i < product.rating ? "text-yellow-400 fill-current" : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-xs text-sage-500 ml-1">({product.review_count})</span>
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sage-700">£{product.discounted_price || product.original_price}</span>
                        <a
                          href={product.affiliate_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <Button size="sm" className="bg-sage-600 hover:bg-sage-700 text-white">
                            <ExternalLink className="w-3 h-3" />
                          </Button>
                        </a>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
