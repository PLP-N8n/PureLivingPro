import React, { useEffect } from "react";

export default function SEOHead({
  title,
  description,
  keywords = [],
  canonicalUrl,
  ogTitle,
  ogDescription,
  ogImage,
  ogType = "website",
  twitterCard = "summary_large_image",
  twitterTitle,
  twitterDescription,
  twitterImage,
  author = "Pure Living Pro",
  publishedTime,
  modifiedTime,
  article = false,
  schema,
  customMeta = [],
  noIndex = false,
  noFollow = false
}) {
  useEffect(() => {
    // Generate robots meta content
    const robotsContent = [
      noIndex ? "noindex" : "index",
      noFollow ? "nofollow" : "follow"
    ].join(", ");

    // Default site title
    const siteTitle = "Pure Living Pro - Holistic Wellness & Natural Living";
    const fullTitle = title ? `${title} | Pure Living Pro` : siteTitle;

    // Ensure URLs are absolute
    const baseUrl = typeof window !== 'undefined' 
      ? window.location.origin 
      : 'https://pureliving.pro';

    const absoluteCanonicalUrl = canonicalUrl?.startsWith('http') 
      ? canonicalUrl 
      : `${baseUrl}${canonicalUrl || window.location.pathname}`;

    const absoluteOgImage = ogImage?.startsWith('http') 
      ? ogImage 
      : ogImage ? `${baseUrl}${ogImage}` : `${baseUrl}/images/og-default.jpg`;

    const absoluteTwitterImage = twitterImage?.startsWith('http') 
      ? twitterImage 
      : twitterImage ? `${baseUrl}${twitterImage}` : absoluteOgImage;

    // Update document title
    document.title = fullTitle;

    // Function to set or update meta tag
    const setMetaTag = (selector, attribute, content) => {
      if (!content) return;
      
      let meta = document.querySelector(selector);
      if (!meta) {
        meta = document.createElement('meta');
        if (attribute === 'property') {
          meta.setAttribute('property', selector.replace('meta[property="', '').replace('"]', ''));
        } else if (attribute === 'name') {
          meta.setAttribute('name', selector.replace('meta[name="', '').replace('"]', ''));
        } else if (attribute === 'http-equiv') {
          meta.setAttribute('http-equiv', selector.replace('meta[http-equiv="', '').replace('"]', ''));
        }
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', content);
    };

    // Function to set or update link tag
    const setLinkTag = (rel, href) => {
      if (!href) return;
      
      let link = document.querySelector(`link[rel="${rel}"]`);
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', rel);
        document.head.appendChild(link);
      }
      link.setAttribute('href', href);
    };

    // Basic Meta Tags
    setMetaTag('meta[name="description"]', 'name', description);
    if (keywords.length > 0) {
      setMetaTag('meta[name="keywords"]', 'name', keywords.join(", "));
    }
    setMetaTag('meta[name="robots"]', 'name', robotsContent);
    setMetaTag('meta[name="author"]', 'name', author);

    // Canonical URL
    setLinkTag('canonical', absoluteCanonicalUrl);

    // Open Graph Meta Tags
    setMetaTag('meta[property="og:title"]', 'property', ogTitle || title || siteTitle);
    setMetaTag('meta[property="og:description"]', 'property', ogDescription || description);
    setMetaTag('meta[property="og:type"]', 'property', ogType);
    setMetaTag('meta[property="og:image"]', 'property', absoluteOgImage);
    setMetaTag('meta[property="og:url"]', 'property', absoluteCanonicalUrl);
    setMetaTag('meta[property="og:site_name"]', 'property', "Pure Living Pro");

    // Article-specific Open Graph
    if (article) {
      setMetaTag('meta[property="article:author"]', 'property', author);
      if (publishedTime) {
        setMetaTag('meta[property="article:published_time"]', 'property', publishedTime);
      }
      if (modifiedTime) {
        setMetaTag('meta[property="article:modified_time"]', 'property', modifiedTime);
      }
      setMetaTag('meta[property="article:section"]', 'property', "Wellness");
      
      // Article tags
      keywords.forEach((tag, index) => {
        setMetaTag(`meta[property="article:tag"][content="${tag}"]`, 'property', tag);
      });
    }

    // Twitter Card Meta Tags
    setMetaTag('meta[name="twitter:card"]', 'name', twitterCard);
    setMetaTag('meta[name="twitter:title"]', 'name', twitterTitle || ogTitle || title || siteTitle);
    setMetaTag('meta[name="twitter:description"]', 'name', twitterDescription || ogDescription || description);
    setMetaTag('meta[name="twitter:image"]', 'name', absoluteTwitterImage);
    setMetaTag('meta[name="twitter:site"]', 'name', "@pure_living_pro");
    setMetaTag('meta[name="twitter:creator"]', 'name', "@pure_living_pro");

    // Additional Meta Tags
    setMetaTag('meta[name="viewport"]', 'name', "width=device-width, initial-scale=1.0");
    setMetaTag('meta[http-equiv="Content-Type"]', 'http-equiv', "text/html; charset=utf-8");
    setMetaTag('meta[name="language"]', 'name', "English");
    setMetaTag('meta[name="theme-color"]', 'name', "#10b981");

    // Custom Meta Tags
    customMeta.forEach((meta) => {
      if (meta.name) {
        setMetaTag(`meta[name="${meta.name}"]`, 'name', meta.content);
      } else if (meta.property) {
        setMetaTag(`meta[property="${meta.property}"]`, 'property', meta.content);
      } else if (meta['http-equiv']) {
        setMetaTag(`meta[http-equiv="${meta['http-equiv']}"]`, 'http-equiv', meta.content);
      }
    });

    // Structured Data
    if (schema) {
      let structuredDataScript = document.querySelector('script[type="application/ld+json"]');
      if (!structuredDataScript) {
        structuredDataScript = document.createElement('script');
        structuredDataScript.type = 'application/ld+json';
        document.head.appendChild(structuredDataScript);
      }
      
      // Update schema to include new logo
      const updatedSchema = {
        ...schema,
        publisher: schema.publisher ? {
          ...schema.publisher,
          logo: {
            "@type": "ImageObject",
            "url": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/7922d7bf4_LogoFinal.jpg",
            "width": 400,
            "height": 400
          }
        } : undefined
      };
      
      structuredDataScript.textContent = JSON.stringify(updatedSchema);
    }

    // Cleanup function to remove meta tags when component unmounts
    return () => {
      // We'll keep the meta tags as they should persist for the page
      // This cleanup is mainly for structured data that might change
      if (schema) {
        const existingScript = document.querySelector('script[type="application/ld+json"]');
        if (existingScript) {
          existingScript.remove();
        }
      }
    };
  }, [
    title,
    description,
    keywords,
    canonicalUrl,
    ogTitle,
    ogDescription,
    ogImage,
    ogType,
    twitterCard,
    twitterTitle,
    twitterDescription,
    twitterImage,
    author,
    publishedTime,
    modifiedTime,
    article,
    schema,
    customMeta,
    noIndex,
    noFollow
  ]);

  // This component doesn't render anything visible
  return null;
}