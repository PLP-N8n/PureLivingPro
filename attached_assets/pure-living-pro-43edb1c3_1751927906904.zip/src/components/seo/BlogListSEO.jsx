
import React from "react";
import SEOHead from "./SEOHead";

export default function BlogListSEO({ 
  category, 
  searchQuery, 
  currentUrl,
  posts = [],
  page = 1 
}) {
  // Generate dynamic title based on filters
  let title = "Wellness Blog & Articles";
  let description = "Discover evidence-based wellness articles, natural living tips, and holistic health insights from Pure Living Pro experts.";

  if (category && category !== "all") {
    const categoryName = category.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
    title = `${categoryName} Articles & Tips`;
    description = `Expert ${categoryName.toLowerCase()} articles, tips, and insights for your wellness journey. Evidence-based content from Pure Living Pro.`;
  }

  if (searchQuery) {
    title = `Search Results for "${searchQuery}"`;
    description = `Search results for "${searchQuery}" on Pure Living Pro wellness blog. Find articles, tips, and insights about ${searchQuery}.`;
  }

  if (page > 1) {
    title += ` - Page ${page}`;
  }

  // Generate keywords
  const keywords = [
    'wellness blog',
    'natural living',
    'holistic health',
    'wellness articles',
    'health tips',
    'natural remedies',
    'meditation',
    'nutrition',
    'fitness',
    'pure living pro'
  ];

  if (category && category !== "all") {
    keywords.unshift(category.replace('-', ' '));
  }

  if (searchQuery) {
    keywords.unshift(searchQuery);
  }

  // Generate Blog structured data
  const blogSchema = {
    "@context": "https://schema.org",
    "@type": "Blog",
    "name": "Pure Living Pro Wellness Blog",
    "description": "Evidence-based wellness articles and natural living insights",
    "url": currentUrl,
    "publisher": {
      "@type": "Organization",
      "name": "Pure Living Pro",
      "logo": {
        "@type": "ImageObject",
        "url": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/7922d7bf4_LogoFinal.jpg",
        "width": 400,
        "height": 400
      }
    },
    "inLanguage": "en-US",
    "author": {
      "@type": "Organization",
      "name": "Pure Living Pro Team"
    }
  };

  // Add ItemList schema for posts
  if (posts.length > 0) {
    const itemListSchema = {
      "@context": "https://schema.org",
      "@type": "ItemList",
      "itemListElement": posts.slice(0, 10).map((post, index) => ({
        "@type": "ListItem",
        "position": index + 1,
        "item": {
          "@type": "Article",
          "headline": post.title,
          "description": post.excerpt,
          "image": post.featured_image,
          "datePublished": post.created_date,
          "author": {
            "@type": "Person",
            "name": "Pure Living Pro Team"
          },
          "url": `${currentUrl}/${post.slug || post.id}`
        }
      }))
    };

    blogSchema["@graph"] = [blogSchema, itemListSchema];
  }

  return (
    <SEOHead
      title={title}
      description={description}
      keywords={keywords}
      canonicalUrl={currentUrl}
      ogTitle={title}
      ogDescription={description}
      ogImage="/images/blog-og-default.jpg"
      schema={blogSchema}
      customMeta={[
        { name: "blog-category", content: category || "all" },
        { name: "content-type", content: "blog-listing" },
        { name: "page-number", content: page.toString() }
      ]}
    />
  );
}
