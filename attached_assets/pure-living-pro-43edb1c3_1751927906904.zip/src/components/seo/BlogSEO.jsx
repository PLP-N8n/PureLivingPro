
import React from "react";
import SEOHead from "./SEOHead";
import { format } from "date-fns";

export default function BlogSEO({ post, currentUrl }) {
  if (!post) return null;

  const {
    title,
    excerpt,
    content,
    featured_image,
    category,
    tags = [],
    created_date,
    updated_date,
    seo_title,
    meta_description,
    read_time
  } = post;

  // Generate SEO-optimized title
  const seoTitle = seo_title || title;
  const seoDescription = meta_description || excerpt || 
    (content ? content.substring(0, 160).replace(/[#*]/g, '').trim() + '...' : '');

  // Generate keywords from category and tags
  const keywords = [
    category?.replace('-', ' '),
    ...tags,
    'wellness',
    'natural living',
    'holistic health',
    'pure living pro'
  ].filter(Boolean);

  // Format dates for structured data
  const publishedTime = created_date ? new Date(created_date).toISOString() : null;
  const modifiedTime = updated_date ? new Date(updated_date).toISOString() : publishedTime;

  // Generate Article structured data
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": title,
    "description": seoDescription,
    "image": featured_image ? [featured_image] : [],
    "datePublished": publishedTime,
    "dateModified": modifiedTime,
    "author": {
      "@type": "Person",
      "name": "Pure Living Pro Team",
      "url": "https://pureliving.pro/about"
    },
    "publisher": {
      "@type": "Organization",
      "name": "Pure Living Pro",
      "logo": {
        "@type": "ImageObject",
        "url": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/7922d7bf4_LogoFinal.jpg",
        "width": 400,
        "height": 400
      }
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": currentUrl
    },
    "articleSection": category?.replace('-', ' ') || "Wellness",
    "keywords": keywords.join(", "),
    "wordCount": content ? content.split(' ').length : 0,
    "timeRequired": read_time ? `PT${read_time}M` : "PT5M"
  };

  // Add FAQ schema if content contains questions
  const faqMatches = content?.match(/(?:^|\n)#{1,3}\s*(.+\?)/gm);
  if (faqMatches && faqMatches.length > 0) {
    const faqSchema = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": faqMatches.slice(0, 5).map(question => ({
        "@type": "Question",
        "name": question.replace(/^#+\s*/, '').trim(),
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Detailed answer available in the full article."
        }
      }))
    };

    // Combine schemas
    articleSchema["@graph"] = [articleSchema, faqSchema];
  }

  return (
    <SEOHead
      title={seoTitle}
      description={seoDescription}
      keywords={keywords}
      canonicalUrl={currentUrl}
      ogTitle={seoTitle}
      ogDescription={seoDescription}
      ogImage={featured_image}
      ogType="article"
      twitterCard="summary_large_image"
      article={true}
      publishedTime={publishedTime}
      modifiedTime={modifiedTime}
      schema={articleSchema}
      customMeta={[
        { name: "article:author", content: "Pure Living Pro Team" },
        { name: "article:section", content: category?.replace('-', ' ') || "Wellness" },
        { name: "reading-time", content: `${read_time || 5} minutes` }
      ]}
    />
  );
}
