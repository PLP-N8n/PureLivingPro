import React from "react";
import SEOHead from "./SEOHead";

export default function ProductSEO({ products = [], category, currentUrl }) {
  // Generate dynamic title based on category
  let title = "Wellness Products & Recommendations";
  let description = "Discover carefully curated wellness products, natural supplements, and holistic health essentials recommended by Pure Living Pro experts.";

  if (category && category !== "all") {
    const categoryName = category.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
    title = `${categoryName} Products & Recommendations`;
    description = `Hand-picked ${categoryName.toLowerCase()} products for your wellness journey. Expert-recommended and thoroughly researched by Pure Living Pro.`;
  }

  // Generate keywords
  const keywords = [
    'wellness products',
    'natural supplements',
    'holistic health',
    'wellness recommendations',
    'natural living products',
    'organic wellness',
    'health products',
    'pure living pro'
  ];

  if (category && category !== "all") {
    keywords.unshift(category.replace('-', ' '));
  }

  // Generate ProductList structured data
  const productListSchema = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    "name": title,
    "description": description,
    "url": currentUrl,
    "numberOfItems": products.length,
    "itemListElement": products.slice(0, 20).map((product, index) => ({
      "@type": "ListItem",
      "position": index + 1,
      "item": {
        "@type": "Product",
        "name": product.name,
        "description": product.description,
        "image": product.image_url,
        "brand": {
          "@type": "Brand",
          "name": "Various"
        },
        "offers": {
          "@type": "Offer",
          "price": product.discounted_price || product.original_price,
          "priceCurrency": "GBP",
          "availability": "https://schema.org/InStock",
          "url": product.affiliate_link
        },
        "aggregateRating": product.rating && product.review_count ? {
          "@type": "AggregateRating",
          "ratingValue": product.rating,
          "reviewCount": product.review_count,
          "bestRating": 5,
          "worstRating": 1
        } : undefined
      }
    }))
  };

  return (
    <SEOHead
      title={title}
      description={description}
      keywords={keywords}
      canonicalUrl={currentUrl}
      ogTitle={title}
      ogDescription={description}
      ogImage="/images/products-og-default.jpg"
      schema={productListSchema}
      customMeta={[
        { name: "product-category", content: category || "all" },
        { name: "content-type", content: "product-listing" },
        { name: "product-count", content: products.length.toString() }
      ]}
    />
  );
}