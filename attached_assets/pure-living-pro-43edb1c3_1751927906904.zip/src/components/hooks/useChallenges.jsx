import { useState, useEffect, useCallback } from 'react';
import { Challenge, UserChallengeProgress, User } from '@/api/entities';
import { useEnhancedBase44 } from './useEnhancedBase44';

export function useChallenges(options = {}) {
  const {
    initialFilters = {},
    sortBy = "-created_date",
    limit = 50,
    autoFetch = true,
    includeUserProgress = true
  } = options;

  const [challenges, setChallenges] = useState([]);
  const [filteredChallenges, setFilteredChallenges] = useState([]);
  const [userProgress, setUserProgress] = useState([]);
  const [filters, setFilters] = useState(initialFilters);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);

  // Use enhanced Base44 client
  const { 
    filter: filterChallenges,
    list: listChallenges 
  } = useEnhancedBase44(Challenge, {
    cacheTTL: 300000, // 5 minutes
    returnStaleOnError: true
  });

  const { 
    filter: filterProgress 
  } = useEnhancedBase44(UserChallengeProgress, {
    cacheTTL: 60000, // 1 minute for user progress
    returnStaleOnError: true
  });

  // Load current user
  const loadCurrentUser = useCallback(async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      return user;
    } catch (error) {
      setCurrentUser(null);
      return null;
    }
  }, []);

  // Load challenges from API
  const loadChallenges = useCallback(async (customFilters = {}) => {
    setIsLoading(true);
    setHasError(false);
    
    try {
      const queryFilters = { 
        is_active: true,
        ...filters, 
        ...customFilters 
      };

      const result = await filterChallenges(queryFilters, sortBy, limit);
      const validChallenges = (result || []).map(challenge => ({
        ...challenge,
        duration_days: parseInt(challenge.duration_days) || 7,
        difficulty_level: challenge.difficulty_level || 'beginner'
      }));

      setChallenges(validChallenges);
      return validChallenges;
    } catch (error) {
      console.error('Error loading challenges:', error);
      setHasError(true);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [filters, sortBy, limit, filterChallenges]);

  // Load user progress
  const loadUserProgress = useCallback(async (user) => {
    if (!user || !includeUserProgress) return [];

    try {
      const progress = await filterProgress({ user_id: user.id });
      setUserProgress(progress || []);
      return progress || [];
    } catch (error) {
      console.error('Error loading user progress:', error);
      return [];
    }
  }, [filterProgress, includeUserProgress]);

  // Apply filters to challenges
  const applyFilters = useCallback(() => {
    let filtered = [...challenges];

    // Apply category filter
    if (filters.category && filters.category !== 'all') {
      filtered = filtered.filter(challenge => challenge.category === filters.category);
    }

    // Apply difficulty filter
    if (filters.difficulty && filters.difficulty !== 'all') {
      filtered = filtered.filter(challenge => challenge.difficulty_level === filters.difficulty);
    }

    // Apply duration filter
    if (filters.maxDuration) {
      filtered = filtered.filter(challenge => challenge.duration_days <= filters.maxDuration);
    }

    // Apply completion status filter
    if (filters.status && currentUser) {
      const userChallengeIds = new Set(userProgress.map(p => p.challenge_id));
      const completedChallengeIds = new Set(
        userProgress.filter(p => p.is_completed).map(p => p.challenge_id)
      );

      switch (filters.status) {
        case 'not-started':
          filtered = filtered.filter(challenge => !userChallengeIds.has(challenge.id));
          break;
        case 'in-progress':
          filtered = filtered.filter(challenge => 
            userChallengeIds.has(challenge.id) && !completedChallengeIds.has(challenge.id)
          );
          break;
        case 'completed':
          filtered = filtered.filter(challenge => completedChallengeIds.has(challenge.id));
          break;
      }
    }

    // Sort filtered results
    filtered.sort((a, b) => {
      switch (sortBy) {
        case '-created_date':
          return new Date(b.created_date) - new Date(a.created_date);
        case 'created_date':
          return new Date(a.created_date) - new Date(b.created_date);
        case 'title':
          return a.title.localeCompare(b.title);
        case 'duration':
          return a.duration_days - b.duration_days;
        case '-duration':
          return b.duration_days - a.duration_days;
        case 'difficulty':
          const difficultyOrder = { 'beginner': 1, 'intermediate': 2, 'advanced': 3 };
          return difficultyOrder[a.difficulty_level] - difficultyOrder[b.difficulty_level];
        default:
          return 0;
      }
    });

    setFilteredChallenges(filtered);
  }, [challenges, filters, sortBy, userProgress, currentUser]);

  // Update filters
  const updateFilters = useCallback((newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  }, []);

  // Clear filters
  const clearFilters = useCallback(() => {
    setFilters(initialFilters);
  }, [initialFilters]);

  // Join a challenge
  const joinChallenge = useCallback(async (challengeId) => {
    if (!currentUser) throw new Error('Must be logged in to join challenges');

    try {
      const progressData = {
        challenge_id: challengeId,
        user_id: currentUser.id,
        started_date: new Date().toISOString().split('T')[0],
        current_day: 1,
        completed_tasks: [],
        is_completed: false,
        streak_days: 0,
        notes: []
      };

      await UserChallengeProgress.create(progressData);
      
      // Reload user progress
      await loadUserProgress(currentUser);
      
      return true;
    } catch (error) {
      console.error('Error joining challenge:', error);
      throw error;
    }
  }, [currentUser, loadUserProgress]);

  // Get challenge progress for user
  const getChallengeProgress = useCallback((challengeId) => {
    return userProgress.find(p => p.challenge_id === challengeId);
  }, [userProgress]);

  // Get challenges by category
  const getChallengesByCategory = useCallback((category) => {
    return challenges.filter(challenge => challenge.category === category);
  }, [challenges]);

  // Get recommended challenges
  const getRecommendedChallenges = useCallback((count = 3) => {
    // Simple recommendation logic - can be enhanced with user preferences
    return challenges
      .filter(challenge => challenge.difficulty_level === 'beginner')
      .slice(0, count);
  }, [challenges]);

  // Get user's active challenges
  const getActiveChallenges = useCallback(() => {
    if (!currentUser) return [];
    
    return userProgress
      .filter(p => !p.is_completed)
      .map(p => ({
        ...p,
        challenge: challenges.find(c => c.id === p.challenge_id)
      }))
      .filter(p => p.challenge);
  }, [userProgress, challenges, currentUser]);

  // Get user's completed challenges
  const getCompletedChallenges = useCallback(() => {
    if (!currentUser) return [];
    
    return userProgress
      .filter(p => p.is_completed)
      .map(p => ({
        ...p,
        challenge: challenges.find(c => c.id === p.challenge_id)
      }))
      .filter(p => p.challenge);
  }, [userProgress, challenges, currentUser]);

  // Auto-load data on mount and when dependencies change
  useEffect(() => {
    if (autoFetch) {
      const loadData = async () => {
        const user = await loadCurrentUser();
        await loadChallenges();
        if (user && includeUserProgress) {
          await loadUserProgress(user);
        }
      };
      loadData();
    }
  }, [autoFetch, loadCurrentUser, loadChallenges, loadUserProgress, includeUserProgress]);

  // Apply filters when challenges or filters change
  useEffect(() => {
    applyFilters();
  }, [applyFilters]);

  // Get available categories and difficulty levels
  const availableCategories = [...new Set(challenges.map(challenge => challenge.category).filter(Boolean))];
  const availableDifficulties = [...new Set(challenges.map(challenge => challenge.difficulty_level).filter(Boolean))];

  return {
    // Data
    challenges,
    filteredChallenges,
    userProgress,
    currentUser,
    availableCategories,
    availableDifficulties,
    
    // State
    filters,
    isLoading,
    hasError,
    
    // Actions
    loadChallenges,
    loadUserProgress,
    updateFilters,
    clearFilters,
    joinChallenge,
    
    // Utilities
    getChallengeProgress,
    getChallengesByCategory,
    getRecommendedChallenges,
    getActiveChallenges,
    getCompletedChallenges,
    
    // Stats
    totalChallenges: challenges.length,
    filteredCount: filteredChallenges.length,
    activeCount: getActiveChallenges().length,
    completedCount: getCompletedChallenges().length
  };
}