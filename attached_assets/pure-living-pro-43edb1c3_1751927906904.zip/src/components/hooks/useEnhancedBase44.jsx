import { useState, useEffect, useCallback } from 'react';
import { enhancedBase44Client } from '@/components/api/EnhancedBase44Client';

// Custom hook for using the enhanced Base44 client
export function useEnhancedBase44(EntityClass, options = {}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const {
    autoFetch = false,
    filters = {},
    sortBy = "-created_date",
    limit = 50,
    cacheTTL,
    returnStaleOnError = true
  } = options;

  // Enhanced list method
  const list = useCallback(async (customSortBy = sortBy, customLimit = limit, customOptions = {}) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await enhancedBase44Client.list(
        EntityClass, 
        customSortBy, 
        customLimit, 
        { cacheTTL, returnStaleOnError, ...customOptions }
      );
      setData(result);
      return result;
    } catch (err) {
      setError(err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [EntityClass, sortBy, limit, cacheTTL, returnStaleOnError]);

  // Enhanced filter method
  const filter = useCallback(async (customFilters = filters, customSortBy = sortBy, customLimit = limit, customOptions = {}) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await enhancedBase44Client.filter(
        EntityClass, 
        customFilters, 
        customSortBy, 
        customLimit, 
        { cacheTTL, returnStaleOnError, ...customOptions }
      );
      setData(result);
      return result;
    } catch (err) {
      setError(err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [EntityClass, filters, sortBy, limit, cacheTTL, returnStaleOnError]);

  // Enhanced create method
  const create = useCallback(async (entityData, customOptions = {}) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await enhancedBase44Client.create(EntityClass, entityData, customOptions);
      return result;
    } catch (err) {
      setError(err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [EntityClass]);

  // Enhanced update method
  const update = useCallback(async (id, entityData, customOptions = {}) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await enhancedBase44Client.update(EntityClass, id, entityData, customOptions);
      return result;
    } catch (err) {
      setError(err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [EntityClass]);

  // Enhanced delete method
  const deleteEntity = useCallback(async (id, customOptions = {}) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await enhancedBase44Client.delete(EntityClass, id, customOptions);
      return result;
    } catch (err) {
      setError(err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [EntityClass]);

  // Refresh data (bypass cache)
  const refresh = useCallback(async () => {
    if (Object.keys(filters).length > 0) {
      return await filter(filters, sortBy, limit, { forceRefresh: true });
    } else {
      return await list(sortBy, limit, { forceRefresh: true });
    }
  }, [filters, sortBy, limit, filter, list]);

  // Auto-fetch on mount if enabled
  useEffect(() => {
    if (autoFetch) {
      if (Object.keys(filters).length > 0) {
        filter();
      } else {
        list();
      }
    }
  }, [autoFetch, filter, list]);

  return {
    data,
    loading,
    error,
    list,
    filter,
    create,
    update,
    delete: deleteEntity,
    refresh
  };
}

// Hook for cache management
export function useBase44Cache() {
  const getCacheStats = useCallback(() => {
    return enhancedBase44Client.getCacheStats();
  }, []);

  const clearCache = useCallback(() => {
    enhancedBase44Client.clearCache();
  }, []);

  const invalidateEntityCache = useCallback((entityName) => {
    enhancedBase44Client.invalidateEntityCache(entityName);
  }, []);

  const getErrorLog = useCallback(() => {
    return enhancedBase44Client.getErrorLog();
  }, []);

  return {
    getCacheStats,
    clearCache,
    invalidateEntityCache,
    getErrorLog
  };
}

export default useEnhancedBase44;