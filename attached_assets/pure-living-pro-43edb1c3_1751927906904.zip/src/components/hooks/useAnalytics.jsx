import { useContext, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { AnalyticsContext } from '../analytics/AnalyticsProvider';

// Main useAnalytics hook
export function useAnalytics() {
  const context = useContext(AnalyticsContext);
  if (!context) {
    // Return a no-op implementation if provider is not available
    return {
      track: () => {},
      trackPageView: () => {},
      trackUserEngagement: () => {},
      trackContentInteraction: () => {},
      trackEcommerce: () => {},
      trackError: () => {},
      getAnalyticsData: () => ({}),
      setConsent: () => {},
      isInitialized: false,
      isTrackingAllowed: false
    };
  }
  return context;
}

// Hook for automatic page view tracking
export function usePageTracking() {
  const location = useLocation();
  const { trackPageView, isInitialized } = useAnalytics();

  useEffect(() => {
    if (isInitialized) {
      trackPageView(location.pathname + location.search, document.title);
    }
  }, [location, isInitialized, trackPageView]);
}

// Hook for content interaction tracking
export function useContentTracking(contentType, contentId) {
  const { trackContentInteraction } = useAnalytics();

  const trackView = () => {
    trackContentInteraction(contentType, contentId, 'view');
  };

  const trackClick = () => {
    trackContentInteraction(contentType, contentId, 'click');
  };

  const trackShare = (platform) => {
    trackContentInteraction(contentType, contentId, 'share', { platform });
  };

  const trackEngagement = (action, metadata = {}) => {
    trackContentInteraction(contentType, contentId, action, metadata);
  };

  useEffect(() => {
    // Automatically track view when component mounts
    trackView();
  }, [contentType, contentId]);

  return {
    trackView,
    trackClick,
    trackShare,
    trackEngagement
  };
}

// Hook for e-commerce tracking
export function useEcommerceTracking() {
  const { trackEcommerce } = useAnalytics();

  const trackProductView = (product) => {
    trackEcommerce('view_item', [product]);
  };

  const trackProductClick = (product) => {
    trackEcommerce('select_item', [product]);
  };

  const trackAddToWishlist = (product) => {
    trackEcommerce('add_to_wishlist', [product]);
  };

  const trackPurchaseIntent = (product) => {
    trackEcommerce('begin_checkout', [product]);
  };

  const trackAffiliateClick = (product) => {
    trackEcommerce('affiliate_click', [product], {
      affiliate_link: product.affiliate_link,
      product_category: product.category
    });
  };

  return {
    trackProductView,
    trackProductClick,
    trackAddToWishlist,
    trackPurchaseIntent,
    trackAffiliateClick
  };
}

// Hook for user engagement tracking
export function useEngagementTracking() {
  const { trackUserEngagement } = useAnalytics();

  const trackButtonClick = (buttonName, category = 'UI') => {
    trackUserEngagement('click', category, buttonName);
  };

  const trackFormSubmission = (formName, success = true) => {
    trackUserEngagement('form_submit', 'Forms', formName, success ? 1 : 0);
  };

  const trackSearchQuery = (query, resultsCount) => {
    trackUserEngagement('search', 'Search', query, resultsCount);
  };

  const trackScrollDepth = (percentage) => {
    trackUserEngagement('scroll', 'Engagement', 'scroll_depth', percentage);
  };

  const trackTimeOnPage = (seconds) => {
    trackUserEngagement('time_on_page', 'Engagement', 'duration', seconds);
  };

  const trackNewsletterSignup = (success = true) => {
    trackUserEngagement('newsletter_signup', 'Marketing', 'subscription', success ? 1 : 0);
  };

  return {
    trackButtonClick,
    trackFormSubmission,
    trackSearchQuery,
    trackScrollDepth,
    trackTimeOnPage,
    trackNewsletterSignup
  };
}

// Hook for performance tracking
export function usePerformanceTracking() {
  const { track } = useAnalytics();

  const trackApiCall = (endpoint, duration, success = true) => {
    track('api_performance', {
      endpoint,
      duration,
      success,
      timestamp: Date.now()
    });
  };

  const trackComponentRender = (componentName, renderTime) => {
    track('component_performance', {
      component: componentName,
      render_time: renderTime,
      timestamp: Date.now()
    });
  };

  const trackUserAction = (action, duration) => {
    track('user_action_performance', {
      action,
      duration,
      timestamp: Date.now()
    });
  };

  return {
    trackApiCall,
    trackComponentRender,
    trackUserAction
  };
}

export default useAnalytics;