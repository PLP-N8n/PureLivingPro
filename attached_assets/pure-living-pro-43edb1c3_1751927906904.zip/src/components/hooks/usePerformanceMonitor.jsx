import { useState, useEffect, useRef, useCallback } from 'react';
import { useAnalytics } from '../analytics/AnalyticsProvider';

// Performance metrics configuration
const PERFORMANCE_CONFIG = {
  // Core Web Vitals thresholds
  thresholds: {
    lcp: { good: 2500, needsImprovement: 4000 }, // Largest Contentful Paint (ms)
    fid: { good: 100, needsImprovement: 300 },   // First Input Delay (ms)
    cls: { good: 0.1, needsImprovement: 0.25 },  // Cumulative Layout Shift
    ttfb: { good: 800, needsImprovement: 1800 }, // Time to First Byte (ms)
    fcp: { good: 1800, needsImprovement: 3000 }  // First Contentful Paint (ms)
  },
  
  // Monitoring intervals
  intervals: {
    memoryCheck: 30000,    // 30 seconds
    performanceLog: 60000, // 1 minute
    vitalsCheck: 5000      // 5 seconds
  },
  
  // Storage limits
  limits: {
    maxMetrics: 100,       // Maximum stored metrics
    maxErrors: 50,         // Maximum stored errors
    sessionDuration: 1800000 // 30 minutes
  }
};

class PerformanceTracker {
  constructor() {
    this.metrics = [];
    this.errors = [];
    this.observers = new Map();
    this.startTime = performance.now();
    this.sessionId = this.generateSessionId();
    this.isMonitoring = false;
  }

  generateSessionId() {
    return 'perf_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  // Initialize performance monitoring
  initialize() {
    if (this.isMonitoring) return;
    
    this.isMonitoring = true;
    this.initializeWebVitals();
    this.initializeResourceMonitoring();
    this.initializeMemoryMonitoring();
    this.initializeErrorTracking();
    
    console.log('Performance monitoring initialized');
  }

  // Initialize Core Web Vitals monitoring
  initializeWebVitals() {
    // Largest Contentful Paint (LCP)
    if ('PerformanceObserver' in window) {
      try {
        const lcpObserver = new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          const lastEntry = entries[entries.length - 1];
          
          this.recordMetric('LCP', {
            value: lastEntry.startTime,
            rating: this.getRating('lcp', lastEntry.startTime),
            timestamp: Date.now()
          });
        });
        
        lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });
        this.observers.set('lcp', lcpObserver);
      } catch (error) {
        console.warn('LCP monitoring not supported:', error);
      }

      // First Input Delay (FID)
      try {
        const fidObserver = new PerformanceObserver((entryList) => {
          const firstInput = entryList.getEntries()[0];
          const fidValue = firstInput.processingStart - firstInput.startTime;
          
          this.recordMetric('FID', {
            value: fidValue,
            rating: this.getRating('fid', fidValue),
            timestamp: Date.now()
          });
        });
        
        fidObserver.observe({ entryTypes: ['first-input'] });
        this.observers.set('fid', fidObserver);
      } catch (error) {
        console.warn('FID monitoring not supported:', error);
      }

      // Cumulative Layout Shift (CLS)
      try {
        let clsValue = 0;
        const clsObserver = new PerformanceObserver((entryList) => {
          for (const entry of entryList.getEntries()) {
            if (!entry.hadRecentInput) {
              clsValue += entry.value;
            }
          }
          
          this.recordMetric('CLS', {
            value: clsValue,
            rating: this.getRating('cls', clsValue),
            timestamp: Date.now()
          });
        });
        
        clsObserver.observe({ entryTypes: ['layout-shift'] });
        this.observers.set('cls', clsObserver);
      } catch (error) {
        console.warn('CLS monitoring not supported:', error);
      }

      // First Contentful Paint (FCP)
      try {
        const fcpObserver = new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          for (const entry of entries) {
            if (entry.name === 'first-contentful-paint') {
              this.recordMetric('FCP', {
                value: entry.startTime,
                rating: this.getRating('fcp', entry.startTime),
                timestamp: Date.now()
              });
            }
          }
        });
        
        fcpObserver.observe({ entryTypes: ['paint'] });
        this.observers.set('fcp', fcpObserver);
      } catch (error) {
        console.warn('FCP monitoring not supported:', error);
      }
    }

    // Time to First Byte (TTFB)
    if (window.performance && window.performance.timing) {
      const timing = window.performance.timing;
      const ttfb = timing.responseStart - timing.navigationStart;
      
      if (ttfb > 0) {
        this.recordMetric('TTFB', {
          value: ttfb,
          rating: this.getRating('ttfb', ttfb),
          timestamp: Date.now()
        });
      }
    }
  }

  // Initialize resource monitoring
  initializeResourceMonitoring() {
    if ('PerformanceObserver' in window) {
      try {
        const resourceObserver = new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          
          for (const entry of entries) {
            // Track slow resources
            if (entry.duration > 1000) { // Resources taking more than 1 second
              this.recordMetric('SLOW_RESOURCE', {
                name: entry.name,
                duration: entry.duration,
                size: entry.transferSize || entry.encodedBodySize,
                type: entry.initiatorType,
                timestamp: Date.now()
              });
            }
            
            // Track failed resources
            if (entry.transferSize === 0 && entry.encodedBodySize === 0) {
              this.recordError('RESOURCE_FAILED', {
                resource: entry.name,
                type: entry.initiatorType,
                timestamp: Date.now()
              });
            }
          }
        });
        
        resourceObserver.observe({ entryTypes: ['resource'] });
        this.observers.set('resource', resourceObserver);
      } catch (error) {
        console.warn('Resource monitoring not supported:', error);
      }
    }
  }

  // Initialize memory monitoring
  initializeMemoryMonitoring() {
    if (performance.memory) {
      const checkMemory = () => {
        const memory = performance.memory;
        const memoryUsage = {
          used: Math.round(memory.usedJSHeapSize / 1024 / 1024), // MB
          total: Math.round(memory.totalJSHeapSize / 1024 / 1024), // MB
          limit: Math.round(memory.jsHeapSizeLimit / 1024 / 1024), // MB
          timestamp: Date.now()
        };
        
        // Alert if memory usage is high
        const usagePercentage = (memoryUsage.used / memoryUsage.limit) * 100;
        if (usagePercentage > 80) {
          this.recordError('HIGH_MEMORY_USAGE', {
            ...memoryUsage,
            percentage: usagePercentage
          });
        }
        
        this.recordMetric('MEMORY', memoryUsage);
      };
      
      // Check memory immediately and then periodically
      checkMemory();
      this.memoryInterval = setInterval(checkMemory, PERFORMANCE_CONFIG.intervals.memoryCheck);
    }
  }

  // Initialize error tracking
  initializeErrorTracking() {
    // Global error handler
    window.addEventListener('error', (event) => {
      this.recordError('JAVASCRIPT_ERROR', {
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        stack: event.error?.stack,
        timestamp: Date.now()
      });
    });

    // Unhandled promise rejection handler
    window.addEventListener('unhandledrejection', (event) => {
      this.recordError('UNHANDLED_PROMISE_REJECTION', {
        reason: event.reason?.toString(),
        stack: event.reason?.stack,
        timestamp: Date.now()
      });
    });

    // Long task monitoring
    if ('PerformanceObserver' in window) {
      try {
        const longTaskObserver = new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          
          for (const entry of entries) {
            this.recordMetric('LONG_TASK', {
              duration: entry.duration,
              startTime: entry.startTime,
              timestamp: Date.now()
            });
          }
        });
        
        longTaskObserver.observe({ entryTypes: ['longtask'] });
        this.observers.set('longtask', longTaskObserver);
      } catch (error) {
        console.warn('Long task monitoring not supported:', error);
      }
    }
  }

  // Record performance metric
  recordMetric(type, data) {
    const metric = {
      type,
      ...data,
      sessionId: this.sessionId,
      url: window.location.href,
      userAgent: navigator.userAgent.substring(0, 100) // Truncate for storage
    };
    
    this.metrics.unshift(metric);
    
    // Limit stored metrics
    if (this.metrics.length > PERFORMANCE_CONFIG.limits.maxMetrics) {
      this.metrics = this.metrics.slice(0, PERFORMANCE_CONFIG.limits.maxMetrics);
    }
    
    // Store in localStorage for persistence
    this.saveToStorage();
  }

  // Record performance error
  recordError(type, data) {
    const error = {
      type,
      ...data,
      sessionId: this.sessionId,
      url: window.location.href,
      userAgent: navigator.userAgent.substring(0, 100)
    };
    
    this.errors.unshift(error);
    
    // Limit stored errors
    if (this.errors.length > PERFORMANCE_CONFIG.limits.maxErrors) {
      this.errors = this.errors.slice(0, PERFORMANCE_CONFIG.limits.maxErrors);
    }
    
    // Store in localStorage for persistence
    this.saveToStorage();
  }

  // Get performance rating based on thresholds
  getRating(metricType, value) {
    const threshold = PERFORMANCE_CONFIG.thresholds[metricType];
    if (!threshold) return 'unknown';
    
    if (value <= threshold.good) return 'good';
    if (value <= threshold.needsImprovement) return 'needs-improvement';
    return 'poor';
  }

  // Save metrics to localStorage
  saveToStorage() {
    try {
      const data = {
        metrics: this.metrics.slice(0, 20), // Store only recent metrics
        errors: this.errors.slice(0, 10),   // Store only recent errors
        sessionId: this.sessionId,
        lastUpdate: Date.now()
      };
      
      localStorage.setItem('performance_data', JSON.stringify(data));
    } catch (error) {
      console.warn('Failed to save performance data:', error);
    }
  }

  // Load metrics from localStorage
  loadFromStorage() {
    try {
      const stored = localStorage.getItem('performance_data');
      if (stored) {
        const data = JSON.parse(stored);
        
        // Only load if session is recent (within 30 minutes)
        if (Date.now() - data.lastUpdate < PERFORMANCE_CONFIG.limits.sessionDuration) {
          this.metrics = data.metrics || [];
          this.errors = data.errors || [];
        }
      }
    } catch (error) {
      console.warn('Failed to load performance data:', error);
    }
  }

  // Get current performance summary
  getPerformanceSummary() {
    const recentMetrics = this.metrics.slice(0, 10);
    const recentErrors = this.errors.slice(0, 5);
    
    // Calculate averages for key metrics
    const webVitals = {};
    ['LCP', 'FID', 'CLS', 'TTFB', 'FCP'].forEach(type => {
      const metrics = recentMetrics.filter(m => m.type === type);
      if (metrics.length > 0) {
        const values = metrics.map(m => m.value);
        webVitals[type] = {
          current: values[0],
          average: values.reduce((a, b) => a + b, 0) / values.length,
          rating: metrics[0].rating,
          count: metrics.length
        };
      }
    });
    
    // Memory usage
    const memoryMetrics = recentMetrics.filter(m => m.type === 'MEMORY');
    const currentMemory = memoryMetrics[0];
    
    return {
      webVitals,
      memory: currentMemory,
      errors: recentErrors,
      sessionDuration: Date.now() - this.startTime,
      totalMetrics: this.metrics.length,
      totalErrors: this.errors.length,
      lastUpdate: Date.now()
    };
  }

  // Cleanup observers and intervals
  cleanup() {
    this.observers.forEach(observer => {
      try {
        observer.disconnect();
      } catch (error) {
        console.warn('Failed to disconnect observer:', error);
      }
    });
    
    if (this.memoryInterval) {
      clearInterval(this.memoryInterval);
    }
    
    this.isMonitoring = false;
  }
}

// Create global performance tracker instance
const performanceTracker = new PerformanceTracker();

export function usePerformanceMonitor() {
  const [performanceData, setPerformanceData] = useState(null);
  const [isMonitoring, setIsMonitoring] = useState(false);
  const updateInterval = useRef(null);
  const { track } = useAnalytics();

  // Initialize monitoring
  const startMonitoring = useCallback(() => {
    if (isMonitoring) return;
    
    performanceTracker.loadFromStorage();
    performanceTracker.initialize();
    setIsMonitoring(true);
    
    // Update performance data periodically
    updateInterval.current = setInterval(() => {
      const summary = performanceTracker.getPerformanceSummary();
      setPerformanceData(summary);
      
      // Send critical metrics to analytics
      if (summary.webVitals.LCP?.rating === 'poor' || 
          summary.webVitals.FID?.rating === 'poor' || 
          summary.webVitals.CLS?.rating === 'poor') {
        track('performance_issue', {
          lcp: summary.webVitals.LCP?.current,
          fid: summary.webVitals.FID?.current,
          cls: summary.webVitals.CLS?.current,
          url: window.location.href
        });
      }
    }, PERFORMANCE_CONFIG.intervals.performanceLog);
    
    // Get initial data
    const initialSummary = performanceTracker.getPerformanceSummary();
    setPerformanceData(initialSummary);
    
  }, [isMonitoring, track]);

  // Stop monitoring
  const stopMonitoring = useCallback(() => {
    if (!isMonitoring) return;
    
    performanceTracker.cleanup();
    setIsMonitoring(false);
    
    if (updateInterval.current) {
      clearInterval(updateInterval.current);
      updateInterval.current = null;
    }
  }, [isMonitoring]);

  // Record custom performance metric
  const recordMetric = useCallback((type, data) => {
    performanceTracker.recordMetric(type, data);
  }, []);

  // Record custom performance error
  const recordError = useCallback((type, data) => {
    performanceTracker.recordError(type, data);
  }, []);

  // Get detailed metrics
  const getDetailedMetrics = useCallback(() => {
    return {
      allMetrics: performanceTracker.metrics,
      allErrors: performanceTracker.errors,
      sessionId: performanceTracker.sessionId
    };
  }, []);

  // Auto-start monitoring on mount
  useEffect(() => {
    startMonitoring();
    
    return () => {
      stopMonitoring();
    };
  }, [startMonitoring, stopMonitoring]);

  return {
    // State
    performanceData,
    isMonitoring,
    
    // Actions
    startMonitoring,
    stopMonitoring,
    recordMetric,
    recordError,
    getDetailedMetrics,
    
    // Utilities
    getPerformanceSummary: performanceTracker.getPerformanceSummary.bind(performanceTracker),
    clearData: () => {
      localStorage.removeItem('performance_data');
      performanceTracker.metrics = [];
      performanceTracker.errors = [];
      setPerformanceData(null);
    }
  };
}

export default usePerformanceMonitor;