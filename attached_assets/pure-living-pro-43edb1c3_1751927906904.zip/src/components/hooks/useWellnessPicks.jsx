import { useState, useEffect, useCallback } from 'react';
import { WellnessPick } from '@/api/entities';
import { useEnhancedBase44 } from './useEnhancedBase44';

export function useWellnessPicks(options = {}) {
  const {
    initialFilters = {},
    sortBy = "-created_date",
    limit = 50,
    autoFetch = true
  } = options;

  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [filters, setFilters] = useState(initialFilters);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [priceRange, setPriceRange] = useState({ min: 0, max: 1000 });

  // Use enhanced Base44 client
  const { 
    filter: filterProducts,
    list: listProducts 
  } = useEnhancedBase44(WellnessPick, {
    cacheTTL: 300000, // 5 minutes
    returnStaleOnError: true
  });

  // Load products from API
  const loadProducts = useCallback(async (customFilters = {}) => {
    setIsLoading(true);
    setHasError(false);
    
    try {
      let result;
      const queryFilters = { 
        ...filters, 
        ...customFilters 
      };

      if (Object.keys(queryFilters).length > 0) {
        result = await filterProducts(queryFilters, sortBy, limit);
      } else {
        result = await listProducts(sortBy, limit);
      }

      const validProducts = (result || []).map(product => ({
        ...product,
        // Ensure price fields are numbers
        original_price: parseFloat(product.original_price) || 0,
        discounted_price: parseFloat(product.discounted_price) || parseFloat(product.original_price) || 0,
        rating: parseFloat(product.rating) || 0,
        review_count: parseInt(product.review_count) || 0
      }));

      setProducts(validProducts);
      
      // Update price range based on loaded products
      if (validProducts.length > 0) {
        const prices = validProducts.map(p => p.discounted_price || p.original_price);
        setPriceRange({
          min: Math.min(...prices),
          max: Math.max(...prices)
        });
      }

      return validProducts;
    } catch (error) {
      console.error('Error loading wellness picks:', error);
      setHasError(true);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [filters, sortBy, limit, filterProducts, listProducts]);

  // Apply filters and search to products
  const applyFiltersAndSearch = useCallback(() => {
    let filtered = [...products];

    // Apply category filter
    if (filters.category && filters.category !== 'all') {
      filtered = filtered.filter(product => product.category === filters.category);
    }

    // Apply badge filter
    if (filters.badge && filters.badge !== 'all') {
      filtered = filtered.filter(product => product.badge === filters.badge);
    }

    // Apply price range filter
    if (filters.minPrice !== undefined || filters.maxPrice !== undefined) {
      filtered = filtered.filter(product => {
        const price = product.discounted_price || product.original_price;
        const minPrice = filters.minPrice || 0;
        const maxPrice = filters.maxPrice || Infinity;
        return price >= minPrice && price <= maxPrice;
      });
    }

    // Apply rating filter
    if (filters.minRating) {
      filtered = filtered.filter(product => product.rating >= filters.minRating);
    }

    // Apply search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(product => 
        product.name?.toLowerCase().includes(query) ||
        product.description?.toLowerCase().includes(query) ||
        product.benefits?.some(benefit => benefit.toLowerCase().includes(query))
      );
    }

    // Apply featured filter
    if (filters.featured === true) {
      filtered = filtered.filter(product => product.featured === true);
    }

    // Sort filtered results
    filtered.sort((a, b) => {
      switch (sortBy) {
        case '-created_date':
          return new Date(b.created_date) - new Date(a.created_date);
        case 'created_date':
          return new Date(a.created_date) - new Date(b.created_date);
        case 'name':
          return a.name.localeCompare(b.name);
        case '-name':
          return b.name.localeCompare(a.name);
        case 'price':
          return (a.discounted_price || a.original_price) - (b.discounted_price || b.original_price);
        case '-price':
          return (b.discounted_price || b.original_price) - (a.discounted_price || a.original_price);
        case 'rating':
          return a.rating - b.rating;
        case '-rating':
          return b.rating - a.rating;
        case 'popularity':
          return b.review_count - a.review_count;
        default:
          return 0;
      }
    });

    setFilteredProducts(filtered);
  }, [products, filters, searchQuery, sortBy]);

  // Update filters
  const updateFilters = useCallback((newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  }, []);

  // Clear filters
  const clearFilters = useCallback(() => {
    setFilters(initialFilters);
    setSearchQuery('');
  }, [initialFilters]);

  // Get products by category
  const getProductsByCategory = useCallback((category) => {
    return products.filter(product => product.category === category);
  }, [products]);

  // Get featured products
  const getFeaturedProducts = useCallback((count = 4) => {
    return products
      .filter(product => product.featured === true)
      .slice(0, count);
  }, [products]);

  // Get products by badge
  const getProductsByBadge = useCallback((badge, count = 4) => {
    return products
      .filter(product => product.badge === badge)
      .slice(0, count);
  }, [products]);

  // Get top rated products
  const getTopRatedProducts = useCallback((count = 4) => {
    return products
      .filter(product => product.rating >= 4)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, count);
  }, [products]);

  // Get budget-friendly products
  const getBudgetProducts = useCallback((maxPrice = 30, count = 4) => {
    return products
      .filter(product => (product.discounted_price || product.original_price) <= maxPrice)
      .sort((a, b) => (a.discounted_price || a.original_price) - (b.discounted_price || b.original_price))
      .slice(0, count);
  }, [products]);

  // Auto-load products on mount and when dependencies change
  useEffect(() => {
    if (autoFetch) {
      loadProducts();
    }
  }, [loadProducts, autoFetch]);

  // Apply filters when products or filters change
  useEffect(() => {
    applyFiltersAndSearch();
  }, [applyFiltersAndSearch]);

  // Get available categories and badges
  const availableCategories = [...new Set(products.map(product => product.category).filter(Boolean))];
  const availableBadges = [...new Set(products.map(product => product.badge).filter(Boolean))];

  return {
    // Data
    products,
    filteredProducts,
    availableCategories,
    availableBadges,
    priceRange,
    
    // State
    filters,
    searchQuery,
    isLoading,
    hasError,
    
    // Actions
    loadProducts,
    updateFilters,
    clearFilters,
    setSearchQuery,
    
    // Utilities
    getProductsByCategory,
    getFeaturedProducts,
    getProductsByBadge,
    getTopRatedProducts,
    getBudgetProducts,
    
    // Stats
    totalProducts: products.length,
    filteredCount: filteredProducts.length
  };
}