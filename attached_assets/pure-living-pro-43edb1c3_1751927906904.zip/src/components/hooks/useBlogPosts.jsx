import { useState, useEffect, useCallback } from 'react';
import { BlogPost } from '@/api/entities';
import { useEnhancedBase44 } from './useEnhancedBase44';

export function useBlogPosts(options = {}) {
  const {
    initialFilters = {},
    sortBy = "-created_date",
    limit = 50,
    autoFetch = true
  } = options;

  const [posts, setPosts] = useState([]);
  const [filteredPosts, setFilteredPosts] = useState([]);
  const [filters, setFilters] = useState(initialFilters);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalItems: 0
  });

  // Use enhanced Base44 client
  const { 
    filter: filterPosts,
    list: listPosts 
  } = useEnhancedBase44(BlogPost, {
    cacheTTL: 300000, // 5 minutes
    returnStaleOnError: true
  });

  // Load posts from API
  const loadPosts = useCallback(async (customFilters = {}) => {
    setIsLoading(true);
    setHasError(false);
    
    try {
      let result;
      const queryFilters = { 
        published: true, 
        ...filters, 
        ...customFilters 
      };

      // If we have specific filters, use filter method, otherwise use list
      if (Object.keys(queryFilters).length > 1) { // More than just 'published'
        result = await filterPosts(queryFilters, sortBy, limit);
      } else {
        result = await listPosts(sortBy, limit);
        // Filter published posts client-side as fallback
        result = result.filter(post => post.published !== false);
      }

      setPosts(result || []);
      return result || [];
    } catch (error) {
      console.error('Error loading blog posts:', error);
      setHasError(true);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [filters, sortBy, limit, filterPosts, listPosts]);

  // Apply filters and search to posts
  const applyFiltersAndSearch = useCallback(() => {
    let filtered = [...posts];

    // Apply category filter
    if (filters.category && filters.category !== 'all') {
      filtered = filtered.filter(post => post.category === filters.category);
    }

    // Apply search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(post => 
        post.title?.toLowerCase().includes(query) ||
        post.excerpt?.toLowerCase().includes(query) ||
        post.content?.toLowerCase().includes(query) ||
        (post.tags && post.tags.some(tag => tag.toLowerCase().includes(query)))
      );
    }

    // Apply premium filter if specified
    if (filters.premium === true) {
      filtered = filtered.filter(post => post.is_premium === true);
    } else if (filters.premium === false) {
      filtered = filtered.filter(post => post.is_premium !== true);
    }

    // Sort filtered results
    filtered.sort((a, b) => {
      switch (sortBy) {
        case '-created_date':
          return new Date(b.created_date) - new Date(a.created_date);
        case 'created_date':
          return new Date(a.created_date) - new Date(b.created_date);
        case 'title':
          return a.title.localeCompare(b.title);
        case '-title':
          return b.title.localeCompare(a.title);
        case 'read_time':
          return (a.read_time || 0) - (b.read_time || 0);
        case '-read_time':
          return (b.read_time || 0) - (a.read_time || 0);
        default:
          return 0;
      }
    });

    setFilteredPosts(filtered);
    
    // Update pagination
    setPagination({
      currentPage: 1,
      totalPages: Math.ceil(filtered.length / 12), // 12 posts per page
      totalItems: filtered.length
    });
  }, [posts, filters, searchQuery, sortBy]);

  // Update filters
  const updateFilters = useCallback((newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  }, []);

  // Clear filters
  const clearFilters = useCallback(() => {
    setFilters(initialFilters);
    setSearchQuery('');
  }, [initialFilters]);

  // Get posts by category
  const getPostsByCategory = useCallback((category) => {
    return posts.filter(post => post.category === category);
  }, [posts]);

  // Get featured posts
  const getFeaturedPosts = useCallback((count = 3) => {
    return posts
      .filter(post => post.featured === true)
      .slice(0, count);
  }, [posts]);

  // Get recent posts
  const getRecentPosts = useCallback((count = 5) => {
    return posts
      .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
      .slice(0, count);
  }, [posts]);

  // Get related posts
  const getRelatedPosts = useCallback((currentPost, count = 3) => {
    if (!currentPost) return [];
    
    return posts
      .filter(post => 
        post.id !== currentPost.id && 
        (post.category === currentPost.category ||
         (post.tags && currentPost.tags && 
          post.tags.some(tag => currentPost.tags.includes(tag))))
      )
      .slice(0, count);
  }, [posts]);

  // Auto-load posts on mount and when dependencies change
  useEffect(() => {
    if (autoFetch) {
      loadPosts();
    }
  }, [loadPosts, autoFetch]);

  // Apply filters when posts or filters change
  useEffect(() => {
    applyFiltersAndSearch();
  }, [applyFiltersAndSearch]);

  // Get available categories
  const availableCategories = [...new Set(posts.map(post => post.category).filter(Boolean))];

  return {
    // Data
    posts,
    filteredPosts,
    availableCategories,
    
    // State
    filters,
    searchQuery,
    isLoading,
    hasError,
    pagination,
    
    // Actions
    loadPosts,
    updateFilters,
    clearFilters,
    setSearchQuery,
    
    // Utilities
    getPostsByCategory,
    getFeaturedPosts,
    getRecentPosts,
    getRelatedPosts,
    
    // Stats
    totalPosts: posts.length,
    filteredCount: filteredPosts.length
  };
}