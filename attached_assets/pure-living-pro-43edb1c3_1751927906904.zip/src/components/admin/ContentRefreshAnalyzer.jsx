import React, { useState, useEffect } from 'react';
import { BlogPost } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  Loader2,
  Archive,
  Edit
} from "lucide-react";
import { format } from "date-fns";

export default function ContentRefreshAnalyzer() {
  const [posts, setPosts] = useState([]);
  const [analysisResults, setAnalysisResults] = useState([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    try {
      const allPosts = await BlogPost.list();
      setPosts(allPosts);
    } catch (error) {
      console.error("Error loading posts:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const analyzeContent = async () => {
    if (posts.length === 0) return;

    setIsAnalyzing(true);
    setAnalysisResults([]);

    try {
      // Analyze posts in batches to avoid overwhelming the API
      const batchSize = 3;
      const results = [];

      for (let i = 0; i < Math.min(posts.length, 6); i += batchSize) {
        const batch = posts.slice(i, i + batchSize);
        const batchPromises = batch.map(post => analyzePost(post));
        const batchResults = await Promise.all(batchPromises);
        results.push(...batchResults);
      }

      setAnalysisResults(results);
    } catch (error) {
      console.error("Error analyzing content:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const analyzePost = async (post) => {
    try {
      const daysSinceCreated = Math.floor((Date.now() - new Date(post.created_date).getTime()) / (1000 * 60 * 60 * 24));
      const daysSinceUpdated = post.updated_date ? 
        Math.floor((Date.now() - new Date(post.updated_date).getTime()) / (1000 * 60 * 60 * 24)) : 
        daysSinceCreated;

      const prompt = `As a content strategist for a wellness blog, analyze this article and provide recommendations for whether it needs updating, refreshing, or archiving.

Article Details:
- Title: ${post.title}
- Created: ${daysSinceCreated} days ago
- Last Updated: ${daysSinceUpdated} days ago
- Content Preview: ${post.content ? post.content.substring(0, 500) : post.excerpt || 'No content available'}

Consider:
- Content freshness and relevance
- Whether facts/statistics might be outdated
- Seasonal relevance
- SEO optimization potential
- Overall quality and engagement potential

Return a JSON object with:
{
  "recommendation": "refresh|update|archive|keep",
  "priority": "high|medium|low",
  "reason": "Brief explanation of the recommendation",
  "specific_actions": ["action1", "action2", "action3"],
  "estimated_hours": <number of hours estimated for the work>
}`;

      const schema = {
        type: "object",
        properties: {
          recommendation: { type: "string", enum: ["refresh", "update", "archive", "keep"] },
          priority: { type: "string", enum: ["high", "medium", "low"] },
          reason: { type: "string" },
          specific_actions: { type: "array", items: { type: "string" } },
          estimated_hours: { type: "number" }
        },
        required: ["recommendation", "priority", "reason", "specific_actions", "estimated_hours"]
      };

      const result = await InvokeLLM({
        prompt,
        response_json_schema: schema
      });

      return { ...result, post };
    } catch (error) {
      console.error(`Error analyzing post ${post.id}:`, error);
      return {
        post,
        recommendation: "keep",
        priority: "low",
        reason: "Analysis failed",
        specific_actions: [],
        estimated_hours: 0
      };
    }
  };

  const getRecommendationColor = (recommendation) => {
    switch (recommendation) {
      case 'refresh': return 'bg-yellow-100 text-yellow-800';
      case 'update': return 'bg-blue-100 text-blue-800';
      case 'archive': return 'bg-red-100 text-red-800';
      case 'keep': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRecommendationIcon = (recommendation) => {
    switch (recommendation) {
      case 'refresh': return <RefreshCw className="w-4 h-4" />;
      case 'update': return <Edit className="w-4 h-4" />;
      case 'archive': return <Archive className="w-4 h-4" />;
      case 'keep': return <CheckCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  if (isLoading) {
    return (
      <div className="pt-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-sage-200 rounded w-1/3"></div>
          <div className="h-4 bg-sage-200 rounded w-2/3"></div>
          <div className="h-10 bg-sage-200 rounded w-1/4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-6">
      <h3 className="text-lg font-semibold text-sage-700 mb-2">Content Refresh Analysis</h3>
      <p className="text-sm text-sage-600 mb-4">
        AI-powered analysis to identify content that needs updating, refreshing, or archiving.
      </p>
      
      <div className="flex items-center justify-between mb-6">
        <div className="text-sm text-sage-600">
          Found {posts.length} published articles
        </div>
        <Button 
          onClick={analyzeContent} 
          disabled={isAnalyzing || posts.length === 0}
          className="bg-sage-600 hover:bg-sage-700"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <RefreshCw className="w-4 h-4 mr-2" />
              Analyze Content
            </>
          )}
        </Button>
      </div>

      {analysisResults.length > 0 && (
        <div className="space-y-4">
          <h4 className="font-semibold text-sage-700 mb-4">Analysis Results</h4>
          
          {analysisResults.map((result, index) => (
            <Card key={result.post.id} className="organic-border">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h5 className="font-semibold text-sage-700 mb-2">
                      {result.post.title}
                    </h5>
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge className={getRecommendationColor(result.recommendation)}>
                        {getRecommendationIcon(result.recommendation)}
                        <span className="ml-1 capitalize">{result.recommendation}</span>
                      </Badge>
                      <Badge className={getPriorityColor(result.priority)}>
                        {result.priority} priority
                      </Badge>
                      <span className="text-sm text-sage-500">
                        Est. {result.estimated_hours}h work
                      </span>
                    </div>
                    <p className="text-sm text-sage-600 mb-3">
                      {result.reason}
                    </p>
                  </div>
                  <div className="text-right text-sm text-sage-500">
                    Created: {format(new Date(result.post.created_date), "MMM d, yyyy")}
                  </div>
                </div>
                
                {result.specific_actions.length > 0 && (
                  <div>
                    <h6 className="font-medium text-sage-700 mb-2">Recommended Actions:</h6>
                    <ul className="list-disc list-inside space-y-1 text-sm text-sage-600">
                      {result.specific_actions.map((action, actionIndex) => (
                        <li key={actionIndex}>{action}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
          
          <div className="mt-6 p-4 bg-sage-50 rounded-lg">
            <h5 className="font-semibold text-sage-700 mb-2">Summary</h5>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div className="text-center">
                <div className="text-2xl font-bold text-sage-700">
                  {analysisResults.filter(r => r.recommendation === 'refresh').length}
                </div>
                <div className="text-sage-600">Need Refresh</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-sage-700">
                  {analysisResults.filter(r => r.recommendation === 'update').length}
                </div>
                <div className="text-sage-600">Need Update</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-sage-700">
                  {analysisResults.filter(r => r.recommendation === 'archive').length}
                </div>
                <div className="text-sage-600">Should Archive</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-sage-700">
                  {analysisResults.reduce((sum, r) => sum + r.estimated_hours, 0)}
                </div>
                <div className="text-sage-600">Total Hours</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}