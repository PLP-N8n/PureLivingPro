import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BlogPost, WellnessPick, Comment, User } from "@/api/entities";
import {
  BarChart3,
  FileText,
  ShoppingBag,
  MessageSquare,
  Users,
  TrendingUp,
  Eye,
  Heart,
  Bot,
  Sparkles,
  ArrowRight,
  Plus,
  Settings
} from "lucide-react";
import { motion } from "framer-motion";

const QuickActionCard = ({ title, description, icon: Icon, onClick, variant = "default", badge }) => (
  <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
    <Card 
      className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-0 bg-card/80 backdrop-blur-sm ${
        variant === "primary" ? "bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20" : ""
      } ${variant === "ai" ? "bg-gradient-to-br from-purple-500/10 to-blue-500/5 border-purple-200" : ""}`}
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
              variant === "primary" ? "bg-primary text-primary-foreground" :
              variant === "ai" ? "bg-gradient-to-br from-purple-500 to-blue-500 text-white" :
              "bg-muted text-muted-foreground"
            }`}>
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1 flex items-center">
                {title}
                {badge && <Badge className="ml-2 text-xs">{badge}</Badge>}
              </h3>
              <p className="text-sm text-muted-foreground">{description}</p>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-muted-foreground" />
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

export default function AdminDashboard({ onTabChange }) {
  const [stats, setStats] = useState({
    posts: 0,
    products: 0,
    comments: 0,
    users: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadDashboardStats();
  }, []);

  const loadDashboardStats = async () => {
    try {
      const [posts, products, comments, users] = await Promise.all([
        BlogPost.list("-created_date", 100).catch(() => []),
        WellnessPick.list("-created_date", 100).catch(() => []),
        Comment.list("-created_date", 100).catch(() => []),
        User.list("-created_date", 100).catch(() => [])
      ]);

      setStats({
        posts: posts?.length || 0,
        products: products?.length || 0,
        comments: comments?.length || 0,
        users: users?.length || 0
      });
    } catch (error) {
      console.error("Error loading dashboard stats:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const quickActions = [
    {
      title: "AI Tools Hub",
      description: "Access powerful AI content creation and analysis tools",
      icon: Bot,
      onClick: () => onTabChange("ai-tools"),
      variant: "ai",
      badge: "New"
    },
    {
      title: "Create Blog Post",
      description: "Write and publish new wellness articles",
      icon: Plus,
      onClick: () => onTabChange("blog"),
      variant: "primary"
    },
    {
      title: "Add Wellness Pick",
      description: "Curate new products for recommendations",
      icon: ShoppingBag,
      onClick: () => onTabChange("products"),
      variant: "default"
    },
    {
      title: "Manage Comments",
      description: "Review and moderate user comments",
      icon: MessageSquare,
      onClick: () => onTabChange("comments"),
      variant: "default"
    }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">Manage your wellness platform</p>
        </div>
        <Badge variant="outline" className="text-sm">
          <Settings className="w-3 h-3 mr-1" />
          Administrator
        </Badge>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-0 bg-card/80 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Blog Posts</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isLoading ? "..." : stats.posts}</div>
            <p className="text-xs text-muted-foreground">
              Published articles
            </p>
          </CardContent>
        </Card>
        
        <Card className="border-0 bg-card/80 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Wellness Picks</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isLoading ? "..." : stats.products}</div>
            <p className="text-xs text-muted-foreground">
              Curated products
            </p>
          </CardContent>
        </Card>
        
        <Card className="border-0 bg-card/80 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Comments</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isLoading ? "..." : stats.comments}</div>
            <p className="text-xs text-muted-foreground">
              User interactions
            </p>
          </CardContent>
        </Card>
        
        <Card className="border-0 bg-card/80 backdrop-blur-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{isLoading ? "..." : stats.users}</div>
            <p className="text-xs text-muted-foreground">
              Community members
            </p>
          </CardContent>
        </Card>
      </div>

      {/* AI Tools Spotlight */}
      <Card className="border-0 bg-gradient-to-br from-purple-500/10 via-blue-500/5 to-transparent backdrop-blur-sm">
        <CardHeader>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-xl">AI-Powered Content Tools</CardTitle>
              <p className="text-muted-foreground">Leverage artificial intelligence to streamline your workflow</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-background/50 p-4 rounded-lg">
              <h4 className="font-semibold text-foreground mb-2">Content Generation</h4>
              <p className="text-sm text-muted-foreground">AI-powered blog post creation with SEO optimization</p>
            </div>
            <div className="bg-background/50 p-4 rounded-lg">
              <h4 className="font-semibold text-foreground mb-2">Quality Analysis</h4>
              <p className="text-sm text-muted-foreground">Analyze readability, engagement, and performance</p>
            </div>
            <div className="bg-background/50 p-4 rounded-lg">
              <h4 className="font-semibold text-foreground mb-2">Performance Insights</h4>
              <p className="text-sm text-muted-foreground">Track affiliate performance and revenue optimization</p>
            </div>
          </div>
          <Button 
            onClick={() => onTabChange("ai-tools")} 
            className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
          >
            <Bot className="w-4 h-4 mr-2" />
            Explore AI Tools Hub
          </Button>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-foreground">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {quickActions.map((action, index) => (
            <QuickActionCard
              key={index}
              {...action}
            />
          ))}
        </div>
      </div>

      {/* Recent Activity Placeholder */}
      <Card className="border-0 bg-card/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="w-5 h-5 mr-2" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Activity tracking coming soon</p>
            <p className="text-sm text-muted-foreground mt-2">
              Monitor content performance, user engagement, and platform analytics
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}