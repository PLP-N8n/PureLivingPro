import React, { useState, useEffect } from 'react';
import { WellnessPick } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { X, Search } from 'lucide-react';

export default function AffiliateProductSelector({ onClose, onSelectProduct }) {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const loadProducts = async () => {
      try {
        const data = await WellnessPick.list("-created_date", 200);
        setProducts(data);
        setFilteredProducts(data);
      } catch (error) {
        console.error("Error loading wellness picks:", error);
      } finally {
        setIsLoading(false);
      }
    };
    loadProducts();
  }, []);

  useEffect(() => {
    if (!searchQuery) {
      setFilteredProducts(products);
      return;
    }
    const lowercasedQuery = searchQuery.toLowerCase();
    const filtered = products.filter(p => 
      p.name?.toLowerCase().includes(lowercasedQuery) ||
      p.description?.toLowerCase().includes(lowercasedQuery) ||
      p.category?.toLowerCase().includes(lowercasedQuery)
    );
    setFilteredProducts(filtered);
  }, [searchQuery, products]);

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[80vh] flex flex-col">
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="text-lg font-semibold">Select an Affiliate Product</h3>
          <Button variant="ghost" size="sm" onClick={onClose}><X className="w-4 h-4" /></Button>
        </div>
        <div className="p-4 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <CardContent className="flex-1 overflow-y-auto p-4 space-y-3">
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)
          ) : (
            filteredProducts.map(product => (
              <div key={product.id} className="flex items-center gap-4 p-2 border rounded-lg">
                <img src={product.image_url} alt={product.name} className="w-16 h-16 object-cover rounded-md" />
                <div className="flex-1">
                  <p className="font-semibold">{product.name}</p>
                  <p className="text-sm text-gray-500">{product.category}</p>
                </div>
                <Button size="sm" onClick={() => onSelectProduct(product)}>Insert</Button>
              </div>
            ))
          )}
          {!isLoading && filteredProducts.length === 0 && (
            <p className="text-center text-gray-500">No products found.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}