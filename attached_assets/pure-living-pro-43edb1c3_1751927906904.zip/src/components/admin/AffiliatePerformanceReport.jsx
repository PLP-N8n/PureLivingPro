import React, { useState, useEffect } from 'react';
import { BlogPost, WellnessPick } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  ExternalLink, 
  DollarSign, 
  BarChart3,
  Target,
  MousePointer
} from "lucide-react";

export default function AffiliatePerformanceReport() {
  const [performanceData, setPerformanceData] = useState({
    totalClicks: 0,
    topPerformingArticles: [],
    topPerformingProducts: [],
    categoryPerformance: []
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPerformanceData();
  }, []);

  const loadPerformanceData = async () => {
    try {
      const [posts, products] = await Promise.all([
        BlogPost.list(),
        WellnessPick.list()
      ]);

      // Simulate affiliate performance data
      const postsWithClicks = posts.map(post => ({
        ...post,
        affiliate_clicks: Math.floor(Math.random() * 200) + 10,
        estimated_revenue: (Math.floor(Math.random() * 500) + 50) / 100
      })).sort((a, b) => b.affiliate_clicks - a.affiliate_clicks);

      const productsWithClicks = products.map(product => ({
        ...product,
        affiliate_clicks: Math.floor(Math.random() * 150) + 5,
        estimated_revenue: (Math.floor(Math.random() * 300) + 30) / 100
      })).sort((a, b) => b.affiliate_clicks - a.affiliate_clicks);

      // Calculate category performance
      const categoryStats = {};
      postsWithClicks.forEach(post => {
        const category = post.category || 'General';
        if (!categoryStats[category]) {
          categoryStats[category] = { clicks: 0, revenue: 0 };
        }
        categoryStats[category].clicks += post.affiliate_clicks;
        categoryStats[category].revenue += post.estimated_revenue;
      });

      const categoryPerformance = Object.entries(categoryStats)
        .map(([category, stats]) => ({ category, ...stats }))
        .sort((a, b) => b.clicks - a.clicks);

      const totalClicks = postsWithClicks.reduce((sum, post) => sum + post.affiliate_clicks, 0) +
                         productsWithClicks.reduce((sum, product) => sum + product.affiliate_clicks, 0);

      setPerformanceData({
        totalClicks,
        topPerformingArticles: postsWithClicks.slice(0, 5),
        topPerformingProducts: productsWithClicks.slice(0, 5),
        categoryPerformance: categoryPerformance.slice(0, 5)
      });

    } catch (error) {
      console.error("Error loading performance data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="organic-border">
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-8 bg-sage-200 rounded mb-2"></div>
                  <div className="h-4 bg-sage-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const totalRevenue = performanceData.topPerformingArticles.reduce((sum, article) => sum + article.estimated_revenue, 0) +
                      performanceData.topPerformingProducts.reduce((sum, product) => sum + product.estimated_revenue, 0);

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="organic-border">
          <CardContent className="p-6 text-center">
            <MousePointer className="w-8 h-8 text-sage-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-sage-700">{performanceData.totalClicks}</div>
            <div className="text-sm text-sage-600">Total Clicks</div>
          </CardContent>
        </Card>
        <Card className="organic-border">
          <CardContent className="p-6 text-center">
            <DollarSign className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-sage-700">£{totalRevenue.toFixed(2)}</div>
            <div className="text-sm text-sage-600">Est. Revenue</div>
          </CardContent>
        </Card>
        <Card className="organic-border">
          <CardContent className="p-6 text-center">
            <Target className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-sage-700">{((totalRevenue / performanceData.totalClicks) * 100).toFixed(2)}p</div>
            <div className="text-sm text-sage-600">Avg. EPC</div>
          </CardContent>
        </Card>
        <Card className="organic-border">
          <CardContent className="p-6 text-center">
            <BarChart3 className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-sage-700">{performanceData.categoryPerformance.length}</div>
            <div className="text-sm text-sage-600">Active Categories</div>
          </CardContent>
        </Card>
      </div>

      {/* Top Performing Articles */}
      <Card className="organic-border">
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-sage-600" />
            Top Performing Articles
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {performanceData.topPerformingArticles.map((article, index) => (
              <div key={article.id} className="flex items-center justify-between p-4 bg-sage-50 rounded-lg">
                <div className="flex-1">
                  <h4 className="font-semibold text-sage-700 mb-1">
                    {article.title}
                  </h4>
                  <div className="flex items-center space-x-4 text-sm text-sage-600">
                    <span className="flex items-center">
                      <MousePointer className="w-3 h-3 mr-1" />
                      {article.affiliate_clicks} clicks
                    </span>
                    <span className="flex items-center">
                      <DollarSign className="w-3 h-3 mr-1" />
                      £{article.estimated_revenue.toFixed(2)}
                    </span>
                  </div>
                </div>
                <Badge className="bg-sage-600 text-white">
                  #{index + 1}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Top Performing Products */}
      <Card className="organic-border">
        <CardHeader>
          <CardTitle className="flex items-center">
            <ExternalLink className="w-5 h-5 mr-2 text-sage-600" />
            Top Performing Products
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {performanceData.topPerformingProducts.map((product, index) => (
              <div key={product.id} className="flex items-center justify-between p-4 bg-sage-50 rounded-lg">
                <div className="flex items-center space-x-4 flex-1">
                  <div className="w-12 h-12 bg-sage-200 rounded-lg overflow-hidden">
                    {product.image_url && (
                      <img 
                        src={product.image_url} 
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  <div>
                    <h4 className="font-semibold text-sage-700 mb-1">
                      {product.name}
                    </h4>
                    <div className="flex items-center space-x-4 text-sm text-sage-600">
                      <span className="flex items-center">
                        <MousePointer className="w-3 h-3 mr-1" />
                        {product.affiliate_clicks} clicks
                      </span>
                      <span className="flex items-center">
                        <DollarSign className="w-3 h-3 mr-1" />
                        £{product.estimated_revenue.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
                <Badge className="bg-sage-600 text-white">
                  #{index + 1}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Category Performance */}
      <Card className="organic-border">
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 text-sage-600" />
            Performance by Category
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {performanceData.categoryPerformance.map((category, index) => (
              <div key={category.category} className="flex items-center justify-between p-4 bg-sage-50 rounded-lg">
                <div>
                  <h4 className="font-semibold text-sage-700 mb-1">
                    {category.category}
                  </h4>
                  <div className="flex items-center space-x-4 text-sm text-sage-600">
                    <span className="flex items-center">
                      <MousePointer className="w-3 h-3 mr-1" />
                      {category.clicks} clicks
                    </span>
                    <span className="flex items-center">
                      <DollarSign className="w-3 h-3 mr-1" />
                      £{category.revenue.toFixed(2)}
                    </span>
                  </div>
                </div>
                <Badge variant="outline" className="border-sage-300 text-sage-600">
                  {((category.clicks / performanceData.totalClicks) * 100).toFixed(1)}%
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}