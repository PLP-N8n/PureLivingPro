import React, { useState, useEffect } from "react";
import { Comment, BlogPost } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Check, Trash2, MessageSquare, Eye, Clock, ThumbsUp } from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function CommentManager() {
  const [comments, setComments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [posts, setPosts] = useState({});

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [commentData, postData] = await Promise.all([
        Comment.list("-created_date", 200),
        BlogPost.list()
      ]);
      
      const commentsList = commentData || [];
      setComments(commentsList);
      
      const postsMap = (postData || []).reduce((acc, post) => {
        acc[post.id] = post;
        return acc;
      }, {});
      setPosts(postsMap);

    } catch (error) {
      console.error("Error loading comments:", error);
      setComments([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApprove = async (commentId) => {
    try {
      await Comment.update(commentId, { approved: true });
      loadData();
    } catch (error) {
      console.error("Error approving comment:", error);
    }
  };

  const handleDelete = async (commentId) => {
    if (window.confirm("Are you sure you want to delete this comment?")) {
      try {
        await Comment.delete(commentId);
        loadData();
      } catch (error) {
        console.error("Error deleting comment:", error);
      }
    }
  };
  
  const getPostTitle = (postId) => {
    return posts[postId]?.title || "Unknown Post";
  };
  
  const getPostLink = (postId) => {
    const post = posts[postId];
    if (post) {
      return `${createPageUrl("BlogPost")}/${post.slug || post.id}`;
    }
    return createPageUrl("Blog");
  }

  return (
    <div className="space-y-6">
      <Card className="organic-border premium-shadow">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-sage-700 flex items-center">
            <MessageSquare className="w-6 h-6 mr-3" />
            Comment Moderation
          </CardTitle>
          <p className="text-sage-600 mt-2">Review and manage community discussions.</p>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-24 w-full organic-border" />)}
            </div>
          ) : comments.length === 0 ? (
            <div className="text-center py-12">
              <MessageSquare className="w-16 h-16 text-sage-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-sage-600">No comments to moderate.</h3>
            </div>
          ) : (
            <div className="space-y-4">
              {comments.map((comment) => (
                <div key={comment.id} className="p-4 border border-sage-200 organic-border hover:bg-sage-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="font-semibold text-sage-700">{comment.created_by}</span>
                        <span className="text-xs text-sage-500 flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {format(new Date(comment.created_date), "MMM d, yyyy")}
                        </span>
                        {comment.approved ? (
                          <Badge className="bg-green-100 text-green-800">Approved</Badge>
                        ) : (
                          <Badge variant="destructive">Pending</Badge>
                        )}
                        <span className="text-xs text-sage-500 flex items-center">
                          <ThumbsUp className="w-3 h-3 mr-1" />
                          {comment.likes || 0} Likes
                        </span>
                      </div>
                      <p className="text-sage-600 mb-3 whitespace-pre-wrap">{comment.content}</p>
                      <p className="text-xs text-sage-500">
                        On post: <Link to={getPostLink(comment.post_id)} target="_blank" className="underline hover:text-sage-700">{getPostTitle(comment.post_id)}</Link>
                      </p>
                    </div>
                    <div className="flex items-center space-x-2 ml-4">
                      {!comment.approved && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleApprove(comment.id)}
                          className="border-green-300 text-green-700 hover:bg-green-50"
                        >
                          <Check className="w-4 h-4 mr-1" />
                          Approve
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDelete(comment.id)}
                        className="border-red-300 text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}