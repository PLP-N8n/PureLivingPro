import React, { useState } from 'react';
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Accessibility } from "lucide-react";
import ResultCard from './ResultCard';

export default function ContentAccessibilityChecker() {
  const [accessibilityContent, setAccessibilityContent] = useState("");
  const [accessibilityResult, setAccessibilityResult] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleAccessibilityCheck = async () => {
    if (!accessibilityContent.trim()) return;
    
    setIsLoading(true);
    setAccessibilityResult("");
    try {
      const prompt = `You are an expert on web accessibility (WCAG 2.2 AA). Analyze the following HTML or Markdown content for accessibility issues and provide a report.

Content to Analyze:
---
${accessibilityContent}
---

Please identify issues related to:
- Missing or non-descriptive alt text for images.
- Improper heading structure (e.g., skipping levels).
- Vague link text like "click here".
- Color contrast problems mentioned in text.
- Readability and use of plain language.

For each issue found, provide a clear description, the problematic snippet, and a specific recommendation for how to fix it. If no major issues are found, confirm that the content appears to be accessible.`;

      const result = await InvokeLLM({
        prompt: prompt,
        add_context_from_internet: false
      });
      setAccessibilityResult(result);
    } catch (error) {
      console.error("Error with accessibility check:", error);
      setAccessibilityResult("Sorry, I encountered an error performing the accessibility check.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="pt-6">
      <h3 className="text-lg font-semibold text-sage-700 mb-2">Content Accessibility Checker</h3>
      <p className="text-sm text-sage-600 mb-4">Check your content for WCAG compliance issues and get recommendations for fixes.</p>
      <div className="space-y-4">
        <Textarea
          placeholder="Paste your HTML or Markdown content here..."
          value={accessibilityContent}
          onChange={(e) => setAccessibilityContent(e.target.value)}
          rows={8}
          disabled={isLoading}
        />
        <Button onClick={handleAccessibilityCheck} disabled={isLoading}>
          {isLoading ? <Loader2 className="animate-spin" /> : "Check Accessibility"}
        </Button>
        {accessibilityResult && (
          <ResultCard title="Accessibility Report" icon={<Accessibility className="w-5 h-5 mr-2" />}>
             <pre className="whitespace-pre-wrap font-sans">{accessibilityResult}</pre>
          </ResultCard>
        )}
      </div>
    </div>
  );
}