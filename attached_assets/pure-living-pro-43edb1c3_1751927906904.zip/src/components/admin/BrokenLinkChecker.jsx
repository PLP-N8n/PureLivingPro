import React, { useState, useEffect } from "react";
import { BlogPost } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, HeartCrack, Link as LinkIcon, CheckCircle, AlertTriangle, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";

export default function BrokenLinkChecker() {
    const [isLoading, setIsLoading] = useState(false);
    const [scanResults, setScanResults] = useState([]);
    const [allPosts, setAllPosts] = useState([]);

    useEffect(() => {
        // Pre-load posts to avoid fetching them multiple times
        const loadPosts = async () => {
            const posts = await BlogPost.list("-created_date", 200);
            setAllPosts(posts);
        };
        loadPosts();
    }, []);

    const extractLinksFromMarkdown = (markdown, postId) => {
        const links = [];
        const regex = /\[([^\]]+)\]\(([^)]+)\)/g;
        let match;
        while ((match = regex.exec(markdown)) !== null) {
            links.push({
                text: match[1],
                url: match[2],
                sourcePostId: postId
            });
        }
        return links;
    };

    const handleScan = async () => {
        setIsLoading(true);
        setScanResults([]);

        let allLinks = [];
        allPosts.forEach(post => {
            if (post.content) {
                allLinks = allLinks.concat(extractLinksFromMarkdown(post.content, post.id));
            }
        });

        const postSlugs = new Set(allPosts.map(p => p.slug).filter(Boolean));
        const postIds = new Set(allPosts.map(p => p.id));
        const staticPages = new Set(["Home", "Blog", "WellnessPicks", "Premium", "Challenges", "About", "Contact"]);

        const results = allLinks.map(link => {
            let status = "unknown";
            let statusText = "Unknown";
            let type = "external";

            if (link.url.startsWith("http://") || link.url.startsWith("https://")) {
                // External link - can't verify automatically
                status = "external";
                statusText = "External - Verify Manually";
            } else if (link.url.startsWith("/")) {
                // Internal link
                type = "internal";
                const path = link.url.split('/').pop().split('?')[0];
                const pageName = path.charAt(0).toUpperCase() + path.slice(1);
                
                if (staticPages.has(pageName) || postSlugs.has(path) || postIds.has(path)) {
                    status = "ok";
                    statusText = "OK";
                } else {
                    status = "broken";
                    statusText = "Broken Link";
                }
            } else {
                status = "unknown";
                statusText = "Unknown Format";
            }

            return { ...link, status, statusText, type };
        });

        setScanResults(results);
        setIsLoading(false);
    };

    const getStatusBadge = (status) => {
        switch (status) {
            case "ok":
                return <Badge variant="default" className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" /> OK</Badge>;
            case "broken":
                return <Badge variant="destructive"><AlertTriangle className="w-3 h-3 mr-1" /> Broken</Badge>;
            case "external":
                return <Badge variant="secondary"><ExternalLink className="w-3 h-3 mr-1" /> External</Badge>;
            default:
                return <Badge variant="outline">Unknown</Badge>;
        }
    };
    
    const getSourcePostTitle = (postId) => {
        const post = allPosts.find(p => p.id === postId);
        return post ? post.title : "Unknown Post";
    };

    return (
        <div className="space-y-6">
            <CardHeader className="p-0">
                <CardTitle className="flex items-center text-2xl">
                    <HeartCrack className="w-6 h-6 mr-3 text-red-500" />
                    Broken Link Checker
                </CardTitle>
                <p className="text-sage-600">Scan all blog posts for broken or problematic links.</p>
            </CardHeader>
            
            <Button onClick={handleScan} disabled={isLoading || allPosts.length === 0}>
                {isLoading ? (
                    <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Scanning...
                    </>
                ) : (
                    "Scan All Posts for Broken Links"
                )}
            </Button>

            {scanResults.length > 0 && (
                <Card>
                    <CardHeader>
                        <CardTitle>Scan Results</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Link URL</TableHead>
                                    <TableHead>Link Text</TableHead>
                                    <TableHead>Source Article</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {scanResults.map((result, index) => (
                                    <TableRow key={index}>
                                        <TableCell>{getStatusBadge(result.status)}</TableCell>
                                        <TableCell>
                                            <a href={result.url} target="_blank" rel="noopener noreferrer" className="text-sage-600 hover:underline truncate block max-w-xs" title={result.url}>
                                                {result.url}
                                            </a>
                                        </TableCell>
                                        <TableCell>{result.text}</TableCell>
                                        <TableCell>
                                            <Link to={createPageUrl(`BlogPost/${result.sourcePostId}`)} className="text-sage-600 hover:underline">
                                                {getSourcePostTitle(result.sourcePostId)}
                                            </Link>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}