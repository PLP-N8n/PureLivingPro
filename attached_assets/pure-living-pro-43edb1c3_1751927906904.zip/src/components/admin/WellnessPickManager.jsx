
import React, { useState, useEffect } from "react";
import { WellnessPick } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  ExternalLink,
  Heart,
  Star,
  Loader2
} from "lucide-react";
import { format } from "date-fns";

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

import { uploadToCloudinary } from "@/components/shared/cloudinary";

const categoryColors = {
  "supplements": "bg-blue-100 text-blue-800",
  "skincare": "bg-pink-100 text-pink-800",
  "fitness-equipment": "bg-orange-100 text-orange-800",
  "books": "bg-purple-100 text-purple-800",
  "meditation-tools": "bg-indigo-100 text-indigo-800",
  "kitchen-wellness": "bg-green-100 text-green-800",
  "aromatherapy": "bg-amber-100 text-amber-800",
  "natural-remedies": "bg-sage-100 text-sage-800"
};

const badgeColors = {
  "editors-pick": "bg-sage-500 text-white",
  "best-seller": "bg-amber-500 text-white",
  "budget-buy": "bg-blue-500 text-white",
  "trending": "bg-purple-500 text-white"
};

export default function WellnessPickManager() {
  const [picks, setPicks] = useState([]);
  const [filteredPicks, setFilteredPicks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [currentPick, setCurrentPick] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    loadPicks();
  }, []);

  useEffect(() => {
    const filtered = (picks || []).filter(pick =>
      pick.name?.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredPicks(filtered);
  }, [searchQuery, picks]);

  const loadPicks = async () => {
    setIsLoading(true);
    try {
      const data = await WellnessPick.list("-created_date", 100);
      const pickList = data || [];
      setPicks(pickList);
      setFilteredPicks(pickList);
    } catch (error) {
      console.error("Error loading picks:", error);
      setPicks([]);
      setFilteredPicks([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!currentPick) return;

    try {
      if (currentPick.id) {
        await WellnessPick.update(currentPick.id, currentPick);
      } else {
        await WellnessPick.create(currentPick);
      }
      setIsDialogOpen(false);
      setCurrentPick(null);
      loadPicks();
    } catch (error) {
      console.error("Error saving pick:", error);
    }
  };

  const handleDelete = async (pickId) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      try {
        await WellnessPick.delete(pickId);
        loadPicks();
      } catch (error) {
        console.error("Error deleting product:", error);
      }
    }
  };

  const handleEdit = (pick) => {
    setCurrentPick(pick);
    setIsDialogOpen(true);
  };

  const handleAddNew = () => {
    setCurrentPick({}); // Initialize with empty object for new pick
    setIsDialogOpen(true);
  };

  const handleFieldChange = (field, value) => {
    setCurrentPick(prev => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const imageUrl = await uploadToCloudinary(file);
      handleFieldChange('image_url', imageUrl);
    } catch (error) {
      console.error("Error uploading to Cloudinary:", error);
      alert("Failed to upload image. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="pt-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <CardTitle className="text-2xl font-bold text-sage-700 flex items-center">
            <Heart className="w-6 h-6 mr-3" />
            Wellness Picks
          </CardTitle>
          <p className="text-sage-600 mt-2">Manage your curated product recommendations</p>
        </div>
        <Button
          onClick={handleAddNew}
          className="bg-sage-600 hover:bg-sage-700 text-white organic-border"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Product
        </Button>
      </div>

      <Card className="premium-shadow organic-border">
        <CardContent>
          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-sage-400" />
            <Input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 organic-border"
            />
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-sage-50 p-4 organic-border text-center">
              <div className="text-2xl font-bold text-sage-700">{picks.length}</div>
              <div className="text-sm text-sage-600">Total Products</div>
            </div>
            <div className="bg-green-50 p-4 organic-border text-center">
              <div className="text-2xl font-bold text-green-700">
                {picks.filter(p => p.featured).length}
              </div>
              <div className="text-sm text-green-600">Featured</div>
            </div>
            <div className="bg-amber-50 p-4 organic-border text-center">
              <div className="text-2xl font-bold text-amber-700">
                {picks.filter(p => p.badge === 'best-seller').length}
              </div>
              <div className="text-sm text-amber-600">Best Sellers</div>
            </div>
            <div className="bg-purple-50 p-4 organic-border text-center">
              <div className="text-2xl font-bold text-purple-700">
                {picks.filter(p => p.badge === 'editors-pick').length}
              </div>
              <div className="text-sm text-purple-600">Editor's Picks</div>
            </div>
          </div>

          {/* Products List */}
          {isLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="p-4 border border-sage-200 organic-border">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Skeleton className="h-16 w-16 organic-border" />
                      <div className="flex-1">
                        <Skeleton className="h-6 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-1/2 mb-2" />
                        <Skeleton className="h-4 w-1/4" />
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Skeleton className="h-8 w-16" />
                      <Skeleton className="h-8 w-16" />
                      <Skeleton className="h-8 w-16" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredPicks.length === 0 ? (
            <div className="text-center py-12">
              <Heart className="w-16 h-16 text-sage-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-sage-600 mb-2">
                {searchQuery ? "No products found" : "No products yet"}
              </h3>
              <p className="text-sage-500 mb-4">
                {searchQuery ? "Try adjusting your search criteria" : "Add your first wellness pick to get started"}
              </p>
              {!searchQuery && (
                <Button
                  onClick={handleAddNew}
                  className="bg-sage-600 hover:bg-sage-700 text-white organic-border"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Product
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredPicks.map((pick) => (
                <div key={pick.id} className="p-4 border border-sage-200 organic-border hover:bg-sage-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 flex-1">
                      {/* Product Image */}
                      <div className="w-16 h-16 bg-sage-100 organic-border overflow-hidden flex-shrink-0">
                        {pick.image_url ? (
                          <img
                            src={pick.image_url}
                            alt={pick.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Heart className="w-6 h-6 text-sage-400" />
                          </div>
                        )}
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="font-semibold text-sage-700 text-lg">
                            {pick.name}
                          </h3>
                          <div className="flex items-center space-x-2">
                            {pick.category && (
                              <Badge className={`${categoryColors[pick.category]} organic-border`}>
                                {pick.category.replace('-', ' ')}
                              </Badge>
                            )}
                            {pick.badge && (
                              <Badge className={`${badgeColors[pick.badge]} organic-border`}>
                                {pick.badge.replace('-', ' ')}
                              </Badge>
                            )}
                            {pick.featured && (
                              <Badge className="bg-yellow-100 text-yellow-800 organic-border">
                                Featured
                              </Badge>
                            )}
                          </div>
                        </div>
                        <p className="text-sage-600 text-sm mb-2 line-clamp-2">
                          {pick.description || "No description available"}
                        </p>
                        <div className="flex items-center space-x-4 text-xs text-sage-500">
                          <span>Added: {format(new Date(pick.created_date), "MMM d, yyyy")}</span>
                          {pick.rating && (
                            <div className="flex items-center">
                              <Star className="w-3 h-3 text-yellow-400 fill-current mr-1" />
                              <span>{pick.rating}/5</span>
                              {pick.review_count && (
                                <span className="ml-1">({pick.review_count} reviews)</span>
                              )}
                            </div>
                          )}
                          {(pick.discounted_price || pick.original_price) && (
                            <span className="font-medium">
                              £{pick.discounted_price || pick.original_price}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 ml-4">
                      {pick.affiliate_link && (
                        <a
                          href={pick.affiliate_link}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-sage-300 text-sage-700 hover:bg-sage-50"
                          >
                            <ExternalLink className="w-4 h-4 mr-1" />
                            View
                          </Button>
                        </a>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(pick)}
                        className="border-blue-300 text-blue-700 hover:bg-blue-50"
                      >
                        <Edit className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDelete(pick.id)}
                        className="border-red-300 text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{currentPick?.id ? "Edit Wellness Pick" : "Add New Wellness Pick"}</DialogTitle>
          </DialogHeader>
          {currentPick && (
            <div className="grid gap-4 py-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input id="name" value={currentPick.name || ""} onChange={(e) => handleFieldChange('name', e.target.value)} />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" value={currentPick.description || ""} onChange={(e) => handleFieldChange('description', e.target.value)} />
              </div>
              <div>
                <Label htmlFor="image_url">Image URL</Label>
                <div className="mt-2 flex items-center gap-4">
                    <Input
                      id="image_url"
                      value={currentPick.image_url || ""}
                      onChange={(e) => handleFieldChange('image_url', e.target.value)}
                      placeholder="Paste URL or upload"
                      disabled={isUploading}
                      className="flex-grow"
                    />
                    <div className="relative">
                      <Button asChild variant="outline" type="button"> {/* Added type="button" to prevent form submission */}
                        <label htmlFor="pick-image-upload" className="cursor-pointer px-4 py-2 text-sm font-medium">
                          {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Upload"}
                        </label>
                      </Button>
                      <Input id="pick-image-upload" type="file" className="sr-only" onChange={handleImageUpload} accept="image/*" disabled={isUploading} />
                    </div>
                </div>
                {currentPick.image_url && (
                    <div className="mt-4">
                      <img src={currentPick.image_url} alt="Preview" className="w-32 h-32 object-cover organic-border" />
                    </div>
                )}
              </div>
              <div>
                <Label htmlFor="category">Category</Label>
                <Select value={currentPick.category || ""} onValueChange={(value) => handleFieldChange('category', value)}>
                  <SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="supplements">Supplements</SelectItem>
                    <SelectItem value="skincare">Skincare</SelectItem>
                    <SelectItem value="fitness-equipment">Fitness Equipment</SelectItem>
                    <SelectItem value="books">Books</SelectItem>
                    <SelectItem value="meditation-tools">Meditation Tools</SelectItem>
                    <SelectItem value="kitchen-wellness">Kitchen Wellness</SelectItem>
                    <SelectItem value="aromatherapy">Aromatherapy</SelectItem>
                    <SelectItem value="natural-remedies">Natural Remedies</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="affiliate_link">Affiliate Link</Label>
                <Input id="affiliate_link" value={currentPick.affiliate_link || ""} onChange={(e) => handleFieldChange('affiliate_link', e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="original_price">Original Price (£)</Label>
                  <Input id="original_price" type="number" value={currentPick.original_price || ""} onChange={(e) => handleFieldChange('original_price', parseFloat(e.target.value) || null)} />
                </div>
                <div>
                  <Label htmlFor="discounted_price">Discounted Price (£)</Label>
                  <Input id="discounted_price" type="number" value={currentPick.discounted_price || ""} onChange={(e) => handleFieldChange('discounted_price', parseFloat(e.target.value) || null)} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                 <div>
                  <Label htmlFor="rating">Rating (1-5)</Label>
                  <Input id="rating" type="number" min="1" max="5" value={currentPick.rating || ""} onChange={(e) => handleFieldChange('rating', parseInt(e.target.value) || null)} />
                </div>
                <div>
                  <Label htmlFor="review_count">Review Count</Label>
                  <Input id="review_count" type="number" value={currentPick.review_count || ""} onChange={(e) => handleFieldChange('review_count', parseInt(e.target.value) || null)} />
                </div>
              </div>
              <div>
                <Label htmlFor="badge">Badge</Label>
                <Select value={currentPick.badge || ""} onValueChange={(value) => handleFieldChange('badge', value)}>
                  <SelectTrigger><SelectValue placeholder="Select a badge" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>None</SelectItem> {/* Option to clear badge */}
                    <SelectItem value="editors-pick">Editor's Pick</SelectItem>
                    <SelectItem value="best-seller">Best Seller</SelectItem>
                    <SelectItem value="budget-buy">Budget Buy</SelectItem>
                    <SelectItem value="trending">Trending</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="featured" checked={currentPick.featured || false} onCheckedChange={(checked) => handleFieldChange('featured', checked)} />
                <Label htmlFor="featured">Feature on homepage</Label>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
