import React, { useState, useEffect } from "react";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import { BlogPost } from "@/api/entities";
import { WellnessPick } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Loader2, ShoppingBag } from "lucide-react";
import { InvokeLLM } from "@/api/integrations";
import AffiliateProductSelector from './AffiliateProductSelector';
import { uploadToCloudinary } from "@/components/shared/cloudinary";

export default function ContentEditor({ post, onSave, onCancel }) {
  const [editedPost, setEditedPost] = useState(post || {});
  const [isGenerating, setIsGenerating] = useState(false);
  const [isAffiliateSelectorOpen, setIsAffiliateSelectorOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const quillRef = React.useRef(null);

  useEffect(() => {
    setEditedPost(post || {});
  }, [post]);

  const handleFieldChange = (field, value) => {
    setEditedPost(prev => ({ ...prev, [field]: value }));
  };

  const handleContentChange = (value) => {
    handleFieldChange("content", value);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const imageUrl = await uploadToCloudinary(file);
      handleFieldChange("featured_image", imageUrl);
    } catch (error) {
      console.error("Error uploading to Cloudinary:", error);
      alert("Failed to upload image. Please try again.");
    } finally {
      setIsUploading(false);
      e.target.value = null;
    }
  };

  const generateArticle = async () => {
    if (!editedPost.title) {
      alert("Please provide a title for the article before generating.");
      return;
    }
    
    setIsGenerating(true);
    try {
      const prompt = `You are an expert wellness blogger for "Pure Living Pro". Your writing style is authoritative, empathetic, and evidence-based.
      
      Generate a full, high-quality blog post based on the following topic.

      Topic: "${editedPost.title}"
      
      Instructions:
      1.  **Create a logical outline:** Start with an introduction that hooks the reader, followed by several main points in a logical sequence, and conclude with a summary and actionable takeaways.
      2.  **Write the full article:** Flesh out each point from the outline. The tone should be professional yet accessible.
      3.  **Format in Markdown:** Use Markdown for headings, lists, and bold text.
      4.  **Include an Excerpt:** Write a short, compelling excerpt (2-3 sentences) summarizing the article.
      5.  **Suggest Tags:** Provide 5-7 relevant SEO tags.
      6.  **Estimate Read Time:** Calculate an estimated read time in minutes.

      Return a single JSON object with the following fields: "content" (the full article in Markdown), "excerpt" (string), "tags" (array of strings), "read_time" (number).`;

      const schema = {
        type: "object",
        properties: {
          content: { type: "string" },
          excerpt: { type: "string" },
          tags: { type: "array", items: { type: "string" } },
          read_time: { type: "number" }
        },
        required: ["content", "excerpt", "tags", "read_time"]
      };

      const result = await InvokeLLM({
        prompt,
        response_json_schema: schema
      });
      
      setEditedPost(prev => ({
        ...prev,
        content: result.content,
        excerpt: result.excerpt,
        tags: result.tags,
        read_time: result.read_time
      }));

    } catch (error) {
      console.error("Error generating article:", error);
      alert("Failed to generate article. Please check the console for details.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleInsertProduct = (product) => {
    const editor = quillRef.current.getEditor();
    const range = editor.getSelection(true);
    
    const productHTML = `
      <div style="border: 1px solid #e2e8f0; border-radius: 1rem; padding: 1rem; margin: 1rem 0; background-color: #f8fafc; display: flex; align-items: center; gap: 1rem;">
        <img src="${product.image_url}" alt="${product.name}" style="width: 120px; height: 120px; object-fit: cover; border-radius: 0.5rem;" />
        <div style="flex: 1;">
          <h4 style="margin-top: 0; margin-bottom: 0.5rem;">${product.name}</h4>
          <p style="margin-top: 0; margin-bottom: 1rem; font-size: 0.9rem; color: #4b5563;">${product.description}</p>
          <a href="${product.affiliate_link}" target="_blank" rel="noopener noreferrer" style="display: inline-block; background-color: #4a7c59; color: white; padding: 0.5rem 1rem; border-radius: 0.5rem; text-decoration: none;">View Product</a>
        </div>
      </div>
    `;
    
    editor.clipboard.dangerouslyPasteHTML(range.index, productHTML);
    setIsAffiliateSelectorOpen(false);
  };

  return (
    <Card className="premium-shadow organic-border border-0 bg-white/50 dark:bg-gray-800/30 mt-6">
      <CardHeader>
        <CardTitle>{editedPost.id ? "Edit Article" : "Create New Article"}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-sage-700 dark:text-sage-300 mb-1">Title</label>
              <Input id="title" value={editedPost.title || ""} onChange={(e) => handleFieldChange("title", e.target.value)} />
            </div>
            <div>
              <label htmlFor="slug" className="block text-sm font-medium text-sage-700 dark:text-sage-300 mb-1">Slug</label>
              <Input id="slug" value={editedPost.slug || ""} onChange={(e) => handleFieldChange("slug", e.target.value)} />
            </div>
          </div>
          
          <Button onClick={generateArticle} disabled={isGenerating || !editedPost.title} className="w-fit">
            {isGenerating ? <Loader2 className="animate-spin mr-2" /> : <Sparkles className="mr-2 h-4 w-4" />}
            {isGenerating ? "Generating Content..." : "Generate Full Article from Title"}
          </Button>

          <div>
            <label htmlFor="excerpt" className="block text-sm font-medium text-sage-700 dark:text-sage-300 mb-1">Excerpt</label>
            <Textarea id="excerpt" value={editedPost.excerpt || ""} onChange={(e) => handleFieldChange("excerpt", e.target.value)} />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-sage-700 dark:text-sage-300 mb-1">Content</label>
            <div className="bg-white rounded-xl">
              <ReactQuill 
                ref={quillRef} 
                theme="snow" 
                value={editedPost.content || ""} 
                onChange={handleContentChange} 
                className="h-96 mb-12"
                modules={{
                  toolbar: [
                    [{ 'header': [1, 2, 3, false] }],
                    ['bold', 'italic', 'underline', 'strike', 'blockquote'],
                    [{'list': 'ordered'}, {'list': 'bullet'}],
                    ['link', 'image'],
                    ['clean']
                  ],
                }}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-sage-700 dark:text-sage-300 mb-1">Category</label>
              <Select value={editedPost.category || ""} onValueChange={(value) => handleFieldChange("category", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="nutrition">Nutrition</SelectItem>
                  <SelectItem value="meditation-mindfulness">Meditation & Mindfulness</SelectItem>
                  <SelectItem value="fitness">Fitness</SelectItem>
                  <SelectItem value="natural-remedies">Natural Remedies</SelectItem>
                  <SelectItem value="healthy-recipes">Healthy Recipes</SelectItem>
                  <SelectItem value="supplements">Supplements</SelectItem>
                  <SelectItem value="skin-selfcare">Skin & Self-care</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label htmlFor="read_time" className="block text-sm font-medium text-sage-700 dark:text-sage-300 mb-1">Read Time (minutes)</label>
              <Input id="read_time" type="number" value={editedPost.read_time || ""} onChange={(e) => handleFieldChange("read_time", parseInt(e.target.value, 10) || 0)} />
            </div>
            <div>
              <label htmlFor="tags" className="block text-sm font-medium text-sage-700 dark:text-sage-300 mb-1">Tags (comma-separated)</label>
              <Input id="tags" value={Array.isArray(editedPost.tags) ? editedPost.tags.join(', ') : ''} onChange={(e) => handleFieldChange("tags", e.target.value.split(',').map(tag => tag.trim()))} />
            </div>
          </div>

          <div>
            <label htmlFor="featured-image" className="block text-sm font-medium text-sage-700 dark:text-sage-300 mb-1">Featured Image</label>
            <div className="mt-2 flex items-center gap-4">
              <Input
                id="featured-image-url"
                placeholder="Image URL or upload a new one"
                value={editedPost.featured_image || ""}
                onChange={(e) => handleFieldChange("featured_image", e.target.value)}
                className="flex-grow"
                disabled={isUploading}
              />
              <div className="relative">
                <Button asChild variant="outline" disabled={isUploading}>
                  <label htmlFor="image-upload" className="cursor-pointer px-4 py-2 flex items-center justify-center">
                    {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Upload"}
                  </label>
                </Button>
                <Input id="image-upload" type="file" className="sr-only" onChange={handleImageUpload} accept="image/*" disabled={isUploading} />
              </div>
            </div>
            {editedPost.featured_image && (
              <div className="mt-4">
                <img src={editedPost.featured_image} alt="Preview" className="w-48 h-auto organic-border object-cover" />
              </div>
            )}
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-sage-700 dark:text-sage-300">Affiliate Products</h3>
            <p className="text-sm text-sage-600 dark:text-sage-400">Embed affiliate products from your Wellness Picks library directly into this article.</p>
            <Button variant="outline" onClick={() => setIsAffiliateSelectorOpen(true)} className="w-fit">
              <ShoppingBag className="mr-2 h-4 w-4" />
              Insert Affiliate Product
            </Button>
            {isAffiliateSelectorOpen && (
              <AffiliateProductSelector 
                onClose={() => setIsAffiliateSelectorOpen(false)} 
                onSelectProduct={handleInsertProduct}
              />
            )}
          </div>

          <div className="flex items-center space-x-4 pt-4 border-t border-sage-200 dark:border-gray-700">
            <div className="flex items-center space-x-2">
              <Checkbox id="published" checked={editedPost.published || false} onCheckedChange={(checked) => handleFieldChange("published", checked)} />
              <label htmlFor="published">Published</label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="is_premium" checked={editedPost.is_premium || false} onCheckedChange={(checked) => handleFieldChange("is_premium", checked)} />
              <label htmlFor="is_premium">Premium Content</label>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end gap-4 mt-8">
          <Button variant="ghost" onClick={onCancel}>Cancel</Button>
          <Button onClick={() => onSave(editedPost)}>Save Post</Button>
        </div>
      </CardContent>
    </Card>
  );
}