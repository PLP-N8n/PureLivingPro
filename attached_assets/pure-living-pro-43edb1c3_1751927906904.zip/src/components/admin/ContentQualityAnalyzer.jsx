import React, { useState } from 'react';
import { InvokeLLM } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import ResultCard from './ResultCard';

export default function ContentQualityAnalyzer() {
  const [qualityContent, setQualityContent] = useState("");
  const [qualityResult, setQualityResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleQualityCheck = async () => {
    if (!qualityContent.trim()) return;

    setIsLoading(true);
    setQualityResult(null);
    try {
      const prompt = `You are a content quality analyst for a wellness blog. Analyze the following article and provide a quality score based on several metrics.

Article Content:
---
${qualityContent}
---

Please evaluate the content and return a JSON object with the following structure:
{
  "overall_score": "<A score from 0 to 100>",
  "scores": {
    "readability": "<A score from 0 to 100, based on clarity and simplicity>",
    "engagement": "<A score from 0 to 100, based on how interesting and engaging the text is>",
    "seo": "<A score from 0 to 100, considering keyword relevance for wellness topics and structure>",
    "trustworthiness": "<A score from 0 to 100, based on tone and evidence-based language>"
  },
  "summary": "<A one-sentence summary of the content's quality>",
  "strengths": [
    "<A key strength of the content>",
    "<Another key strength>"
  ],
  "recommendations": [
    "<A specific, actionable recommendation for improvement>",
    "<Another specific recommendation>"
  ]
}`;
      
      const schema = {
        type: "object",
        properties: {
          overall_score: { type: "number" },
          scores: {
            type: "object",
            properties: {
              readability: { type: "number" },
              engagement: { type: "number" },
              seo: { type: "number" },
              trustworthiness: { type: "number" }
            },
            required: ["readability", "engagement", "seo", "trustworthiness"]
          },
          summary: { type: "string" },
          strengths: { type: "array", items: { type: "string" } },
          recommendations: { type: "array", items: { type: "string" } }
        },
        required: ["overall_score", "scores", "summary", "strengths", "recommendations"]
      };

      const result = await InvokeLLM({
        prompt,
        response_json_schema: schema
      });
      setQualityResult(result);

    } catch (error) {
      console.error("Error with quality check:", error);
      setQualityResult({ error: "Failed to analyze content quality. Please try again." });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="pt-6">
      <h3 className="text-lg font-semibold text-sage-700 mb-2">Content Quality Scoring</h3>
      <p className="text-sm text-sage-600 mb-4">Get an AI-driven quality score for your content based on readability, engagement, SEO, and more.</p>
      <div className="space-y-4">
        <Textarea
          placeholder="Paste your article content for analysis..."
          value={qualityContent}
          onChange={(e) => setQualityContent(e.target.value)}
          rows={8}
          disabled={isLoading}
        />
        <Button onClick={handleQualityCheck} disabled={isLoading}>
          {isLoading ? <Loader2 className="animate-spin" /> : "Analyze Quality"}
        </Button>
        {qualityResult && !qualityResult.error && (
          <ResultCard title="Quality Report" icon={<img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/file-text-icon.svg" alt="file text" className="w-5 h-5 mr-2" />}>
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-sm text-gray-500">Overall Score</p>
                <p className="text-5xl font-bold text-sage-700">{qualityResult.overall_score}</p>
                <p className="font-semibold mt-2">{qualityResult.summary}</p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                {Object.entries(qualityResult.scores).map(([key, value]) => (
                  <div key={key} className="bg-sage-50 p-3 rounded-lg">
                    <p className="text-xs capitalize">{key}</p>
                    <p className="text-2xl font-semibold">{value}</p>
                  </div>
                ))}
              </div>
              <div>
                <h4 className="font-bold">Strengths:</h4>
                <ul className="list-disc pl-5">
                  {qualityResult.strengths.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
              </div>
              <div>
                <h4 className="font-bold">Recommendations:</h4>
                <ul className="list-disc pl-5">
                  {qualityResult.recommendations.map((r, i) => <li key={i}>{r}</li>)}
                </ul>
              </div>
            </div>
          </ResultCard>
        )}
        {qualityResult?.error && (
           <ResultCard title="Error" icon={<img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/file-text-icon.svg" alt="file text" className="w-5 h-5 mr-2" />}>
              <p>{qualityResult.error}</p>
           </ResultCard>
        )}
      </div>
    </div>
  );
}