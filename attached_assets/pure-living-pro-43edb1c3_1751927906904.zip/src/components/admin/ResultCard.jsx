import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const ResultCard = ({ title, icon, children }) => (
  <Card className="mt-6 organic-border">
    <CardHeader>
      <CardTitle className="flex items-center text-lg text-sage-700">
        {icon}
        {title}
      </CardTitle>
    </CardHeader>
    <CardContent className="prose dark:prose-invert max-w-none">
      {children}
    </CardContent>
  </Card>
);

export default ResultCard;