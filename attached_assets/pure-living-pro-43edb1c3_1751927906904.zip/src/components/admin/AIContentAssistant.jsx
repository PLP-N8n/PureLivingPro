import React, { useState } from "react";
import { InvokeLLM, GenerateImage } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";
import { 
  Sparkles, 
  Brain, 
  Zap, 
  RefreshCw, 
  TrendingUp,
  BarChart3,
  MessageSquare,
  Copy,
  CheckCircle,
  Globe,
  ImageIcon,
  Accessibility,
  Palette,
  HeartCrack,
  DollarSign,
  Clock
} from "lucide-react";

import ContentAccessibilityChecker from "./ContentAccessibilityChecker";
import ContentQualityAnalyzer from "./ContentQualityAnalyzer";
import BrokenLinkChecker from "./BrokenLinkChecker";
import AffiliatePerformanceReport from "./AffiliatePerformanceReport";
import ContentRefreshAnalyzer from "./ContentRefreshAnalyzer";

export default function AIContentAssistant() {
  const [activeTab, setActiveTab] = useState("analytics");
  const [isLoading, setIsLoading] = useState(false);
  const [analyticsContent, setAnalyticsContent] = useState("");
  const [analyticsResult, setAnalyticsResult] = useState("");
  const [repurposeContent, setRepurposeContent] = useState("");
  const [repurposeResult, setRepurposeResult] = useState("");
  const [translationContent, setTranslationContent] = useState("");
  const [translationResult, setTranslationResult] = useState("");
  const [imageGenPrompt, setImageGenPrompt] = useState("");
  const [generatedImageUrl, setGeneratedImageUrl] = useState("");
  const [copiedStates, setCopiedStates] = useState({});

  const copyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedStates(prev => ({ ...prev, [id]: true }));
    setTimeout(() => {
      setCopiedStates(prev => ({ ...prev, [id]: false }));
    }, 2000);
  };

  const handleContentAnalytics = async () => {
    if (!analyticsContent.trim()) return;

    setIsLoading(true);
    try {
      const prompt = `Analyze this wellness content and provide insights for content strategy:

Content: ${analyticsContent}

Provide analysis on:
1. Key topics and themes
2. Audience engagement potential
3. SEO optimization suggestions
4. Content gaps or opportunities
5. Recommended next steps

Format as actionable insights for a content creator.`;
      
      const result = await InvokeLLM({ prompt });
      setAnalyticsResult(result);
    } catch (error) {
      console.error("Error with content analytics:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleContentRepurpose = async () => {
    if (!repurposeContent.trim()) return;

    setIsLoading(true);
    try {
      const prompt = `Take this wellness content and repurpose it into 5 different formats:

Original Content: ${repurposeContent}

Create:
1. Social media post (Instagram caption)
2. Email newsletter snippet
3. Twitter thread (3-4 tweets)
4. YouTube video description
5. Pinterest pin description

Make each format engaging and platform-appropriate while maintaining the wellness focus.`;
      
      const result = await InvokeLLM({ prompt });
      setRepurposeResult(result);
    } catch (error) {
      console.error("Error with content repurposing:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTranslation = async () => {
    if (!translationContent.trim()) return;

    setIsLoading(true);
    try {
      const prompt = `Translate this wellness content into Spanish, French, and German. Maintain the wellness terminology and ensure cultural appropriateness:

Content: ${translationContent}

Provide:
1. Spanish translation
2. French translation  
3. German translation

Each should be natural and culturally appropriate for wellness content.`;
      
      const result = await InvokeLLM({ prompt });
      setTranslationResult(result);
    } catch (error) {
      console.error("Error with translation:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageGeneration = async () => {
    if (!imageGenPrompt.trim()) return;

    setIsLoading(true);
    try {
      const enhancedPrompt = `Create a wellness-focused, calming image: ${imageGenPrompt}. Style: clean, minimalist, natural colors (sage green, cream, soft browns), professional wellness photography aesthetic, serene and peaceful mood`;
      
      const result = await GenerateImage({ prompt: enhancedPrompt });
      setGeneratedImageUrl(result.url);
    } catch (error) {
      console.error("Error generating image:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="premium-shadow organic-border">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Sparkles className="w-6 h-6 mr-2 text-sage-600" />
          AI Content Tools
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-1">
            <TabsTrigger value="analytics" className="flex items-center gap-2 text-xs">
              <BarChart3 className="w-4 h-4" />Analytics
            </TabsTrigger>
            <TabsTrigger value="repurpose" className="flex items-center gap-2 text-xs">
              <RefreshCw className="w-4 h-4" />Repurpose
            </TabsTrigger>
            <TabsTrigger value="translate" className="flex items-center gap-2 text-xs">
              <Globe className="w-4 h-4" />Translate
            </TabsTrigger>
            <TabsTrigger value="images" className="flex items-center gap-2 text-xs">
              <ImageIcon className="w-4 h-4" />Images
            </TabsTrigger>
            <TabsTrigger value="quality" className="flex items-center gap-2 text-xs">
              <TrendingUp className="w-4 h-4" />Quality
            </TabsTrigger>
            <TabsTrigger value="accessibility" className="flex items-center gap-2 text-xs">
              <Accessibility className="w-4 h-4" />Access
            </TabsTrigger>
            <TabsTrigger value="links" className="flex items-center gap-2 text-xs">
              <HeartCrack className="w-4 h-4" />Links
            </TabsTrigger>
            <TabsTrigger value="performance" className="flex items-center gap-2 text-xs">
              <DollarSign className="w-4 h-4" />Revenue
            </TabsTrigger>
          </TabsList>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <div className="pt-6">
              <h3 className="text-lg font-semibold text-sage-700 mb-2">Content Analytics</h3>
              <p className="text-sm text-sage-600 mb-4">Get insights and optimization suggestions for your content.</p>
              <div className="space-y-4">
                <Textarea
                  placeholder="Paste your content here for analysis..."
                  value={analyticsContent}
                  onChange={(e) => setAnalyticsContent(e.target.value)}
                  rows={6}
                  disabled={isLoading}
                />
                <Button onClick={handleContentAnalytics} disabled={isLoading}>
                  {isLoading ? <Loader2 className="animate-spin" /> : <Brain className="w-4 h-4" />}
                  {isLoading ? "Analyzing..." : "Analyze Content"}
                </Button>
                {analyticsResult && (
                  <div className="mt-4 p-4 bg-sage-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-sage-700">Analysis Results</h4>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(analyticsResult, "analytics")}
                      >
                        {copiedStates.analytics ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                    <div className="prose dark:prose-invert max-w-none">
                      <pre className="whitespace-pre-wrap text-sm">{analyticsResult}</pre>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Repurpose Tab */}
          <TabsContent value="repurpose">
            <div className="pt-6">
              <h3 className="text-lg font-semibold text-sage-700 mb-2">Content Repurposing</h3>
              <p className="text-sm text-sage-600 mb-4">Transform your content for different platforms and formats.</p>
              <div className="space-y-4">
                <Textarea
                  placeholder="Paste your original content here..."
                  value={repurposeContent}
                  onChange={(e) => setRepurposeContent(e.target.value)}
                  rows={6}
                  disabled={isLoading}
                />
                <Button onClick={handleContentRepurpose} disabled={isLoading}>
                  {isLoading ? <Loader2 className="animate-spin" /> : <Zap className="w-4 h-4" />}
                  {isLoading ? "Repurposing..." : "Repurpose Content"}
                </Button>
                {repurposeResult && (
                  <div className="mt-4 p-4 bg-sage-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-sage-700">Repurposed Content</h4>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(repurposeResult, "repurpose")}
                      >
                        {copiedStates.repurpose ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                    <div className="prose dark:prose-invert max-w-none">
                      <pre className="whitespace-pre-wrap text-sm">{repurposeResult}</pre>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Translate Tab */}
          <TabsContent value="translate">
            <div className="pt-6">
              <h3 className="text-lg font-semibold text-sage-700 mb-2">Content Translation</h3>
              <p className="text-sm text-sage-600 mb-4">Translate your wellness content into multiple languages.</p>
              <div className="space-y-4">
                <Textarea
                  placeholder="Enter content to translate..."
                  value={translationContent}
                  onChange={(e) => setTranslationContent(e.target.value)}
                  rows={6}
                  disabled={isLoading}
                />
                <Button onClick={handleTranslation} disabled={isLoading}>
                  {isLoading ? <Loader2 className="animate-spin" /> : <Globe className="w-4 h-4" />}
                  {isLoading ? "Translating..." : "Translate Content"}
                </Button>
                {translationResult && (
                  <div className="mt-4 p-4 bg-sage-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-sage-700">Translations</h4>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(translationResult, "translation")}
                      >
                        {copiedStates.translation ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                    <div className="prose dark:prose-invert max-w-none">
                      <pre className="whitespace-pre-wrap text-sm">{translationResult}</pre>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
          
          {/* Image Generation Tab */}
          <TabsContent value="images">
            <div className="pt-6">
              <h3 className="text-lg font-semibold text-sage-700 mb-2">AI Image Generation</h3>
              <p className="text-sm text-sage-600 mb-4">Generate wellness-themed images for your content.</p>
              <div className="space-y-4">
                <Input
                  placeholder="Describe the image you want to generate..."
                  value={imageGenPrompt}
                  onChange={(e) => setImageGenPrompt(e.target.value)}
                  disabled={isLoading}
                />
                <Button onClick={handleImageGeneration} disabled={isLoading}>
                  {isLoading ? <Loader2 className="animate-spin" /> : <ImageIcon className="w-4 h-4" />}
                  {isLoading ? "Generating..." : "Generate Image"}
                </Button>
                {generatedImageUrl && (
                  <div className="mt-4 p-4 bg-sage-50 rounded-lg">
                    <h4 className="font-semibold text-sage-700 mb-2">Generated Image</h4>
                    <img 
                      src={generatedImageUrl} 
                      alt="Generated wellness image" 
                      className="w-full max-w-md rounded-lg"
                    />
                    <div className="mt-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(generatedImageUrl, "image")}
                      >
                        {copiedStates.image ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        Copy URL
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
          
          {/* Content Quality Tab */}
          <TabsContent value="quality">
            <ContentQualityAnalyzer />
          </TabsContent>

          {/* Accessibility Checker Tab */}
          <TabsContent value="accessibility">
            <ContentAccessibilityChecker />
          </TabsContent>

          {/* Broken Link Checker Tab */}
          <TabsContent value="links">
            <BrokenLinkChecker />
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance">
            <div className="pt-6">
              <h3 className="text-lg font-semibold text-sage-700 mb-2">Affiliate Performance</h3>
              <p className="text-sm text-sage-600 mb-4">Track your affiliate link performance and revenue insights.</p>
              <AffiliatePerformanceReport />
            </div>
          </TabsContent>

          {/* Content Refresh Tab */}
          <TabsContent value="refresh">
            <ContentRefreshAnalyzer />
          </TabsContent>

        </Tabs>
      </CardContent>
    </Card>
  );
}