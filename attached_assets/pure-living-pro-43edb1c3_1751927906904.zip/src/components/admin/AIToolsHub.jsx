import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bot,
  Sparkles,
  PenTool,
  Image as ImageIcon,
  RefreshCw,
  BarChart3,
  Search,
  Zap,
  Target,
  Brain,
  Wand2,
  Lightbulb,
  TrendingUp
} from "lucide-react";

import AIContentAssistant from "./AIContentAssistant";
import ContentQualityAnalyzer from "./ContentQualityAnalyzer";
import ContentRefreshAnalyzer from "./ContentRefreshAnalyzer";
import AffiliatePerformanceReport from "./AffiliatePerformanceReport";

const aiToolCategories = [
  {
    id: "content-creation",
    name: "Content Creation",
    icon: PenTool,
    color: "bg-blue-500",
    description: "AI-powered content generation and writing assistance",
    tools: [
      {
        name: "Content Assistant",
        description: "Generate blog posts, product descriptions, and marketing copy",
        component: "AIContentAssistant",
        icon: Bot,
        features: ["Article Generation", "SEO Optimization", "Content Repurposing"]
      }
    ]
  },
  {
    id: "content-analysis",
    name: "Content Analysis",
    icon: BarChart3,
    color: "bg-green-500",
    description: "Analyze and optimize your existing content",
    tools: [
      {
        name: "Quality Analyzer",
        description: "Analyze content quality, readability, and SEO potential",
        component: "ContentQualityAnalyzer",
        icon: Target,
        features: ["Readability Score", "SEO Analysis", "Engagement Prediction"]
      },
      {
        name: "Refresh Analyzer", 
        description: "Identify content that needs updates or improvements",
        component: "ContentRefreshAnalyzer",
        icon: RefreshCw,
        features: ["Content Freshness", "Update Recommendations", "Performance Tracking"]
      }
    ]
  },
  {
    id: "performance-insights",
    name: "Performance Insights",
    icon: TrendingUp,
    color: "bg-purple-500",
    description: "AI-driven analytics and performance optimization",
    tools: [
      {
        name: "Affiliate Performance",
        description: "Track and optimize affiliate product performance",
        component: "AffiliatePerformanceReport",
        icon: BarChart3,
        features: ["Revenue Tracking", "Conversion Analysis", "Product Recommendations"]
      }
    ]
  },
  {
    id: "automation",
    name: "Automation",
    icon: Zap,
    color: "bg-orange-500",
    description: "Automated workflows and smart suggestions",
    tools: [
      {
        name: "Smart Recommendations",
        description: "AI-powered content and product recommendations",
        component: "ComingSoon",
        icon: Brain,
        features: ["Content Suggestions", "Product Matching", "User Personalization"],
        comingSoon: true
      },
      {
        name: "Auto-Scheduler",
        description: "Intelligent content scheduling and publishing",
        component: "ComingSoon", 
        icon: Wand2,
        features: ["Optimal Timing", "Content Calendar", "Audience Analysis"],
        comingSoon: true
      }
    ]
  }
];

const ComingSoonCard = ({ tool, category }) => (
  <Card className="relative overflow-hidden border-dashed border-2 border-muted-foreground/30 bg-muted/30">
    <div className="absolute inset-0 bg-gradient-to-br from-muted/50 to-transparent"></div>
    <CardHeader className="relative">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 ${category.color} rounded-lg flex items-center justify-center`}>
            <tool.icon className="w-5 h-5 text-white" />
          </div>
          <div>
            <CardTitle className="text-lg">{tool.name}</CardTitle>
            <Badge variant="outline" className="mt-1">
              <Lightbulb className="w-3 h-3 mr-1" />
              Coming Soon
            </Badge>
          </div>
        </div>
      </div>
    </CardHeader>
    <CardContent className="relative">
      <p className="text-muted-foreground mb-4">{tool.description}</p>
      <div className="space-y-2">
        <p className="text-sm font-medium text-foreground">Planned Features:</p>
        <ul className="text-sm text-muted-foreground space-y-1">
          {tool.features.map((feature, idx) => (
            <li key={idx} className="flex items-center">
              <div className="w-1.5 h-1.5 bg-muted-foreground rounded-full mr-2"></div>
              {feature}
            </li>
          ))}
        </ul>
      </div>
    </CardContent>
  </Card>
);

const ToolCard = ({ tool, category, onSelect }) => {
  if (tool.comingSoon) {
    return <ComingSoonCard tool={tool} category={category} />;
  }

  return (
    <Card className="cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-105 border-0 bg-card/80 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 ${category.color} rounded-lg flex items-center justify-center`}>
            <tool.icon className="w-5 h-5 text-white" />
          </div>
          <div>
            <CardTitle className="text-lg">{tool.name}</CardTitle>
            <Badge variant="secondary" className="mt-1">
              <Sparkles className="w-3 h-3 mr-1" />
              AI Powered
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground mb-4">{tool.description}</p>
        <div className="space-y-2 mb-4">
          <p className="text-sm font-medium text-foreground">Key Features:</p>
          <ul className="text-sm text-muted-foreground space-y-1">
            {tool.features.map((feature, idx) => (
              <li key={idx} className="flex items-center">
                <div className="w-1.5 h-1.5 bg-primary rounded-full mr-2"></div>
                {feature}
              </li>
            ))}
          </ul>
        </div>
        <Button 
          onClick={() => onSelect(tool.component)} 
          className="w-full bg-primary hover:bg-primary/90"
        >
          Open Tool
        </Button>
      </CardContent>
    </Card>
  );
};

export default function AIToolsHub() {
  const [selectedTool, setSelectedTool] = useState(null);
  const [activeCategory, setActiveCategory] = useState("overview");

  const renderToolComponent = (componentName) => {
    switch (componentName) {
      case "AIContentAssistant":
        return <AIContentAssistant />;
      case "ContentQualityAnalyzer":
        return <ContentQualityAnalyzer />;
      case "ContentRefreshAnalyzer":
        return <ContentRefreshAnalyzer />;
      case "AffiliatePerformanceReport":
        return <AffiliatePerformanceReport />;
      default:
        return null;
    }
  };

  if (selectedTool) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button 
              variant="outline" 
              onClick={() => setSelectedTool(null)}
              className="bg-background"
            >
              ← Back to AI Tools
            </Button>
            <div className="h-6 w-px bg-border"></div>
            <h2 className="text-2xl font-bold text-foreground">AI Tools Hub</h2>
          </div>
          <Badge className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
            <Bot className="w-4 h-4 mr-2" />
            AI Powered
          </Badge>
        </div>
        
        <div className="bg-card/50 backdrop-blur-sm rounded-xl">
          {renderToolComponent(selectedTool)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-foreground">AI Tools Hub</h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Leverage artificial intelligence to streamline content creation, analyze performance, 
          and optimize your wellness platform with powerful automation tools.
        </p>
        <div className="flex items-center justify-center space-x-4">
          <Badge variant="outline" className="text-sm">
            <Sparkles className="w-3 h-3 mr-1" />
            {aiToolCategories.reduce((acc, cat) => acc + cat.tools.length, 0)} AI Tools Available
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Zap className="w-3 h-3 mr-1" />
            Powered by Advanced AI
          </Badge>
        </div>
      </div>

      {/* Tool Categories */}
      <Tabs value={activeCategory} onValueChange={setActiveCategory} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5 bg-muted/50">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          {aiToolCategories.map(category => (
            <TabsTrigger key={category.id} value={category.id} className="flex items-center space-x-2">
              <category.icon className="w-4 h-4" />
              <span className="hidden sm:inline">{category.name}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="overview" className="space-y-8">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {aiToolCategories.map(category => (
              <Card key={category.id} className="border-0 bg-card/80 backdrop-blur-sm">
                <CardContent className="p-6 text-center">
                  <div className={`w-12 h-12 ${category.color} rounded-xl flex items-center justify-center mx-auto mb-3`}>
                    <category.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">{category.name}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{category.tools.length} tools</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setActiveCategory(category.id)}
                    className="text-xs"
                  >
                    Explore
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* All Tools Grid */}
          <div className="space-y-6">
            {aiToolCategories.map(category => (
              <div key={category.id} className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 ${category.color} rounded-lg flex items-center justify-center`}>
                    <category.icon className="w-4 h-4 text-white" />
                  </div>
                  <h2 className="text-xl font-bold text-foreground">{category.name}</h2>
                  <Badge variant="secondary">{category.tools.length} tools</Badge>
                </div>
                <p className="text-muted-foreground ml-11">{category.description}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 ml-11">
                  {category.tools.map((tool, idx) => (
                    <ToolCard 
                      key={idx} 
                      tool={tool} 
                      category={category} 
                      onSelect={setSelectedTool}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        {aiToolCategories.map(category => (
          <TabsContent key={category.id} value={category.id} className="space-y-6">
            <div className="text-center space-y-2">
              <div className="flex items-center justify-center space-x-3">
                <div className={`w-10 h-10 ${category.color} rounded-xl flex items-center justify-center`}>
                  <category.icon className="w-5 h-5 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-foreground">{category.name}</h2>
              </div>
              <p className="text-muted-foreground">{category.description}</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {category.tools.map((tool, idx) => (
                <ToolCard 
                  key={idx} 
                  tool={tool} 
                  category={category} 
                  onSelect={setSelectedTool}
                />
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}