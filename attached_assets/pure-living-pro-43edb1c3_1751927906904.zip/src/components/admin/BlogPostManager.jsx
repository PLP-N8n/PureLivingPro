import React, { useState, useEffect } from "react";
import { BlogPost } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { PlusCircle, Edit, Trash2 } from "lucide-react";
import ContentEditor from "./ContentEditor";
import AIContentAssistant from "./AIContentAssistant";

export default function BlogPostManager() {
  const [posts, setPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [currentPost, setCurrentPost] = useState(null);

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = async () => {
    setIsLoading(true);
    try {
      const data = await BlogPost.list("-created_date", 100);
      setPosts(data);
    } catch (error) {
      console.error("Error loading blog posts:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewPost = () => {
    setCurrentPost({ title: '', content: '', published: false, is_premium: false, tags: [], category: '' });
    setIsEditing(true);
  };

  const handleEditPost = (post) => {
    setCurrentPost(post);
    setIsEditing(true);
  };

  const handleDeletePost = async (postId) => {
    if (confirm("Are you sure you want to delete this post?")) {
      try {
        await BlogPost.delete(postId);
        loadPosts();
      } catch (error) {
        console.error("Error deleting post:", error);
      }
    }
  };

  const handleSavePost = async (postData) => {
    try {
      if (postData.id) {
        await BlogPost.update(postData.id, postData);
      } else {
        await BlogPost.create(postData);
      }
      setIsEditing(false);
      setCurrentPost(null);
      loadPosts();
    } catch (error) {
      console.error("Error saving post:", error);
    }
  };

  if (isEditing) {
    return (
      <ContentEditor
        post={currentPost}
        onSave={handleSavePost}
        onCancel={() => setIsEditing(false)}
      />
    );
  }

  return (
    <div className="space-y-6">
      <Card className="premium-shadow organic-border">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Manage Blog Posts</CardTitle>
            <Button onClick={handleNewPost}>
              <PlusCircle className="w-4 h-4 mr-2" />
              New Post
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}
            </div>
          ) : (
            <div className="space-y-4">
              {posts.map((post) => (
                <div key={post.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h3 className="font-semibold">{post.title}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <span>{format(new Date(post.created_date), "MMM d, yyyy")}</span>
                      <Badge variant={post.published ? "default" : "outline"}>
                        {post.published ? "Published" : "Draft"}
                      </Badge>
                      {post.is_premium && <Badge className="bg-amber-400">Premium</Badge>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => handleEditPost(post)}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleDeletePost(post.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      <AIContentAssistant />
    </div>
  );
}