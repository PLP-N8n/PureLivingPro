import React, { useState, useEffect } from "react";
import { DailyWellnessLog, User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Smile, 
  Zap, 
  Leaf,
  Dumbbell,
  Brain,
  BookOpen,
  Save,
  Loader2,
  CheckCircle
} from "lucide-react";

const moodLevels = {
  1: { label: "Struggling", iconColor: "text-red-500" },
  2: { label: "Down", iconColor: "text-orange-500" },
  3: { label: "Okay", iconColor: "text-yellow-500" },
  4: { label: "Good", iconColor: "text-lime-500" },
  5: { label: "Great!", iconColor: "text-green-500" }
};

const energyLevels = {
  1: { label: "Exhausted", iconColor: "text-gray-500" },
  2: { label: "Tired", iconColor: "text-blue-400" },
  3: { label: "Normal", iconColor: "text-blue-500" },
  4: { label: "Energized", iconColor: "text-sky-500" },
  5: { label: "Vibrant!", iconColor: "text-cyan-400" }
};

const wellnessHabits = [
  { id: "meditation", label: "Meditated", icon: Brain },
  { id: "exercise", label: "Exercised", icon: Dumbbell },
  { id: "healthy_eating", label: "Ate Healthily", icon: Leaf },
  { id: "journaling", label: "Journaled/Reflected", icon: BookOpen }
];

export default function DailyTracker({ onLogUpdated }) {
  const [log, setLog] = useState(null);
  const [mood, setMood] = useState(3);
  const [energy, setEnergy] = useState(3);
  const [habits, setHabits] = useState([]);
  const [notes, setNotes] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    loadTodaysLog();
  }, []);

  const getTodayDateString = () => {
    return new Date().toISOString().split('T')[0];
  };

  const loadTodaysLog = async () => {
    setIsLoading(true);
    try {
      const today = getTodayDateString();
      const logs = await DailyWellnessLog.filter({ log_date: today });
      if (logs.length > 0) {
        const todaysLog = logs[0];
        setLog(todaysLog);
        setMood(todaysLog.mood);
        setEnergy(todaysLog.energy_level);
        setHabits(todaysLog.habits_completed || []);
        setNotes(todaysLog.notes || "");
      }
    } catch (error) {
      console.error("Error loading today's log:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleHabitChange = (habitId, checked) => {
    setHabits(prev => 
      checked ? [...prev, habitId] : prev.filter(h => h !== habitId)
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    setIsSaved(false);

    const logData = {
      log_date: getTodayDateString(),
      mood,
      energy_level: energy,
      habits_completed: habits,
      notes
    };

    try {
      if (log) {
        await DailyWellnessLog.update(log.id, logData);
      } else {
        await DailyWellnessLog.create(logData);
      }
      setIsSaved(true);
      if (onLogUpdated) {
        onLogUpdated();
      }
      setTimeout(() => setIsSaved(false), 2000);
      loadTodaysLog(); // Reload data after saving
    } catch (error) {
      console.error("Error saving wellness log:", error);
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <Card className="premium-shadow organic-border">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Loader2 className="animate-spin mr-2" /> Today's Wellness Log
          </CardTitle>
        </CardHeader>
        <CardContent className="h-64"></CardContent>
      </Card>
    );
  }

  return (
    <Card className="premium-shadow organic-border">
      <CardHeader>
        <CardTitle>Today's Wellness Log</CardTitle>
        <CardDescription>Track your daily progress to build lasting wellness habits.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Mood Tracker */}
          <div className="space-y-3">
            <Label htmlFor="mood-slider" className="flex items-center text-lg font-medium">
              <Smile className="mr-2 h-5 w-5 text-sage-600" /> Mood: <span className={`ml-2 font-bold ${moodLevels[mood].iconColor}`}>{moodLevels[mood].label}</span>
            </Label>
            <Slider
              id="mood-slider"
              min={1}
              max={5}
              step={1}
              value={[mood]}
              onValueChange={(value) => setMood(value[0])}
            />
          </div>

          {/* Energy Tracker */}
          <div className="space-y-3">
            <Label htmlFor="energy-slider" className="flex items-center text-lg font-medium">
              <Zap className="mr-2 h-5 w-5 text-sage-600" /> Energy: <span className={`ml-2 font-bold ${energyLevels[energy].iconColor}`}>{energyLevels[energy].label}</span>
            </Label>
            <Slider
              id="energy-slider"
              min={1}
              max={5}
              step={1}
              value={[energy]}
              onValueChange={(value) => setEnergy(value[0])}
            />
          </div>

          {/* Habit Tracker */}
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Completed Habits</h3>
            <div className="grid grid-cols-2 gap-4">
              {wellnessHabits.map(habit => (
                <div key={habit.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={habit.id}
                    checked={habits.includes(habit.id)}
                    onCheckedChange={(checked) => handleHabitChange(habit.id, checked)}
                  />
                  <Label htmlFor={habit.id} className="flex items-center gap-2 font-normal">
                    <habit.icon className="h-4 w-4 text-sage-600" /> {habit.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>
          
          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes" className="text-lg font-medium">Daily Reflection</Label>
            <Textarea
              id="notes"
              placeholder="Any thoughts or reflections today?"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="organic-border"
            />
          </div>

          <div className="flex justify-end">
            <Button type="submit" disabled={isSaving || isSaved}>
              {isSaving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...
                </>
              ) : isSaved ? (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" /> Saved!
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" /> {log ? 'Update Today\'s Log' : 'Save Today\'s Log'}
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}