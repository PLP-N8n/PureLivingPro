import React, { useState, useEffect } from "react";
import { DailyWellnessLog, User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  Dumbbell, 
  Leaf, 
  BookOpen, 
  Droplets,
  Heart,
  Moon,
  Sun,
  TrendingUp,
  Calendar,
  Target,
  Plus,
  X
} from "lucide-react";
import { format, subDays, startOfWeek, endOfWeek } from "date-fns";

const defaultHabits = [
  { id: "meditation", label: "Meditation", icon: Brain, category: "mindfulness" },
  { id: "exercise", label: "Exercise", icon: Dumbbell, category: "fitness" },
  { id: "healthy_eating", label: "Healthy Eating", icon: Leaf, category: "nutrition" },
  { id: "journaling", label: "Journaling", icon: BookOpen, category: "mindfulness" },
  { id: "water_intake", label: "8 Glasses of Water", icon: Droplets, category: "nutrition" },
  { id: "gratitude", label: "Gratitude Practice", icon: Heart, category: "mindfulness" },
  { id: "early_sleep", label: "Sleep by 10 PM", icon: Moon, category: "sleep" },
  { id: "morning_routine", label: "Morning Routine", icon: Sun, category: "routine" }
];

const categoryColors = {
  mindfulness: "bg-purple-100 text-purple-700",
  fitness: "bg-orange-100 text-orange-700",
  nutrition: "bg-green-100 text-green-700",
  sleep: "bg-blue-100 text-blue-700",
  routine: "bg-yellow-100 text-yellow-700"
};

export default function HabitTracker() {
  const [user, setUser] = useState(null);
  const [weeklyLogs, setWeeklyLogs] = useState([]);
  const [selectedHabits, setSelectedHabits] = useState([]);
  const [customHabit, setCustomHabit] = useState("");
  const [showAddHabit, setShowAddHabit] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  useEffect(() => {
    if (user) {
      loadWeeklyData();
      loadUserHabits();
    }
  }, [user]);

  const loadUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.error("User not logged in:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadUserHabits = () => {
    // Load selected habits from user profile or use defaults based on wellness goals
    const userGoals = user?.wellness_profile?.wellness_goals || [];
    const defaultSelection = defaultHabits.filter(habit => {
      if (userGoals.includes("stress_management")) return ["meditation", "journaling", "gratitude"].includes(habit.id);
      if (userGoals.includes("fitness_energy")) return ["exercise", "water_intake", "early_sleep"].includes(habit.id);
      if (userGoals.includes("better_nutrition")) return ["healthy_eating", "water_intake"].includes(habit.id);
      return ["meditation", "exercise", "healthy_eating"].includes(habit.id);
    });
    
    setSelectedHabits(defaultSelection.length > 0 ? defaultSelection : defaultHabits.slice(0, 4));
  };

  const loadWeeklyData = async () => {
    try {
      const today = new Date();
      const weekStart = startOfWeek(today, { weekStartsOn: 1 }); // Monday
      const weekEnd = endOfWeek(today, { weekStartsOn: 1 });
      
      // Get logs for the current week
      const logs = await DailyWellnessLog.filter({ 
        created_by: user.email 
      }, '-log_date', 7);
      
      setWeeklyLogs(logs);
    } catch (error) {
      console.error("Error loading weekly data:", error);
    }
  };

  const addCustomHabit = () => {
    if (!customHabit.trim()) return;
    
    const newHabit = {
      id: `custom_${Date.now()}`,
      label: customHabit,
      icon: Target,
      category: "custom"
    };
    
    setSelectedHabits(prev => [...prev, newHabit]);
    setCustomHabit("");
    setShowAddHabit(false);
  };

  const removeHabit = (habitId) => {
    setSelectedHabits(prev => prev.filter(h => h.id !== habitId));
  };

  const getHabitCompletionForWeek = (habitId) => {
    const completedDays = weeklyLogs.filter(log => 
      log.habits_completed?.includes(habitId)
    ).length;
    return completedDays;
  };

  const getWeeklyProgress = () => {
    if (selectedHabits.length === 0) return 0;
    const totalPossible = selectedHabits.length * 7;
    const totalCompleted = selectedHabits.reduce((sum, habit) => 
      sum + getHabitCompletionForWeek(habit.id), 0
    );
    return Math.round((totalCompleted / totalPossible) * 100);
  };

  const getLast7Days = () => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      days.push(subDays(new Date(), i));
    }
    return days;
  };

  const isHabitCompletedOnDay = (habitId, date) => {
    const dateString = format(date, 'yyyy-MM-dd');
    const dayLog = weeklyLogs.find(log => log.log_date === dateString);
    return dayLog?.habits_completed?.includes(habitId) || false;
  };

  if (isLoading) {
    return <div className="animate-pulse h-64 bg-sage-100 rounded-2xl"></div>;
  }

  if (!user) {
    return (
      <Card className="organic-border">
        <CardContent className="p-8 text-center">
          <Target className="w-12 h-12 text-sage-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-sage-700 mb-2">Track Your Habits</h3>
          <p className="text-sage-600 mb-4">Sign in to monitor your daily wellness habits.</p>
          <Button onClick={() => User.login()}>Sign In</Button>
        </CardContent>
      </Card>
    );
  }

  const weeklyProgress = getWeeklyProgress();

  return (
    <div className="space-y-6">
      {/* Weekly Progress Overview */}
      <Card className="organic-border premium-shadow">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-sage-600" />
              Weekly Habit Progress
            </div>
            <Badge variant="outline" className="text-sage-700">
              {weeklyProgress}% Complete
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Progress value={weeklyProgress} className="h-3 mb-4" />
          <p className="text-sm text-sage-600">
            You've completed {selectedHabits.reduce((sum, habit) => sum + getHabitCompletionForWeek(habit.id), 0)} out of {selectedHabits.length * 7} possible habits this week.
          </p>
        </CardContent>
      </Card>

      {/* Habit Grid */}
      <Card className="organic-border">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-sage-600" />
              Daily Habit Tracker
            </div>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowAddHabit(!showAddHabit)}
            >
              <Plus className="w-4 h-4" />
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Add Custom Habit */}
          {showAddHabit && (
            <div className="flex gap-2 p-4 bg-sage-50 rounded-xl">
              <input
                type="text"
                value={customHabit}
                onChange={(e) => setCustomHabit(e.target.value)}
                placeholder="Add custom habit..."
                className="flex-1 px-3 py-2 border rounded-lg"
                onKeyPress={(e) => e.key === 'Enter' && addCustomHabit()}
              />
              <Button onClick={addCustomHabit} size="sm">Add</Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowAddHabit(false)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}

          {/* Habits Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-sage-200">
                  <th className="text-left py-3 px-2 font-medium text-sage-700">Habit</th>
                  {getLast7Days().map((date, index) => (
                    <th key={index} className="text-center py-3 px-2 font-medium text-sage-700 min-w-[50px]">
                      <div className="text-xs">{format(date, 'EEE')}</div>
                      <div className="text-sm">{format(date, 'd')}</div>
                    </th>
                  ))}
                  <th className="text-center py-3 px-2 font-medium text-sage-700">Streak</th>
                </tr>
              </thead>
              <tbody>
                {selectedHabits.map((habit) => (
                  <tr key={habit.id} className="border-b border-sage-100">
                    <td className="py-3 px-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <habit.icon className="w-4 h-4 text-sage-600" />
                          <span className="text-sm font-medium text-sage-700">{habit.label}</span>
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${categoryColors[habit.category] || 'bg-gray-100 text-gray-700'}`}
                          >
                            {habit.category}
                          </Badge>
                        </div>
                        {habit.id.startsWith('custom_') && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeHabit(habit.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </td>
                    {getLast7Days().map((date, index) => (
                      <td key={index} className="text-center py-3 px-2">
                        <div className="flex justify-center">
                          {isHabitCompletedOnDay(habit.id, date) ? (
                            <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                              <span className="text-white text-xs">✓</span>
                            </div>
                          ) : (
                            <div className="w-6 h-6 bg-sage-200 rounded-full"></div>
                          )}
                        </div>
                      </td>
                    ))}
                    <td className="text-center py-3 px-2">
                      <Badge variant="outline" className="text-xs">
                        {getHabitCompletionForWeek(habit.id)}/7
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {selectedHabits.length === 0 && (
            <div className="text-center py-8">
              <Target className="w-12 h-12 text-sage-300 mx-auto mb-4" />
              <p className="text-sage-600">No habits selected. Add some habits to start tracking!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}