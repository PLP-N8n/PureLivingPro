import React, { useState, useEffect } from "react";
import { DailyWellnessLog } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Loader2, TrendingUp, BarChart } from 'lucide-react';
import { subDays, format, parseISO } from 'date-fns';

export default function WellnessCharts({ lastRefreshed }) {
  const [logs, setLogs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadChartData();
  }, [lastRefreshed]);

  const loadChartData = async () => {
    setIsLoading(true);
    try {
      const thirtyDaysAgo = subDays(new Date(), 30).toISOString();
      const data = await DailyWellnessLog.filter({ created_date__gte: thirtyDaysAgo }, '-created_date');
      
      const sortedData = data.sort((a, b) => new Date(a.log_date) - new Date(b.log_date));
      setLogs(sortedData);
    } catch (error) {
      console.error("Error loading chart data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const chartData = logs.map(log => ({
    date: format(parseISO(log.log_date), 'MMM d'),
    Mood: log.mood,
    Energy: log.energy_level,
  }));

  const calculateWellnessScore = () => {
    if (logs.length === 0) return 0;
    const last7DaysLogs = logs.slice(-7);
    if (last7DaysLogs.length === 0) return 0;
    const totalMood = last7DaysLogs.reduce((sum, log) => sum + log.mood, 0);
    const totalEnergy = last7DaysLogs.reduce((sum, log) => sum + log.energy_level, 0);
    const avgMood = totalMood / last7DaysLogs.length;
    const avgEnergy = totalEnergy / last7DaysLogs.length;
    const score = ((avgMood + avgEnergy) / 10) * 100;
    return Math.round(score);
  };
  
  const wellnessScore = calculateWellnessScore();

  if (isLoading) {
    return (
      <Card className="premium-shadow organic-border">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Loader2 className="animate-spin mr-2" /> Loading Progress...
          </CardTitle>
        </CardHeader>
        <CardContent className="h-96"></CardContent>
      </Card>
    );
  }

  if (logs.length < 2) {
    return (
      <Card className="premium-shadow organic-border">
        <CardHeader>
          <CardTitle>Your Wellness Trends</CardTitle>
        </CardHeader>
        <CardContent className="text-center py-16">
          <BarChart className="mx-auto h-12 w-12 text-sage-300 mb-4" />
          <h3 className="text-xl font-semibold text-sage-700">Not enough data yet</h3>
          <p className="text-sage-500 mt-2">Log your wellness for a few days to see your progress visualized here!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="premium-shadow organic-border">
      <CardHeader>
        <CardTitle>Your Wellness Trends</CardTitle>
        <CardDescription>Visualizing your mood and energy over the last 30 days.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-center mb-6 p-4 bg-sage-50 organic-border">
            <TrendingUp className="h-8 w-8 text-green-500 mr-4" />
            <div>
              <p className="text-sm text-sage-600">7-Day Wellness Score</p>
              <p className="text-3xl font-bold text-sage-700">{wellnessScore} <span className="text-lg font-normal">/ 100</span></p>
            </div>
        </div>

        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={chartData}
              margin={{ top: 5, right: 20, left: -10, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.1)" />
              <XAxis dataKey="date" stroke="#6b7280" />
              <YAxis domain={[1, 5]} tickCount={5} stroke="#6b7280" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.9)',
                  borderColor: '#e5e7eb',
                  borderRadius: '1rem',
                }}
              />
              <Legend />
              <Line type="monotone" dataKey="Mood" stroke="#8b5cf6" strokeWidth={2} activeDot={{ r: 8 }} />
              <Line type="monotone" dataKey="Energy" stroke="#10b981" strokeWidth={2} activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}