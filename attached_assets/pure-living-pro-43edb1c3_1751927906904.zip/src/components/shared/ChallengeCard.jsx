import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar, Trophy } from "lucide-react";

const categoryColors = {
  mindfulness: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  nutrition: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  fitness: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  sleep: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  detox: "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-400",
  "self-care": "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400"
};

const difficultyColors = {
  beginner: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  intermediate: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400", 
  advanced: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
};

export default function ChallengeCard({ 
  challenge, 
  userProgress = null, 
  className = "", 
  showProgress = true, 
  showBadges = true,
  imageHeight = "h-48" 
}) {
  if (!challenge || !challenge.id) return null;

  const isStarted = userProgress && userProgress.length > 0;
  const progress = isStarted ? userProgress[0] : null;
  const progressPercentage = progress ? Math.round((progress.current_day / challenge.duration_days) * 100) : 0;

  const safeChallenge = {
    id: challenge.id,
    title: challenge.title || "Unnamed Challenge",
    description: challenge.description || "No description available.",
    category: challenge.category || "general",
    difficulty_level: challenge.difficulty_level || "beginner",
    duration_days: challenge.duration_days || 7,
    image_url: challenge.image_url,
    reward_badge: challenge.reward_badge
  };

  return (
    <Link 
      to={`${createPageUrl("Challenges")}/${safeChallenge.id}`} 
      className={`group perspective-1000 block ${className}`}
    >
      <Card className="h-full border-0 bg-card shadow-lg transition-all duration-300 group-hover:shadow-2xl group-hover:[transform:translateY(-8px)_rotateX(5deg)_rotateY(-5deg)] rounded-2xl overflow-hidden">
        <CardContent className="p-0 h-full flex flex-col">
          <div className={`relative ${imageHeight} overflow-hidden`}>
            <img
              src={safeChallenge.image_url || "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"}
              alt={safeChallenge.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              loading="lazy"
              onError={(e) => {
                e.target.src = "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80";
              }}
            />
            
            {showBadges && (
              <>
                <div className="absolute top-3 left-3">
                  <Badge className={`${categoryColors[safeChallenge.category] || 'bg-muted text-muted-foreground'} rounded-full`}>
                    {safeChallenge.category}
                  </Badge>
                </div>
                <div className="absolute top-3 right-3">
                  <Badge className={`${difficultyColors[safeChallenge.difficulty_level] || 'bg-muted text-muted-foreground'} rounded-full`}>
                    {safeChallenge.difficulty_level}
                  </Badge>
                </div>
              </>
            )}
          </div>

          <div className="p-6 flex-1 flex flex-col">
            <h3 className="text-xl font-bold text-card-foreground mb-3 line-clamp-2 group-hover:text-primary transition-colors">
              {safeChallenge.title}
            </h3>
            <p className="text-muted-foreground mb-4 line-clamp-3 flex-1">
              {safeChallenge.description}
            </p>

            {showProgress && isStarted && (
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-card-foreground">
                    Day {progress.current_day} of {safeChallenge.duration_days}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {progressPercentage}% Complete
                  </span>
                </div>
                <Progress value={progressPercentage} className="h-2" />
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-border">
              <div className="flex items-center text-sm text-muted-foreground">
                <Calendar className="w-4 h-4 mr-1" />
                {safeChallenge.duration_days} days
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Trophy className="w-4 h-4 mr-1" />
                {safeChallenge.reward_badge ? 'Badge' : 'Reward'}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}