import React, { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/components/contexts/AuthContext";
import { BlogPost, WellnessPick, DailyWellnessLog } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { 
  MessageCircle, 
  X, 
  Send, 
  Bot, 
  User as UserIcon,
  Loader2,
  Sparkles,
  AlertCircle
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ChatbotWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'bot',
      content: "Hi! I'm your AI Wellness Coach. I can help you with personalized advice, find articles, or recommend products. How can I assist you today?",
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const { user: currentUser, isAuthenticated } = useAuth();
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return;

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsLoading(true);
    setHasError(false);

    try {
      // Create personalized context for the AI
      let personalContext = "The user is not logged in or their data is not available.";
      if (isAuthenticated && currentUser) {
        let recentLogs = [];
        try {
          recentLogs = await DailyWellnessLog.filter({ created_by: currentUser.email }, '-log_date', 3);
        } catch (logError) {
          console.warn("Could not fetch recent wellness logs:", logError);
        }

        personalContext = `
          User Name: ${currentUser.full_name || 'N/A'}
          User Email: ${currentUser.email || 'N/A'}
          Wellness Goals: ${currentUser.wellness_profile?.wellness_goals?.join(', ') || 'Not set'}
          Content Preferences: ${currentUser.wellness_profile?.content_preferences?.join(', ') || 'Not set'}
          Recent Mood/Energy Logs (last 3 entries): 
          ${recentLogs.map(log => `- ${new Date(log.log_date).toLocaleDateString()}: Mood ${log.mood}/5, Energy ${log.energy_level}/5, Notes: ${log.notes || 'N/A'}`).join('\n') || 'No recent logs available.'}
        `;
      }

      const prompt = `You are a helpful, supportive, and knowledgeable AI Wellness Coach for Pure Living Pro. Your goal is to provide personalized and empathetic wellness advice.

Here is some context about the user you are talking to:
${personalContext}

User's Question: "${inputMessage}"

Instructions:
- Use the user's personal context to provide tailored and empathetic advice.
- Keep responses conversational, positive, and motivational.
- Focus on holistic, natural approaches to wellness.
- Be encouraging and positive.
- If you don't know something, admit it rather than guessing.
- Keep responses under 200 words for better readability.

Please respond as a wellness coach:`;

      const response = await InvokeLLM({
        prompt: prompt,
        add_context_from_internet: false
      });

      const botMessage = {
        id: Date.now() + 1,
        type: 'bot',
        content: response || "I apologize, but I'm having trouble processing your request. Could you please try rephrasing your question?",
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botMessage]);

    } catch (error) {
      console.error("Error getting AI response:", error);
      setHasError(true);
      const errorMessage = {
        id: Date.now() + 1,
        type: 'bot',
        content: "I apologize, but I'm experiencing technical difficulties right now. Please try again in a moment, or feel free to browse our articles and wellness picks for helpful information.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatMessageContent = (content) => {
    return content;
  };

  return (
    <>
      {/* Chat Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="w-14 h-14 rounded-full bg-gradient-to-r from-sage-500 to-sage-600 hover:from-sage-600 hover:to-sage-700 text-white shadow-lg"
        >
          <AnimatePresence mode="wait">
            {isOpen ? (
              <motion.div
                key="close"
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <X className="w-6 h-6" />
              </motion.div>
            ) : (
              <motion.div
                key="chat"
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <Sparkles className="w-6 h-6" />
              </motion.div>
            )}
          </AnimatePresence>
        </Button>
      </motion.div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-24 right-6 w-96 h-[500px] z-50"
          >
            <Card className="h-full flex flex-col organic-border premium-shadow bg-white">
              <CardHeader className="bg-gradient-to-r from-sage-500 to-sage-600 text-white rounded-t-3xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">AI Wellness Coach</CardTitle>
                      <p className="text-xs text-white/80">Your Personal Wellness Assistant</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsOpen(false)}
                    className="text-white hover:bg-white/20"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                {hasError && (
                  <div className="flex items-center mt-2 text-xs text-white/80">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    <span>Connection issues detected</span>
                  </div>
                )}
              </CardHeader>

              <CardContent className="flex-1 flex flex-col p-0">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] p-3 rounded-2xl ${
                          message.type === 'user'
                            ? 'bg-sage-600 text-white'
                            : 'bg-sage-50 text-sage-700'
                        }`}
                      >
                        <div className="flex items-start space-x-2">
                          {message.type === 'bot' && (
                            <Bot className="w-4 h-4 mt-1 text-sage-600 flex-shrink-0" />
                          )}
                          <div className="text-sm">
                            {formatMessageContent(message.content)}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-sage-50 text-sage-700 p-3 rounded-2xl">
                        <div className="flex items-center space-x-2">
                          <Bot className="w-4 h-4 text-sage-600" />
                          <Loader2 className="w-4 h-4 animate-spin text-sage-600" />
                          <span className="text-sm">Thinking...</span>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className="p-4 border-t border-sage-200">
                  <div className="flex space-x-2">
                    <Input
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Ask me anything..."
                      className="flex-1 organic-border"
                      disabled={isLoading}
                    />
                    <Button
                      onClick={handleSendMessage}
                      disabled={!inputMessage.trim() || isLoading}
                      className="bg-sage-600 hover:bg-sage-700 text-white"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-xs text-sage-500 mt-2 text-center">
                    Powered by AI • For educational purposes only
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}