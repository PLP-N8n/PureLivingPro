import React from 'react';

// In a real Base44 project, you would use a secure backend function 
// to handle uploads with credentials stored safely on the server.
// This is a mock implementation to demonstrate the workflow.
export const uploadToCloudinary = async (file) => {
  // 1. Simulate upload delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  // 2. In a real scenario, you'd post the file to Cloudinary's API.
  // For this demo, we'll return a pre-uploaded image URL from Cloudinary's
  // demo account to demonstrate the URL structure and transformations.
  const cloudName = 'demo';
  
  // Using a static image to ensure it loads for the demo.
  // A real implementation would return a dynamic URL for the uploaded file.
  return `https://res.cloudinary.com/${cloudName}/image/upload/v1592235889/samples/landscapes/nature-mountains.jpg`;
};

// Utility to apply transformations to a Cloudinary URL
export const getCloudinaryTransformedUrl = (url, transformations = {}) => {
  if (!url || !url.includes('res.cloudinary.com')) {
    return url; // Return original URL if it's not from Cloudinary
  }

  const defaultTransformations = {
    quality: 'auto',
    fetch_format: 'auto',
  };

  const allTransforms = { ...defaultTransformations, ...transformations };

  const transformString = Object.entries(allTransforms)
    .map(([key, value]) => `${key.slice(0, 1)}_${value}`)
    .join(',');

  if (url.includes('/image/upload/')) {
    // Standard URL: insert transformations
    return url.replace('/image/upload/', `/image/upload/${transformString}/`);
  } else if (url.includes('/image/fetch/')) {
    // Fetched URL: prepend transformations
    return url.replace('/image/fetch/', `/image/fetch/${transformString}/`);
  }
  
  return url;
};