import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, ExternalLink } from "lucide-react";
import OptimizedImage from "@/components/shared/OptimizedImage";

const categoryColors = {
  "supplements": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  "skincare": "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-400",
  "fitness-equipment": "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  "meditation-tools": "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  "kitchen-wellness": "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  "aromatherapy": "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  "natural-remedies": "bg-sage-100 text-sage-800 dark:bg-sage-900/30 dark:text-sage-400"
};

const badgeColors = {
  "editors-pick": "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  "best-seller": "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  "trending": "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  "budget-buy": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400"
};

export default function ProductCardEnhanced({ product, imageHeight = "h-48" }) {
  const safeProduct = {
    id: product?.id || Math.random(),
    name: product?.name || "Wellness Product",
    description: product?.description || "Premium wellness product.",
    image_url: product?.image_url,
    affiliate_link: product?.affiliate_link || "#",
    original_price: product?.original_price || 0,
    discounted_price: product?.discounted_price,
    rating: product?.rating || 0,
    review_count: product?.review_count || 0,
    category: product?.category || "supplements",
    badge: product?.badge
  };

  return (
    <a 
      href={safeProduct.affiliate_link} 
      target="_blank" 
      rel="noopener noreferrer" 
      className="group perspective-1000 block"
    >
      <Card className="shadow-lg border-0 bg-card group-hover:[transform:translateY(-8px)_rotateX(5deg)_rotateY(-5deg)] transition-all duration-300 rounded-2xl overflow-hidden h-full group-hover:shadow-2xl">
        <CardContent className="p-0 h-full flex flex-col">
          <div className={`relative ${imageHeight} overflow-hidden`}>
            <OptimizedImage
              src={safeProduct.image_url || "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"}
              alt={safeProduct.name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              width={400}
              height={300}
              crop="fill"
              gravity="auto"
              quality="auto:good"
            />
            {safeProduct.badge && (
              <Badge className={`absolute top-3 left-3 ${badgeColors[safeProduct.badge]} rounded-full capitalize`}>
                {safeProduct.badge.replace('-', ' ')}
              </Badge>
            )}
          </div>

          <div className="p-6 flex-1 flex flex-col">
            <h3 className="font-bold text-card-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
              {safeProduct.name}
            </h3>
            <p className="text-sm text-muted-foreground mb-3 line-clamp-2 flex-1">
              {safeProduct.description}
            </p>

            <Badge className={`${categoryColors[safeProduct.category]} mb-3 self-start text-xs`}>
              {safeProduct.category.replace('-', ' ')}
            </Badge>

            {safeProduct.rating > 0 && (
              <div className="flex items-center mb-3">
                <div className="flex items-center">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${i < safeProduct.rating ? "text-accent fill-current" : "text-muted-foreground/30"}`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground ml-2">({safeProduct.review_count})</span>
              </div>
            )}

            <div className="flex items-center justify-between">
              <div className="flex flex-col">
                {safeProduct.discounted_price && safeProduct.discounted_price !== safeProduct.original_price && (
                  <span className="text-sm text-muted-foreground line-through">
                    £{safeProduct.original_price}
                  </span>
                )}
                <span className="text-lg font-bold text-card-foreground">
                  £{safeProduct.discounted_price || safeProduct.original_price}
                </span>
              </div>
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full">
                <ExternalLink className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </a>
  );
}