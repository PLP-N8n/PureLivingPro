import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function LoadingCard({ 
  type = "blog", 
  className = "", 
  imageHeight = "h-48" 
}) {
  return (
    <Card className={`organic-border bg-card/50 ${className}`}>
      <CardContent className="p-0 h-full flex flex-col">
        {/* Image area */}
        <div className={`relative ${imageHeight} overflow-hidden`}>
          <Skeleton className="h-full w-full rounded-t-2xl" />
        </div>
        
        <div className="p-6 flex-1 flex flex-col">
          {/* Title */}
          <Skeleton className="h-6 w-3/4 mb-2" />
          
          {/* Description */}
          <div className="space-y-2 mb-3">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-5/6" />
          </div>
          
          {/* Type-specific content */}
          {type === "product" && (
            <div className="flex items-center mb-3">
              <div className="flex items-center space-x-1">
                <Skeleton className="h-4 w-4 rounded-full" />
                <Skeleton className="h-4 w-4 rounded-full" />
                <Skeleton className="h-4 w-4 rounded-full" />
                <Skeleton className="h-4 w-4 rounded-full" />
                <Skeleton className="h-4 w-4 rounded-full" />
              </div>
              <Skeleton className="h-4 w-12 ml-2" />
            </div>
          )}
          
          {type === "challenge" && (
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-4 w-16" />
              </div>
              <Skeleton className="h-2 w-full" />
            </div>
          )}
          
          {/* Footer */}
          <div className="flex items-center justify-between mt-auto pt-4 border-t border-border">
            <Skeleton className="h-4 w-24" />
            {type === "product" ? (
              <Skeleton className="h-8 w-20 rounded-full" />
            ) : (
              <Skeleton className="h-4 w-16" />
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}