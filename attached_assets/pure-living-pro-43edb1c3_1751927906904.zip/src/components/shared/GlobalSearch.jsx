import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BlogPost, WellnessPick } from "@/api/entities";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, Search, Clock, Heart, TrendingUp, BookOpen } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const categoryColors = {
  "nutrition": "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  "meditation-mindfulness": "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  "fitness": "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  "natural-remedies": "bg-sage-100 text-sage-800 dark:bg-sage-900/30 dark:text-sage-400",
  "healthy-recipes": "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  "supplements": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  "skin-selfcare": "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-400"
};

export default function GlobalSearch({ isOpen, onClose }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState({ posts: [], products: [] });
  const [isLoading, setIsLoading] = useState(false);

  const fuzzySearch = (items, searchTerm, searchFields) => {
    if (!searchTerm) return [];
    
    const lowerSearchTerm = searchTerm.toLowerCase();
    
    return items.filter(item => {
      return searchFields.some(field => {
        const value = item[field];
        if (!value) return false;
        
        if (Array.isArray(value)) {
          return value.some(v => v.toLowerCase().includes(lowerSearchTerm));
        }
        
        return String(value).toLowerCase().includes(lowerSearchTerm);
      });
    }).slice(0, 5); // Limit results
  };

  const performSearch = async (searchQuery) => {
    if (!searchQuery.trim()) {
      setResults({ posts: [], products: [] });
      return;
    }

    setIsLoading(true);
    try {
      const [allPosts, allProducts] = await Promise.all([
        BlogPost.filter({ published: true }, "-created_date", 50),
        WellnessPick.list("-created_date", 50)
      ]);

      const posts = fuzzySearch(allPosts, searchQuery, ['title', 'excerpt', 'category', 'tags']);
      const products = fuzzySearch(allProducts, searchQuery, ['name', 'description', 'category', 'benefits']);

      setResults({ posts, products });
    } catch (error) {
      console.error("Search error:", error);
      setResults({ posts: [], products: [] });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const debounceTimer = setTimeout(() => {
      performSearch(query);
    }, 300);

    return () => clearTimeout(debounceTimer);
  }, [query]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
      setQuery("");
      setResults({ posts: [], products: [] });
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          transition={{ duration: 0.2 }}
          className="max-w-2xl mx-auto mt-20 mb-20 bg-card organic-border premium-shadow overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center p-6 border-b border-border">
            <Search className="w-5 h-5 text-muted-foreground mr-3" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search articles and products..."
              className="flex-1 border-0 p-0 text-lg focus:ring-0 bg-transparent"
              onKeyDown={handleKeyDown}
              autoFocus
            />
            <button
              onClick={onClose}
              className="ml-3 p-1 rounded-full hover:bg-muted transition-colors"
            >
              <X className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>

          {/* Results */}
          <div className="max-h-[60vh] overflow-y-auto">
            {isLoading && (
              <div className="p-6 text-center">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto"></div>
                <p className="mt-2 text-muted-foreground">Searching...</p>
              </div>
            )}

            {!isLoading && query && (results.posts.length > 0 || results.products.length > 0) && (
              <div className="p-4 space-y-6">
                {/* Articles */}
                {results.posts.length > 0 && (
                  <div>
                    <h3 className="text-sm font-semibold text-foreground mb-3 px-2 flex items-center">
                      <BookOpen className="w-4 h-4 mr-2 text-muted-foreground" />
                      Articles
                    </h3>
                    <div className="space-y-1">
                      {results.posts.map((post) => (
                        <Link
                          key={post.id}
                          to={`${createPageUrl("BlogPost")}/${post.slug || post.id}`}
                          onClick={onClose}
                          className="block p-3 rounded-lg hover:bg-muted transition-colors"
                        >
                          <div className="flex items-start space-x-3">
                            <div className="w-12 h-12 bg-secondary organic-border overflow-hidden flex-shrink-0">
                              {post.featured_image && (
                                <img
                                  src={post.featured_image}
                                  alt=""
                                  className="w-full h-full object-cover"
                                />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="text-sm font-medium text-foreground line-clamp-1">
                                {post.title}
                              </h4>
                              <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                                {post.excerpt}
                              </p>
                              <div className="flex items-center mt-2 space-x-2">
                                {post.category && (
                                  <Badge variant="secondary" className={`text-xs ${categoryColors[post.category]}`}>
                                    {post.category.replace('-', ' ')}
                                  </Badge>
                                )}
                                <span className="text-xs text-muted-foreground flex items-center">
                                  <Clock className="w-3 h-3 mr-1" />
                                  {post.read_time || 5} min
                                </span>
                              </div>
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}

                {/* Products */}
                {results.products.length > 0 && (
                  <div>
                    <h3 className="text-sm font-semibold text-foreground mb-3 px-2 flex items-center">
                      <Heart className="w-4 h-4 mr-2 text-muted-foreground" />
                      Wellness Picks
                    </h3>
                    <div className="space-y-1">
                      {results.products.map((product) => (
                        <a
                          key={product.id}
                          href={product.affiliate_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={onClose}
                          className="block p-3 rounded-lg hover:bg-muted transition-colors"
                        >
                          <div className="flex items-start space-x-3">
                            <div className="w-12 h-12 bg-secondary organic-border overflow-hidden flex-shrink-0">
                              {product.image_url && (
                                <img
                                  src={product.image_url}
                                  alt=""
                                  className="w-full h-full object-cover"
                                />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="text-sm font-medium text-foreground line-clamp-1">
                                {product.name}
                              </h4>
                              <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                                {product.description}
                              </p>
                              <div className="flex items-center justify-between mt-2">
                                <span className="text-sm font-bold text-foreground">
                                  £{product.discounted_price || product.original_price}
                                </span>
                                {product.badge && (
                                  <Badge variant="secondary" className="text-xs bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400">
                                    {product.badge.replace('-', ' ')}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {!isLoading && query && results.posts.length === 0 && results.products.length === 0 && (
              <div className="p-8 text-center">
                <Search className="w-12 h-12 text-muted-foreground/50 mx-auto mb-3" />
                <p className="text-muted-foreground">No results found for "{query}"</p>
                <p className="text-sm text-muted-foreground/70 mt-1">
                  Try different keywords or browse our categories.
                </p>
              </div>
            )}

            {!query && (
              <div className="p-8 text-center">
                <Search className="w-12 h-12 text-muted-foreground/50 mx-auto mb-3" />
                <p className="text-muted-foreground">
                  Search articles and wellness products
                </p>
                <p className="text-sm text-muted-foreground/70 mt-2">
                  Use <kbd className="px-1.5 py-0.5 bg-muted text-muted-foreground rounded-md text-xs font-mono">⌘K</kbd> to open search anytime.
                </p>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}