import React, { useState, useRef, useEffect } from "react";
import { Skeleton } from "@/components/ui/skeleton";

// Centralized Cloudinary transformation utility
export const getCloudinaryTransformedUrl = (originalUrl, options = {}) => {
  // Return original URL if not a Cloudinary URL or no URL provided
  if (!originalUrl || !originalUrl.includes('cloudinary.com')) {
    return originalUrl;
  }

  // Skip if already has transformations
  if (originalUrl.includes('/upload/') && originalUrl.match(/\/upload\/[^\/]+\//)) {
    return originalUrl;
  }

  const {
    width = 'auto',
    height = 'auto',
    quality = 'auto:good',
    format = 'auto',
    crop = 'fill',
    gravity = 'auto',
    dpr = 'auto',
    fetchFormat = 'auto',
    ...otherOptions
  } = options;

  // Build transformation string
  const transformations = [
    width !== 'auto' && `w_${width}`,
    height !== 'auto' && `h_${height}`,
    `q_${quality}`,
    `f_${format}`,
    crop !== 'fill' && `c_${crop}`,
    gravity !== 'auto' && `g_${gravity}`,
    dpr !== 'auto' && `dpr_${dpr}`,
    fetchFormat !== 'auto' && `fetch_format_${fetchFormat}`,
    ...Object.entries(otherOptions).map(([key, value]) => `${key}_${value}`)
  ].filter(Boolean).join(',');

  // Insert transformations into Cloudinary URL
  const urlParts = originalUrl.split('/upload/');
  if (urlParts.length === 2) {
    return `${urlParts[0]}/upload/${transformations}/${urlParts[1]}`;
  }

  return originalUrl;
};

// Generate responsive srcSet for different screen sizes
const generateSrcSet = (originalUrl, breakpoints = [400, 800, 1200, 1600]) => {
  if (!originalUrl || !originalUrl.includes('cloudinary.com')) {
    return '';
  }

  return breakpoints
    .map(width => {
      const url = getCloudinaryTransformedUrl(originalUrl, { 
        width, 
        quality: 'auto:good',
        format: 'auto',
        dpr: 'auto'
      });
      return `${url} ${width}w`;
    })
    .join(', ');
};

// Generate WebP and AVIF versions for modern browsers
const generateModernFormats = (originalUrl, options = {}) => {
  if (!originalUrl || !originalUrl.includes('cloudinary.com')) {
    return [];
  }

  return [
    {
      format: 'avif',
      srcSet: generateSrcSet(originalUrl, [400, 800, 1200, 1600])
        .replace(/f_auto/g, 'f_avif'),
      type: 'image/avif'
    },
    {
      format: 'webp',
      srcSet: generateSrcSet(originalUrl, [400, 800, 1200, 1600])
        .replace(/f_auto/g, 'f_webp'),
      type: 'image/webp'
    }
  ];
};

// Intersection Observer hook for lazy loading
const useIntersectionObserver = (options = {}) => {
  const [isIntersecting, setIsIntersecting] = useState(false);
  const [hasIntersected, setHasIntersected] = useState(false);
  const elementRef = useRef(null);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        const isVisible = entry.isIntersecting;
        setIsIntersecting(isVisible);
        
        if (isVisible && !hasIntersected) {
          setHasIntersected(true);
        }
      },
      {
        threshold: 0.1,
        rootMargin: '50px',
        ...options
      }
    );

    observer.observe(element);

    return () => {
      observer.unobserve(element);
    };
  }, [hasIntersected, options]);

  return [elementRef, isIntersecting, hasIntersected];
};

export default function OptimizedImage({
  src,
  alt = "",
  className = "",
  width,
  height,
  quality = "auto:good",
  format = "auto",
  crop = "fill",
  gravity = "auto",
  loading = "lazy",
  sizes = "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
  fallbackSrc = "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
  showSkeleton = true,
  enableIntersectionObserver = true,
  breakpoints = [400, 800, 1200, 1600],
  enableModernFormats = true,
  blurDataURL,
  onLoad,
  onError,
  ...props
}) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [currentSrc, setCurrentSrc] = useState(src);
  const [intersectionRef, isIntersecting, hasIntersected] = useIntersectionObserver({
    enabled: enableIntersectionObserver && loading === 'lazy'
  });

  // Determine if image should load
  const shouldLoad = loading === 'eager' || !enableIntersectionObserver || hasIntersected;

  // Generate optimized URLs
  const optimizedSrc = getCloudinaryTransformedUrl(currentSrc, {
    width,
    height,
    quality,
    format,
    crop,
    gravity
  });

  const srcSet = generateSrcSet(currentSrc, breakpoints);
  const modernFormats = enableModernFormats ? generateModernFormats(currentSrc) : [];

  const handleLoad = (e) => {
    setImageLoaded(true);
    onLoad?.(e);
  };

  const handleError = (e) => {
    if (!imageError && fallbackSrc && currentSrc !== fallbackSrc) {
      setCurrentSrc(fallbackSrc);
      setImageError(true);
      setImageLoaded(false);
    } else {
      setImageLoaded(true); // Hide skeleton even on error
    }
    onError?.(e);
  };

  return (
    <div 
      ref={intersectionRef}
      className={`relative overflow-hidden ${className}`}
      style={{ backgroundColor: blurDataURL ? 'transparent' : '#f3f4f6' }}
    >
      {/* Skeleton/Placeholder */}
      {showSkeleton && !imageLoaded && (
        <div className="absolute inset-0">
          {blurDataURL ? (
            <img
              src={blurDataURL}
              alt=""
              className="w-full h-full object-cover blur-sm scale-110 transition-all duration-300"
              style={{ filter: 'blur(10px)' }}
            />
          ) : (
            <Skeleton className="w-full h-full" />
          )}
        </div>
      )}

      {/* Main Image with Modern Format Support */}
      {shouldLoad && (
        <picture>
          {/* Modern formats for better compression */}
          {modernFormats.map((formatData) => (
            <source
              key={formatData.format}
              srcSet={formatData.srcSet}
              sizes={sizes}
              type={formatData.type}
            />
          ))}
          
          {/* Fallback image */}
          <img
            src={optimizedSrc}
            srcSet={srcSet}
            sizes={sizes}
            alt={alt}
            className={`w-full h-full object-cover transition-all duration-500 ${
              imageLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
            } ${className}`}
            onLoad={handleLoad}
            onError={handleError}
            loading={loading}
            decoding="async"
            {...props}
          />
        </picture>
      )}

      {/* Loading indicator for non-skeleton mode */}
      {!showSkeleton && !imageLoaded && shouldLoad && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      )}
    </div>
  );
}

// Utility component for background images
export function OptimizedBackgroundImage({
  src,
  className = "",
  children,
  overlay = false,
  overlayOpacity = 0.5,
  ...imageProps
}) {
  return (
    <div className={`relative ${className}`}>
      <OptimizedImage
        src={src}
        className="absolute inset-0 w-full h-full object-cover"
        loading="eager"
        {...imageProps}
      />
      {overlay && (
        <div 
          className="absolute inset-0 bg-black"
          style={{ opacity: overlayOpacity }}
        />
      )}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}

// Utility component for avatar images
export function OptimizedAvatar({
  src,
  alt,
  size = 40,
  className = "",
  fallback,
  ...props
}) {
  return (
    <div 
      className={`relative rounded-full overflow-hidden ${className}`}
      style={{ width: size, height: size }}
    >
      <OptimizedImage
        src={src}
        alt={alt}
        width={size * 2} // 2x for retina displays
        height={size * 2}
        crop="fill"
        gravity="face"
        quality="auto:good"
        className="w-full h-full"
        fallbackSrc={fallback}
        {...props}
      />
    </div>
  );
}

// Performance monitoring for images
export const imagePerformanceTracker = {
  metrics: [],
  
  trackImageLoad: (src, loadTime, size) => {
    if (typeof window !== 'undefined' && window.performance) {
      imagePerformanceTracker.metrics.push({
        src,
        loadTime,
        size,
        timestamp: Date.now(),
        url: window.location.pathname
      });
      
      // Keep only last 100 metrics
      if (imagePerformanceTracker.metrics.length > 100) {
        imagePerformanceTracker.metrics = imagePerformanceTracker.metrics.slice(-100);
      }
    }
  },
  
  getMetrics: () => imagePerformanceTracker.metrics,
  
  getAverageLoadTime: () => {
    const metrics = imagePerformanceTracker.metrics;
    if (metrics.length === 0) return 0;
    
    const totalTime = metrics.reduce((sum, metric) => sum + metric.loadTime, 0);
    return totalTime / metrics.length;
  }
};