import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Calendar } from "lucide-react";
import { format } from "date-fns";
import OptimizedImage from "./OptimizedImage";

const categoryColors = {
  "nutrition": "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  "meditation-mindfulness": "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  "fitness": "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  "natural-remedies": "bg-sage-100 text-sage-800 dark:bg-sage-900/30 dark:text-sage-400",
  "healthy-recipes": "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  "supplements": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  "skin-selfcare": "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-400"
};

function SafeDate({ dateString, format: dateFormat = "MMM d" }) {
  try {
    if (!dateString) return <span>Recent</span>;
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return <span>Recent</span>;
    return <span>{format(date, dateFormat)}</span>;
  } catch {
    return <span>Recent</span>;
  }
}

export default function BlogCard({ 
  post, 
  className = "", 
  showCategory = true, 
  showReadTime = true, 
  showDate = true,
  imageHeight = "h-48" 
}) {
  if (!post || !post.id) return null;

  const safePost = {
    id: post.id,
    title: post.title || "Untitled Article",
    excerpt: post.excerpt || "No description available.",
    category: post.category || "general",
    read_time: post.read_time || 5,
    created_date: post.created_date,
    slug: post.slug || post.id,
    featured_image: post.featured_image
  };

  return (
    <Link 
      to={`${createPageUrl("Blog")}/${safePost.slug}`} 
      className={`group perspective-1000 block ${className}`}
    >
      <Card className="h-full border-0 bg-card shadow-lg transition-all duration-300 group-hover:shadow-2xl group-hover:[transform:translateY(-8px)_rotateX(5deg)_rotateY(-5deg)] rounded-2xl overflow-hidden">
        <CardContent className="p-0 h-full flex flex-col">
          <div className={`relative ${imageHeight} overflow-hidden`}>
            <OptimizedImage
              src={safePost.featured_image}
              alt={safePost.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              width={400}
              height={300}
              crop="fill"
              gravity="auto"
              loading="lazy"
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
              fallbackSrc="https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
              enableModernFormats={true}
              breakpoints={[300, 400, 600, 800]}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            
            {showCategory && (
              <Badge className={`absolute top-3 left-3 ${categoryColors[safePost.category] || 'bg-muted text-muted-foreground'} rounded-full`}>
                {safePost.category.replace('-', ' ')}
              </Badge>
            )}
          </div>

          <div className="p-6 flex-1 flex flex-col">
            <h3 className="text-xl font-bold text-card-foreground mb-3 line-clamp-2 group-hover:text-primary transition-colors">
              {safePost.title}
            </h3>
            <p className="text-muted-foreground mb-4 line-clamp-3 flex-1">
              {safePost.excerpt}
            </p>

            <div className="flex items-center justify-between pt-4 border-t border-border">
              {showReadTime && (
                <div className="flex items-center text-sm text-muted-foreground">
                  <Clock className="w-4 h-4 mr-1" />
                  {safePost.read_time} min read
                </div>
              )}
              
              {showDate && (
                <div className="text-sm text-muted-foreground">
                  <SafeDate dateString={safePost.created_date} />
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}