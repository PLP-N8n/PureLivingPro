import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, ExternalLink, Heart } from "lucide-react";
import OptimizedImage from "./OptimizedImage";

const badgeConfig = {
  "editors-pick": { label: "Editor's Pick", color: "bg-sage-500 text-white" },
  "best-seller": { label: "Best Seller", color: "bg-amber-500 text-white" },
  "budget-buy": { label: "Budget Buy", color: "bg-blue-500 text-white" },
  "trending": { label: "Trending", color: "bg-purple-500 text-white" }
};

export default function ProductCard({ 
  product, 
  className = "", 
  showBadge = true, 
  showRating = true, 
  showHeart = true,
  imageHeight = "h-48",
  buttonText = "View"
}) {
  if (!product || !product.id) return null;

  const safeProduct = {
    id: product.id,
    name: product.name || "Unnamed Product",
    description: product.description || "No description available.",
    category: product.category || "general",
    image_url: product.image_url,
    affiliate_link: product.affiliate_link || "#",
    original_price: product.original_price || 0,
    discounted_price: product.discounted_price,
    rating: product.rating || 0,
    review_count: product.review_count || 0,
    badge: product.badge
  };

  return (
    <a 
      href={safeProduct.affiliate_link} 
      target="_blank" 
      rel="noopener noreferrer" 
      className={`group perspective-1000 block ${className}`}
    >
      <Card className="h-full border-0 bg-card shadow-lg transition-all duration-300 group-hover:shadow-2xl group-hover:[transform:rotateX(2deg)_rotateY(-2deg)_translateY(-5px)_scale(1.015)] rounded-2xl overflow-hidden">
        <CardContent className="p-0 h-full flex flex-col">
          <div className={`relative ${imageHeight} overflow-hidden`}>
            <OptimizedImage
              src={safeProduct.image_url}
              alt={safeProduct.name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              width={400}
              height={300}
              crop="fill"
              gravity="auto"
              loading="lazy"
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
              fallbackSrc="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
              enableModernFormats={true}
              breakpoints={[300, 400, 600, 800]}
            />
            
            {showBadge && safeProduct.badge && badgeConfig[safeProduct.badge] && (
              <Badge className={`absolute top-3 left-3 ${badgeConfig[safeProduct.badge].color} rounded-full`}>
                {badgeConfig[safeProduct.badge].label}
              </Badge>
            )}
            
            {showHeart && (
              <div className="absolute top-3 right-3 w-8 h-8 bg-card/80 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Heart className="w-4 h-4 text-primary" />
              </div>
            )}
          </div>

          <div className="p-6 flex-1 flex flex-col">
            <h3 className="font-bold text-card-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
              {safeProduct.name}
            </h3>
            <p className="text-sm text-muted-foreground mb-3 line-clamp-2 flex-1">
              {safeProduct.description}
            </p>
            
            {showRating && safeProduct.rating > 0 && (
              <div className="flex items-center mb-3">
                <div className="flex items-center">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${i < safeProduct.rating ? "text-accent fill-current" : "text-muted-foreground/30"}`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground ml-2">({safeProduct.review_count})</span>
              </div>
            )}

            <div className="flex items-center justify-between mt-auto pt-4 border-t border-border">
              <div className="flex items-baseline space-x-2">
                {safeProduct.discounted_price && safeProduct.original_price && safeProduct.discounted_price < safeProduct.original_price && (
                  <span className="text-sm text-muted-foreground line-through">
                    £{safeProduct.original_price}
                  </span>
                )}
                <span className="text-lg font-bold text-card-foreground">
                  £{safeProduct.discounted_price || safeProduct.original_price}
                </span>
              </div>
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full group/btn">
                {buttonText}
                <ExternalLink className="w-4 h-4 ml-1 group-hover/btn:translate-x-0.5 transition-transform" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </a>
  );
}