import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import OptimizedImage from "./OptimizedImage";

export default function BaseCard({
  // Content
  title,
  subtitle,
  description,
  image,
  imageAlt,
  
  // Styling
  imageHeight = "h-48",
  badgeText,
  badgeColor = "bg-primary text-primary-foreground",
  
  // Interaction
  onClick,
  href,
  target,
  isClickable = true,
  
  // Layout
  layout = "vertical", // "vertical" | "horizontal" | "compact"
  children,
  
  // Animation
  hoverEffect = true,
  
  // Custom classes
  className = "",
  imageClassName = "",
  contentClassName = "",
  
  ...props
}) {
  const CardWrapper = href ? 'a' : onClick ? 'button' : 'div';
  
  const cardClasses = `
    ${hoverEffect && isClickable ? 'group perspective-1000 cursor-pointer' : ''}
    ${isClickable ? 'focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2' : ''}
    ${className}
  `;

  const cardContentClasses = `
    shadow-lg border-0 bg-card 
    ${hoverEffect && isClickable ? 'group-hover:[transform:translateY(-8px)_rotateX(5deg)_rotateY(-5deg)] group-hover:shadow-2xl' : ''}
    transition-all duration-300 rounded-2xl overflow-hidden h-full
  `;

  const cardProps = {
    ...(href && { href, target }),
    ...(onClick && { onClick }),
    className: cardClasses,
    ...props
  };

  const renderImage = () => {
    if (!image) return null;

    return (
      <div className={`relative ${imageHeight} overflow-hidden ${imageClassName}`}>
        <OptimizedImage
          src={image}
          alt={imageAlt || title || ''}
          className={`w-full h-full object-cover ${hoverEffect ? 'group-hover:scale-110' : ''} transition-transform duration-500`}
          width={400}
          height={300}
          crop="fill"
          gravity="auto"
          quality="auto:good"
        />
        {badgeText && (
          <Badge className={`absolute top-3 left-3 ${badgeColor} rounded-full`}>
            {badgeText}
          </Badge>
        )}
      </div>
    );
  };

  const renderContent = () => (
    <div className={`p-6 flex-1 flex flex-col ${contentClassName}`}>
      {title && (
        <h3 className={`font-bold text-card-foreground mb-3 line-clamp-2 ${hoverEffect ? 'group-hover:text-primary' : ''} transition-colors ${
          layout === 'compact' ? 'text-lg' : 'text-xl'
        }`}>
          {title}
        </h3>
      )}
      
      {subtitle && (
        <p className="text-sm font-medium text-muted-foreground mb-2">
          {subtitle}
        </p>
      )}
      
      {description && (
        <p className="text-muted-foreground mb-4 line-clamp-3 flex-1">
          {description}
        </p>
      )}
      
      {children}
    </div>
  );

  const renderHorizontalLayout = () => (
    <CardContent className="p-0 h-full flex">
      <div className="w-1/3">
        {renderImage()}
      </div>
      <div className="flex-1">
        {renderContent()}
      </div>
    </CardContent>
  );

  const renderVerticalLayout = () => (
    <CardContent className="p-0 h-full flex flex-col">
      {renderImage()}
      {renderContent()}
    </CardContent>
  );

  const renderCompactLayout = () => (
    <CardContent className="p-4 h-full flex items-center space-x-4">
      {image && (
        <div className="w-16 h-16 flex-shrink-0 overflow-hidden rounded-lg">
          <OptimizedImage
            src={image}
            alt={imageAlt || title || ''}
            className="w-full h-full object-cover"
            width={64}
            height={64}
            crop="fill"
            gravity="auto"
            quality="auto:good"
          />
        </div>
      )}
      <div className="flex-1 min-w-0">
        {title && (
          <h4 className="font-semibold text-card-foreground truncate">
            {title}
          </h4>
        )}
        {subtitle && (
          <p className="text-sm text-muted-foreground truncate">
            {subtitle}
          </p>
        )}
        {children}
      </div>
      {badgeText && (
        <Badge className={`${badgeColor} rounded-full flex-shrink-0`}>
          {badgeText}
        </Badge>
      )}
    </CardContent>
  );

  return (
    <CardWrapper {...cardProps}>
      <Card className={cardContentClasses}>
        {layout === 'horizontal' && renderHorizontalLayout()}
        {layout === 'vertical' && renderVerticalLayout()}
        {layout === 'compact' && renderCompactLayout()}
      </Card>
    </CardWrapper>
  );
}