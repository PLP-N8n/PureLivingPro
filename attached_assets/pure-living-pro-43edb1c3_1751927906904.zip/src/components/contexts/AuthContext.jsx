import React, { createContext, useState, useEffect, useContext } from 'react';
import { User } from '@/api/entities';
import { Loader2 } from 'lucide-react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const checkUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      setIsAuthenticated(true);
      console.log('AuthContext: User authenticated:', currentUser.email);
    } catch (error) {
      console.log('AuthContext: User not authenticated');
      setUser(null);
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await User.logout();
    } catch (error) {
      console.error('AuthContext: Logout error:', error);
    } finally {
      setUser(null);
      setIsAuthenticated(false);
    }
  };

  const updateUserData = async (data) => {
    try {
      await User.updateMyUserData(data);
      // Refresh user data after update
      await checkUser();
    } catch (error) {
      console.error('AuthContext: Update user data error:', error);
      throw error;
    }
  };

  useEffect(() => {
    checkUser();
  }, []);

  const value = {
    user,
    isLoading,
    isAuthenticated,
    refetchUser: checkUser,
    logout,
    updateUserData
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading your wellness journey...</p>
        </div>
      </div>
    );
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;