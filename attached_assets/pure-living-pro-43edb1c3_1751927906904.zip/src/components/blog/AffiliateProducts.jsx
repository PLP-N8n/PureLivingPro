import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, ShoppingBag } from "lucide-react";

export default function AffiliateProducts({ products }) {
  if (!products || products.length === 0) {
    return null;
  }

  return (
    <section className="mb-12">
      <div className="bg-sage-50 organic-border p-6 mb-6">
        <div className="flex items-center mb-4">
          <ShoppingBag className="w-6 h-6 text-sage-600 mr-2" />
          <h3 className="text-xl font-bold text-sage-700">Featured Products</h3>
        </div>
        <p className="text-sage-600">
          These are some of the wellness products mentioned in this article. 
          We may earn a commission from purchases made through these links.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {products.map((product) => (
          <Card key={product.amazon_link || product.name} className="premium-shadow organic-border border-0 bg-white">
            <CardContent className="p-6">
              <h4 className="font-bold text-sage-700 mb-2">{product.name}</h4>
              <p className="text-sage-600 mb-4">{product.description}</p>
              <a
                href={product.amazon_link}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="w-full bg-sage-600 hover:bg-sage-700 text-white organic-border">
                  View on Amazon
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </a>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}