import React from "react";
import { Button } from "@/components/ui/button";

const categories = [
  { name: "All Categories", slug: "all" },
  { name: "Nutrition", slug: "nutrition" },
  { name: "Mindfulness", slug: "meditation-mindfulness" },
  { name: "Fitness", slug: "fitness" },
  { name: "Natural Remedies", slug: "natural-remedies" },
  { name: "Healthy Recipes", slug: "healthy-recipes" },
  { name: "Supplements", slug: "supplements" },
  { name: "Skin & Self-care", slug: "skin-selfcare" }
];

export default function CategoryFilterEnhanced({ selectedCategory, onCategoryChange }) {
  return (
    <div className="flex flex-wrap justify-center gap-3">
      {categories.map((category) => (
        <Button
          key={category.slug}
          variant={selectedCategory === category.slug ? "default" : "outline"}
          onClick={() => onCategoryChange(category.slug)}
          className="rounded-full transition-all duration-300"
        >
          {category.name}
        </Button>
      ))}
    </div>
  );
}