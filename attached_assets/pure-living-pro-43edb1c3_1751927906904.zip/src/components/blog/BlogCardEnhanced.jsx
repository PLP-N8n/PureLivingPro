import React from "react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";
import OptimizedImage from "@/components/shared/OptimizedImage";

const categoryColors = {
  "nutrition": "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  "meditation-mindfulness": "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
  "fitness": "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  "natural-remedies": "bg-sage-100 text-sage-800 dark:bg-sage-900/30 dark:text-sage-400",
  "healthy-recipes": "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  "supplements": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  "skin-selfcare": "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-400"
};

const formatSafeDate = (dateString) => {
  try {
    if (!dateString) return "Recent";
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return "Recent";
    return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(date);
  } catch {
    return "Recent";
  }
};

export default function BlogCardEnhanced({ post, imageHeight = "h-48" }) {
  const safePost = {
    id: post?.id || Math.random(),
    title: post?.title || "Wellness Insight",
    excerpt: post?.excerpt || "Discover valuable wellness insights.",
    slug: post?.slug || post?.id,
    featured_image: post?.featured_image,
    category: post?.category || "wellness",
    read_time: post?.read_time || 5,
    created_date: post?.created_date
  };

  return (
    <Link 
      to={`/blog/${safePost.slug}`} 
      className="group perspective-1000 block"
    >
      <Card className="shadow-lg border-0 bg-card group-hover:[transform:translateY(-8px)_rotateX(5deg)_rotateY(-5deg)] transition-all duration-300 rounded-2xl overflow-hidden h-full group-hover:shadow-2xl">
        <CardContent className="p-0 h-full flex flex-col">
          <div className={`relative ${imageHeight} overflow-hidden`}>
            <OptimizedImage
              src={safePost.featured_image || "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"}
              alt={safePost.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              width={400}
              height={300}
              crop="fill"
              gravity="auto"
              quality="auto:good"
            />
            <Badge className={`absolute top-3 left-3 ${categoryColors[safePost.category]} rounded-full capitalize`}>
              {safePost.category.replace('-', ' ')}
            </Badge>
          </div>

          <div className="p-6 flex-1 flex flex-col">
            <h3 className="text-xl font-bold text-card-foreground mb-3 line-clamp-2 group-hover:text-primary transition-colors">
              {safePost.title}
            </h3>
            <p className="text-muted-foreground mb-4 line-clamp-3 flex-1">
              {safePost.excerpt}
            </p>

            <div className="flex items-center justify-between pt-4 border-t border-border">
              <div className="flex items-center text-sm text-muted-foreground">
                <Clock className="w-4 h-4 mr-1" />
                {safePost.read_time} min read
              </div>
              <div className="text-sm text-muted-foreground">
                {formatSafeDate(safePost.created_date)}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}