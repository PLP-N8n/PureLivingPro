import React from "react";
import { BookOpen } from "lucide-react";

export default function BlogHeaderEnhanced() {
  return (
    <div className="bg-card border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <div className="flex items-center justify-center mb-4">
            <BookOpen className="w-8 h-8 text-primary mr-3" />
            <span className="text-primary font-medium uppercase tracking-wider">Wellness Insights</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Evidence-Based Wellness
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover science-backed insights, practical guides, and expert advice
            to support your holistic wellness journey.
          </p>
        </div>
      </div>
    </div>
  );
}