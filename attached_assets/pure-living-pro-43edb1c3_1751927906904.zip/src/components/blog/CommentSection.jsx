import React, { useState, useEffect } from "react";
import { Comment, User } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { MessageCircle, Heart, Reply, Send, User as UserIcon } from "lucide-react";
import { format } from "date-fns";

export default function CommentSection({ postId }) {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [replyTo, setReplyTo] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadComments();
    loadCurrentUser();
  }, [postId]);

  const loadCurrentUser = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (error) {
      // User not logged in
      setCurrentUser(null);
    }
  };

  const loadComments = async () => {
    try {
      const data = await Comment.filter({ post_id: postId, approved: true }, "-created_date");
      setComments(data);
    } catch (error) {
      console.error("Error loading comments:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim() || !currentUser) return;

    setIsSubmitting(true);
    try {
      await Comment.create({
        content: newComment.trim(),
        post_id: postId,
        parent_id: replyTo?.id || null
      });
      setNewComment("");
      setReplyTo(null);
      loadComments();
    } catch (error) {
      console.error("Error submitting comment:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLikeComment = async (commentId) => {
    if (!currentUser) return;
    
    try {
      const comment = comments.find(c => c.id === commentId);
      await Comment.update(commentId, { likes: (comment.likes || 0) + 1 });
      loadComments();
    } catch (error) {
      console.error("Error liking comment:", error);
    }
  };

  const organizeComments = (comments) => {
    const topLevel = comments.filter(c => !c.parent_id);
    const replies = comments.filter(c => c.parent_id);
    
    return topLevel.map(comment => ({
      ...comment,
      replies: replies.filter(r => r.parent_id === comment.id)
    }));
  };

  const organizedComments = organizeComments(comments);

  return (
    <section className="mt-12 pt-8 border-t border-sage-200">
      <div className="flex items-center mb-8">
        <MessageCircle className="w-6 h-6 text-sage-600 mr-3" />
        <h3 className="text-2xl font-bold text-sage-700">
          Discussion ({comments.length})
        </h3>
      </div>

      {/* Comment Form */}
      {currentUser ? (
        <Card className="mb-8 organic-border premium-shadow">
          <CardContent className="p-6">
            {replyTo && (
              <div className="mb-4 p-3 bg-sage-50 organic-border">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-sage-600">
                    Replying to <strong>{replyTo.created_by}</strong>
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setReplyTo(null)}
                    className="text-sage-500 hover:text-sage-700"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
            <form onSubmit={handleSubmitComment} className="space-y-4">
              <Textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder={replyTo ? "Write your reply..." : "Share your thoughts on this article..."}
                className="min-h-[100px] organic-border resize-none"
              />
              <div className="flex justify-between items-center">
                <span className="text-sm text-sage-500">
                  Commenting as <strong>{currentUser.full_name}</strong>
                </span>
                <Button
                  type="submit"
                  disabled={!newComment.trim() || isSubmitting}
                  className="bg-sage-600 hover:bg-sage-700 organic-border"
                >
                  {isSubmitting ? "Posting..." : "Post Comment"}
                  <Send className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      ) : (
        <Card className="mb-8 organic-border">
          <CardContent className="p-6 text-center">
            <UserIcon className="w-12 h-12 text-sage-400 mx-auto mb-4" />
            <h4 className="text-lg font-semibold text-sage-700 mb-2">Join the Conversation</h4>
            <p className="text-sage-600 mb-4">
              Sign in to share your thoughts and connect with our wellness community.
            </p>
            <Button
              onClick={() => User.login()}
              className="bg-sage-600 hover:bg-sage-700 organic-border"
            >
              Sign In to Comment
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Comments List */}
      {isLoading ? (
        <div className="space-y-6">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="organic-border">
              <CardContent className="p-6">
                <div className="flex space-x-4">
                  <Skeleton className="w-10 h-10 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-16 w-full" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : organizedComments.length === 0 ? (
        <div className="text-center py-12">
          <MessageCircle className="w-16 h-16 text-sage-300 mx-auto mb-4" />
          <h4 className="text-lg font-semibold text-sage-600 mb-2">No comments yet</h4>
          <p className="text-sage-500">Be the first to share your thoughts on this article!</p>
        </div>
      ) : (
        <div className="space-y-6">
          {organizedComments.map((comment) => (
            <Card key={comment.id} className="organic-border">
              <CardContent className="p-6">
                <div className="flex space-x-4">
                  <div className="w-10 h-10 bg-sage-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <UserIcon className="w-5 h-5 text-sage-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="font-semibold text-sage-700">
                        {comment.created_by}
                      </span>
                      <span className="text-sm text-sage-500">
                        {format(new Date(comment.created_date), "MMM d, yyyy 'at' h:mm a")}
                      </span>
                    </div>
                    <p className="text-sage-600 mb-4 leading-relaxed whitespace-pre-wrap">
                      {comment.content}
                    </p>
                    <div className="flex items-center space-x-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLikeComment(comment.id)}
                        className="text-sage-500 hover:text-sage-700 p-0"
                        disabled={!currentUser}
                      >
                        <Heart className={`w-4 h-4 mr-1 ${comment.likes > 0 ? 'fill-current text-red-500' : ''}`} />
                        {comment.likes || 0}
                      </Button>
                      {currentUser && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setReplyTo(comment)}
                          className="text-sage-500 hover:text-sage-700 p-0"
                        >
                          <Reply className="w-4 h-4 mr-1" />
                          Reply
                        </Button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Replies */}
                {comment.replies && comment.replies.length > 0 && (
                  <div className="mt-6 pl-14 space-y-4">
                    {comment.replies.map((reply) => (
                      <div key={reply.id} className="bg-sage-50 p-4 organic-border">
                        <div className="flex space-x-3">
                          <div className="w-8 h-8 bg-sage-200 rounded-full flex items-center justify-center flex-shrink-0">
                            <UserIcon className="w-4 h-4 text-sage-600" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <span className="font-semibold text-sage-700 text-sm">
                                {reply.created_by}
                              </span>
                              <span className="text-xs text-sage-500">
                                {format(new Date(reply.created_date), "MMM d 'at' h:mm a")}
                              </span>
                            </div>
                            <p className="text-sage-600 text-sm leading-relaxed whitespace-pre-wrap">
                              {reply.content}
                            </p>
                            <div className="flex items-center space-x-4 mt-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleLikeComment(reply.id)}
                                className="text-sage-500 hover:text-sage-700 p-0 text-xs"
                                disabled={!currentUser}
                              >
                                <Heart className={`w-3 h-3 mr-1 ${reply.likes > 0 ? 'fill-current text-red-500' : ''}`} />
                                {reply.likes || 0}
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </section>
  );
}