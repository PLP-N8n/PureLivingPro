import React from "react";
import { Button } from "@/components/ui/button";
import { Share2, X } from "lucide-react";

export default function SocialShare({ post }) {
  const shareUrl = window.location.href;
  const shareText = `Check out this wellness article: ${post.title}`;

  const shareOnTwitter = () => {
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`, '_blank');
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareUrl);
    // You could add a toast notification here
  };

  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-sage-600 mr-2">Share:</span>
      <Button
        variant="outline"
        size="sm"
        onClick={shareOnTwitter}
        aria-label="Share on X / Twitter"
        className="border-sage-200 text-sage-600 hover:bg-sage-50"
      >
        <X className="w-4 h-4" />
      </Button>
      <Button
        variant="outline"
        size="sm"
        onClick={copyToClipboard}
        aria-label="Copy link to clipboard"
        className="border-sage-200 text-sage-600 hover:bg-sage-50"
      >
        <Share2 className="w-4 h-4" />
      </Button>
    </div>
  );
}