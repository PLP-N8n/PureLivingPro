import React from "react";
import { BookOpen, Sparkles } from "lucide-react";

export default function BlogHeader() {
  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 text-center">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-center mb-6">
          <Sparkles className="w-6 h-6 text-sage-600 mr-2" />
          <span className="text-sage-600 font-medium uppercase tracking-wider text-sm">
            Wellness Insights
          </span>
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold text-sage-700 mb-6">
          Transform Your Wellness Journey
        </h1>
        
        <p className="text-xl text-sage-600 leading-relaxed max-w-3xl mx-auto">
          Discover evidence-based insights, practical guides, and inspiring stories 
          to support your path to holistic health and mindful living.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12 pt-8 border-t border-sage-200">
          <div className="text-center">
            <div className="text-3xl font-bold text-sage-700">500+</div>
            <div className="text-sage-600">Expert Articles</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-sage-700">7</div>
            <div className="text-sage-600">Wellness Categories</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-sage-700">50K+</div>
            <div className="text-sage-600">Monthly Readers</div>
          </div>
        </div>
      </div>
    </section>
  );
}