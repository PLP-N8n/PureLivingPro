import React from "react";
import { Button } from "@/components/ui/button";

export default function CategoryFilter({ categories, selectedCategory, onCategoryChange }) {
  return (
    <div className="flex flex-wrap gap-3">
      {categories.map((category) => (
        <Button
          key={category.slug}
          variant={selectedCategory === category.slug ? "default" : "outline"}
          onClick={() => onCategoryChange(category.slug)}
          className={`organic-border transition-all duration-300 ${
            selectedCategory === category.slug
              ? "bg-sage-600 hover:bg-sage-700 text-white premium-shadow"
              : "border-sage-200 text-sage-700 hover:bg-sage-50 hover:border-sage-300"
          }`}
        >
          {category.name}
        </Button>
      ))}
    </div>
  );
}