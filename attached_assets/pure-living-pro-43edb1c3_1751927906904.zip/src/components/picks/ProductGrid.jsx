import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, ExternalLink, Heart } from "lucide-react";

const badgeConfig = {
  "editors-pick": { label: "Editor's Pick", color: "bg-sage-500 text-white" },
  "best-seller": { label: "Best Seller", color: "bg-amber-500 text-white" },
  "budget-buy": { label: "Budget Buy", color: "bg-blue-500 text-white" },
  "trending": { label: "Trending", color: "bg-purple-500 text-white" }
};

function ProductCard({ product }) {
  if (!product || !product.id) return null;

  const safeProduct = {
    id: product.id,
    name: product.name || "Unnamed Product",
    description: product.description || "No description available.",
    category: product.category || "general",
    image_url: product.image_url,
    affiliate_link: product.affiliate_link || "#",
    original_price: product.original_price || 0,
    discounted_price: product.discounted_price,
    rating: product.rating || 0,
    review_count: product.review_count || 0,
    badge: product.badge
  };

  const handleProductClick = (e) => {
    e.preventDefault();
    
    // Validate affiliate link
    if (!safeProduct.affiliate_link || safeProduct.affiliate_link === "#") {
      console.error("Invalid affiliate link for product:", safeProduct.name);
      return;
    }

    // Log the click for analytics
    console.log("Product clicked:", safeProduct.name, "Link:", safeProduct.affiliate_link);

    // Open in new tab with proper security attributes
    const newWindow = window.open(safeProduct.affiliate_link, '_blank', 'noopener,noreferrer');
    
    // Fallback if popup is blocked
    if (!newWindow) {
      window.location.href = safeProduct.affiliate_link;
    }
  };

  return (
    <div className="group cursor-pointer" onClick={handleProductClick}>
      <Card className="h-full border-0 bg-white shadow-lg hover:shadow-xl transition-all duration-300 group-hover:scale-105 rounded-2xl overflow-hidden">
        <CardContent className="p-0 h-full flex flex-col">
          <div className="relative h-48 overflow-hidden">
            <img
              src={safeProduct.image_url || "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"}
              alt={safeProduct.name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              onError={(e) => {
                e.target.src = "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80";
              }}
            />
            {safeProduct.badge && badgeConfig[safeProduct.badge] && (
              <Badge className={`absolute top-3 left-3 ${badgeConfig[safeProduct.badge].color} rounded-full`}>
                {badgeConfig[safeProduct.badge].label}
              </Badge>
            )}
            <div className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Heart className="w-4 h-4 text-sage-600" />
            </div>
          </div>

          <div className="p-6 flex-1 flex flex-col">
            <h3 className="font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-sage-700 transition-colors">
              {safeProduct.name}
            </h3>
            <p className="text-sm text-gray-600 mb-3 line-clamp-2 flex-1">
              {safeProduct.description}
            </p>
            
            {safeProduct.rating > 0 && (
              <div className="flex items-center mb-3">
                <div className="flex items-center">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${i < safeProduct.rating ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-500 ml-2">({safeProduct.review_count})</span>
              </div>
            )}

            <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-100">
              <div className="flex items-baseline space-x-2">
                {safeProduct.discounted_price && safeProduct.original_price && safeProduct.discounted_price < safeProduct.original_price && (
                  <span className="text-sm text-gray-400 line-through">
                    £{safeProduct.original_price}
                  </span>
                )}
                <span className="text-lg font-bold text-gray-900">
                  £{safeProduct.discounted_price || safeProduct.original_price}
                </span>
              </div>
              <Button 
                size="sm" 
                className="bg-sage-600 hover:bg-sage-700 text-white rounded-full group/btn"
                onClick={(e) => {
                  e.stopPropagation();
                  handleProductClick(e);
                }}
              >
                Buy Now
                <ExternalLink className="w-4 h-4 ml-1 group-hover/btn:translate-x-0.5 transition-transform" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function ProductGrid({ products, isLoading }) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {Array.from({ length: 6 }).map((_, i) => (
          <Card key={i} className="rounded-2xl animate-pulse">
            <CardContent className="p-0">
              <div className="h-48 bg-gray-200 rounded-t-2xl"></div>
              <div className="p-6 space-y-3">
                <div className="h-6 bg-gray-200 rounded"></div>
                <div className="h-16 bg-gray-200 rounded"></div>
                <div className="flex justify-between">
                  <div className="h-4 w-24 bg-gray-200 rounded"></div>
                  <div className="h-4 w-20 bg-gray-200 rounded"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!products || products.length === 0) {
    return (
      <div className="text-center py-16">
        <Heart className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-900 mb-2">No products found</h3>
        <p className="text-gray-600">Try adjusting your search or filter criteria.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}