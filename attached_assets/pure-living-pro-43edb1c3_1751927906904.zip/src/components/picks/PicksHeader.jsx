import React from "react";
import { Heart, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

export default function PicksHeader() {
  return (
    <div className="relative bg-sage-50/50 dark:bg-gray-800/20 pt-16 pb-20 text-center">
      <div className="absolute inset-0 opacity-10 dark:opacity-5">
        <div className="absolute top-0 left-0 w-32 h-32 bg-sage-500 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-48 h-48 bg-amber-400 rounded-full blur-3xl" />
      </div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative max-w-4xl mx-auto px-4"
      >
        <div className="inline-flex items-center justify-center bg-white/80 dark:bg-gray-900/50 backdrop-blur-sm organic-border px-4 py-2 mb-6">
          <Heart className="w-6 h-6 text-sage-600 mr-2" />
          <span className="text-sage-600 font-medium uppercase tracking-wider text-sm">
            Our Wellness Picks
          </span>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-sage-700 dark:text-white mb-4">
          Expertly Curated Wellness Essentials
        </h1>
        <p className="text-lg text-sage-600 dark:text-sage-400 max-w-2xl mx-auto">
          Discover products we trust and recommend. Each item is hand-picked by our experts to support your holistic wellness journey.
        </p>
      </motion.div>
    </div>
  );
}