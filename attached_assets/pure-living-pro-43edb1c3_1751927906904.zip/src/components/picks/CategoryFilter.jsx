import React from "react";
import { Button } from "@/components/ui/button";

const categories = [
  { name: "All Products", slug: "all" },
  { name: "Supplements", slug: "supplements" },
  { name: "Skincare", slug: "skincare" },
  { name: "Fitness Gear", slug: "fitness-equipment" },
  { name: "Meditation Tools", slug: "meditation-tools" },
  { name: "Aromatherapy", slug: "aromatherapy" },
];

const badges = [
  { name: "All Badges", slug: "all" },
  { name: "Editor's Pick", slug: "editors-pick" },
  { name: "Best Seller", slug: "best-seller" },
  { name: "Trending", slug: "trending" },
  { name: "Budget Buy", slug: "budget-buy" },
];

export default function CategoryFilter({ onFilterChange, activeFilters }) {
  return (
    <div className="space-y-6">
      <div>
        <h4 className="text-sm font-semibold text-sage-600 mb-3 text-center">Filter by Category</h4>
        <div className="flex flex-wrap justify-center gap-2">
          {categories.map((cat) => (
            <Button
              key={cat.slug}
              variant={activeFilters.category === cat.slug ? "default" : "outline"}
              onClick={() => onFilterChange('category', cat.slug)}
              className={`organic-border ${activeFilters.category === cat.slug ? 'bg-sage-600 hover:bg-sage-700' : 'border-sage-300 text-sage-700 hover:bg-sage-50'}`}
            >
              {cat.name}
            </Button>
          ))}
        </div>
      </div>
      <div>
        <h4 className="text-sm font-semibold text-sage-600 mb-3 text-center">Filter by Badge</h4>
        <div className="flex flex-wrap justify-center gap-2">
          {badges.map((badge) => (
            <Button
              key={badge.slug}
              variant={activeFilters.badge === badge.slug ? "default" : "outline"}
              onClick={() => onFilterChange('badge', badge.slug)}
              className={`organic-border ${activeFilters.badge === badge.slug ? 'bg-sage-600 hover:bg-sage-700' : 'border-sage-300 text-sage-700 hover:bg-sage-50'}`}
            >
              {badge.name}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}