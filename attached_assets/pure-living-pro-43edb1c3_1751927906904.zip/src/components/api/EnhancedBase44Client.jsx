import { User } from '@/api/entities';

// Enhanced API wrapper with caching, retry logic, and error handling
class EnhancedBase44Client {
  constructor() {
    this.cache = new Map();
    this.requestQueue = new Map();
    this.errorLog = [];
    this.config = {
      cache: {
        enabled: true,
        defaultTTL: 300000, // 5 minutes
        maxSize: 100
      },
      retry: {
        attempts: 3,
        delay: 1000,
        exponentialBackoff: true,
        retryableErrors: ['NetworkError', 'TimeoutError', '503', '502', '504']
      },
      timeout: 15000 // 15 seconds
    };
    
    // Periodic cache cleanup
    setInterval(() => this.cleanupCache(), 60000); // Every minute
  }

  // Helper to detect development mode
  isDevelopmentMode() {
    return window.location.hostname === 'localhost' || 
           window.location.hostname === '127.0.0.1' ||
           window.location.hostname.includes('dev') ||
           window.location.port !== '';
  }

  // Generate cache key for requests
  getCacheKey(entity, method, params = {}) {
    const sortedParams = JSON.stringify(params, Object.keys(params).sort());
    return `${entity}-${method}-${sortedParams}`;
  }

  // Check if error is retryable
  isRetryableError(error) {
    const errorString = error.toString();
    return this.config.retry.retryableErrors.some(retryableError => 
      errorString.includes(retryableError)
    );
  }

  // Exponential backoff delay calculation
  calculateDelay(attempt) {
    const baseDelay = this.config.retry.delay;
    return this.config.retry.exponentialBackoff 
      ? baseDelay * Math.pow(2, attempt - 1) + Math.random() * 1000
      : baseDelay;
  }

  // Log errors for debugging and monitoring
  logError(error, context = {}) {
    const errorEntry = {
      timestamp: new Date().toISOString(),
      error: error.message || error.toString(),
      stack: error.stack,
      context,
      url: window.location.href,
      userAgent: navigator.userAgent
    };

    this.errorLog.unshift(errorEntry);
    if (this.errorLog.length > 50) {
      this.errorLog = this.errorLog.slice(0, 50);
    }

    // Log to console in development
    if (this.isDevelopmentMode()) {
      console.error('Base44 Client Error:', errorEntry);
    }

    // Could integrate with external error tracking service here
    // e.g., Sentry, LogRocket, etc.
  }

  // Cache management
  setCache(key, data, ttl = this.config.cache.defaultTTL) {
    if (!this.config.cache.enabled) return;

    // Remove oldest entries if cache is full
    if (this.cache.size >= this.config.cache.maxSize) {
      const oldestKey = this.cache.keys().next().value;
      this.cache.delete(oldestKey);
    }

    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  getCache(key) {
    if (!this.config.cache.enabled) return null;

    const cached = this.cache.get(key);
    if (!cached) return null;

    // Check if cache has expired
    if (Date.now() - cached.timestamp > cached.ttl) {
      this.cache.delete(key);
      return null;
    }

    return cached.data;
  }

  cleanupCache() {
    const now = Date.now();
    for (const [key, cached] of this.cache.entries()) {
      if (now - cached.timestamp > cached.ttl) {
        this.cache.delete(key);
      }
    }
  }

  // Enhanced request execution with retry logic
  async executeWithRetry(requestFn, context = {}) {
    const maxRetries = this.config.retry.attempts;
    let lastError;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        // Add timeout to request
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('Request timeout')), this.config.timeout);
        });

        const result = await Promise.race([requestFn(), timeoutPromise]);
        
        // Log successful retry if not first attempt
        if (attempt > 1) {
          console.log(`Request succeeded on attempt ${attempt}`, context);
        }
        
        return result;
      } catch (error) {
        lastError = error;
        
        // Don't retry on last attempt or non-retryable errors
        if (attempt === maxRetries || !this.isRetryableError(error)) {
          break;
        }

        // Wait before retrying
        const delay = this.calculateDelay(attempt);
        console.warn(`Request failed, retrying in ${delay}ms (attempt ${attempt}/${maxRetries})`, {
          error: error.message,
          context
        });
        
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    // Log final error
    this.logError(lastError, { ...context, attempts: maxRetries });
    throw lastError;
  }

  // Enhanced entity list method
  async list(EntityClass, sortBy = "-created_date", limit = 50, options = {}) {
    const cacheKey = this.getCacheKey(EntityClass.name, 'list', { sortBy, limit });
    
    // Return cached data if available and not forcing refresh
    if (!options.forceRefresh) {
      const cached = this.getCache(cacheKey);
      if (cached) {
        console.log(`Cache hit for ${EntityClass.name}.list`);
        return cached;
      }
    }

    // Deduplicate concurrent requests
    if (this.requestQueue.has(cacheKey)) {
      console.log(`Deduplicating request for ${EntityClass.name}.list`);
      return this.requestQueue.get(cacheKey);
    }

    const requestPromise = this.executeWithRetry(
      () => EntityClass.list(sortBy, limit),
      { entity: EntityClass.name, method: 'list', sortBy, limit }
    );

    this.requestQueue.set(cacheKey, requestPromise);

    try {
      const result = await requestPromise;
      
      // Cache successful results
      this.setCache(cacheKey, result, options.cacheTTL);
      
      return result;
    } catch (error) {
      // Return stale cache data if available during errors
      const staleCache = this.cache.get(cacheKey);
      if (staleCache && options.returnStaleOnError !== false) {
        console.warn(`Returning stale data for ${EntityClass.name}.list due to error:`, error.message);
        return staleCache.data;
      }
      
      throw error;
    } finally {
      this.requestQueue.delete(cacheKey);
    }
  }

  // Enhanced entity filter method
  async filter(EntityClass, filters = {}, sortBy = "-created_date", limit = 50, options = {}) {
    const cacheKey = this.getCacheKey(EntityClass.name, 'filter', { filters, sortBy, limit });
    
    // Return cached data if available and not forcing refresh
    if (!options.forceRefresh) {
      const cached = this.getCache(cacheKey);
      if (cached) {
        console.log(`Cache hit for ${EntityClass.name}.filter`);
        return cached;
      }
    }

    // Deduplicate concurrent requests
    if (this.requestQueue.has(cacheKey)) {
      console.log(`Deduplicating request for ${EntityClass.name}.filter`);
      return this.requestQueue.get(cacheKey);
    }

    const requestPromise = this.executeWithRetry(
      () => EntityClass.filter(filters, sortBy, limit),
      { entity: EntityClass.name, method: 'filter', filters, sortBy, limit }
    );

    this.requestQueue.set(cacheKey, requestPromise);

    try {
      const result = await requestPromise;
      
      // Cache successful results
      this.setCache(cacheKey, result, options.cacheTTL);
      
      return result;
    } catch (error) {
      // Return stale cache data if available during errors
      const staleCache = this.cache.get(cacheKey);
      if (staleCache && options.returnStaleOnError !== false) {
        console.warn(`Returning stale data for ${EntityClass.name}.filter due to error:`, error.message);
        return staleCache.data;
      }
      
      throw error;
    } finally {
      this.requestQueue.delete(cacheKey);
    }
  }

  // Enhanced entity create method
  async create(EntityClass, data, options = {}) {
    try {
      const result = await this.executeWithRetry(
        () => EntityClass.create(data),
        { entity: EntityClass.name, method: 'create', data }
      );

      // Invalidate relevant caches after successful create
      this.invalidateEntityCache(EntityClass.name);
      
      return result;
    } catch (error) {
      throw error;
    }
  }

  // Enhanced entity update method
  async update(EntityClass, id, data, options = {}) {
    try {
      const result = await this.executeWithRetry(
        () => EntityClass.update(id, data),
        { entity: EntityClass.name, method: 'update', id, data }
      );

      // Invalidate relevant caches after successful update
      this.invalidateEntityCache(EntityClass.name);
      
      return result;
    } catch (error) {
      throw error;
    }
  }

  // Enhanced entity delete method
  async delete(EntityClass, id, options = {}) {
    try {
      const result = await this.executeWithRetry(
        () => EntityClass.delete(id),
        { entity: EntityClass.name, method: 'delete', id }
      );

      // Invalidate relevant caches after successful delete
      this.invalidateEntityCache(EntityClass.name);
      
      return result;
    } catch (error) {
      throw error;
    }
  }

  // Invalidate cache entries for a specific entity
  invalidateEntityCache(entityName) {
    const keysToDelete = [];
    for (const key of this.cache.keys()) {
      if (key.startsWith(`${entityName}-`)) {
        keysToDelete.push(key);
      }
    }
    keysToDelete.forEach(key => this.cache.delete(key));
    console.log(`Invalidated ${keysToDelete.length} cache entries for ${entityName}`);
  }

  // Clear all cache
  clearCache() {
    this.cache.clear();
    console.log('Cache cleared');
  }

  // Get cache statistics
  getCacheStats() {
    return {
      size: this.cache.size,
      maxSize: this.config.cache.maxSize,
      enabled: this.config.cache.enabled,
      entries: Array.from(this.cache.entries()).map(([key, value]) => ({
        key,
        age: Date.now() - value.timestamp,
        ttl: value.ttl
      }))
    };
  }

  // Get error log
  getErrorLog() {
    return [...this.errorLog];
  }

  // Update configuration
  updateConfig(newConfig) {
    this.config = { ...this.config, ...newConfig };
  }
}

// Create singleton instance
export const enhancedBase44Client = new EnhancedBase44Client();

// Export convenience methods that wrap the enhanced client
export const enhancedEntityMethods = {
  list: (EntityClass, sortBy, limit, options) => 
    enhancedBase44Client.list(EntityClass, sortBy, limit, options),
  
  filter: (EntityClass, filters, sortBy, limit, options) => 
    enhancedBase44Client.filter(EntityClass, filters, sortBy, limit, options),
  
  create: (EntityClass, data, options) => 
    enhancedBase44Client.create(EntityClass, data, options),
  
  update: (EntityClass, id, data, options) => 
    enhancedBase44Client.update(EntityClass, id, data, options),
  
  delete: (EntityClass, id, options) => 
    enhancedBase44Client.delete(EntityClass, id, options)
};

export default enhancedBase44Client;