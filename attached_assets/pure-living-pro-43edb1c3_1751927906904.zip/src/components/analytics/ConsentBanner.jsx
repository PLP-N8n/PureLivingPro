import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, Shield, BarChart3 } from 'lucide-react';
import { useAnalytics } from './AnalyticsProvider';

export default function ConsentBanner() {
  const [showBanner, setShowBanner] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const { setConsent } = useAnalytics();

  useEffect(() => {
    // Check if user has already made a consent choice
    const consent = localStorage.getItem('analytics_consent');
    if (consent === null) {
      setShowBanner(true);
    }
  }, []);

  const handleAccept = () => {
    setConsent(true);
    setShowBanner(false);
    localStorage.setItem('analytics_consent_date', new Date().toISOString());
  };

  const handleDecline = () => {
    setConsent(false);
    setShowBanner(false);
    localStorage.setItem('analytics_consent_date', new Date().toISOString());
  };

  const handleDismiss = () => {
    setShowBanner(false);
    // Don't set consent, let user decide later
  };

  if (!showBanner) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 max-w-md mx-auto">
      <Card className="shadow-2xl border-2 border-primary/20 bg-card/95 backdrop-blur-sm">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center">
              <Shield className="w-5 h-5 text-primary mr-2" />
              <h3 className="font-semibold text-card-foreground">Privacy & Analytics</h3>
            </div>
            <button
              onClick={handleDismiss}
              className="text-muted-foreground hover:text-card-foreground transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-sm text-muted-foreground mb-4">
            We use analytics to improve your experience and understand how our content helps your wellness journey.
          </p>

          {showDetails && (
            <div className="mb-4 p-3 bg-muted/50 rounded-lg text-xs text-muted-foreground">
              <div className="flex items-center mb-2">
                <BarChart3 className="w-4 h-4 mr-2" />
                <span className="font-medium">What we track:</span>
              </div>
              <ul className="space-y-1 ml-6">
                <li>• Page views and popular content</li>
                <li>• User engagement and preferences</li>
                <li>• Site performance and errors</li>
                <li>• Anonymous usage patterns</li>
              </ul>
              <p className="mt-2 text-xs">
                We never track personal information or sell your data.
              </p>
            </div>
          )}

          <div className="flex flex-col gap-2">
            <div className="flex gap-2">
              <Button
                onClick={handleAccept}
                className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                size="sm"
              >
                Accept
              </Button>
              <Button
                onClick={handleDecline}
                variant="outline"
                className="flex-1"
                size="sm"
              >
                Decline
              </Button>
            </div>
            
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="text-xs text-muted-foreground hover:text-card-foreground transition-colors"
            >
              {showDetails ? 'Hide details' : 'Learn more'}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}