import React, { createContext, useContext, useEffect, useState } from 'react';

const AnalyticsContext = createContext(null);

// Analytics configuration
const ANALYTICS_CONFIG = {
  // Enable/disable different analytics providers
  providers: {
    googleAnalytics: true,
    facebookPixel: true,
    customEvents: true,
    performanceTracking: true
  },
  
  // Tracking IDs (replace with your actual IDs)
  trackingIds: {
    googleAnalytics: 'GA_MEASUREMENT_ID', // Replace with actual GA4 ID
    facebookPixel: 'FB_PIXEL_ID', // Replace with actual Facebook Pixel ID
  },
  
  // Event configuration
  events: {
    pageView: true,
    userEngagement: true,
    contentInteraction: true,
    ecommerce: true,
    performance: true
  },
  
  // Privacy settings
  privacy: {
    respectDoNotTrack: true,
    consentRequired: false, // Set to true if GDPR compliance needed
    anonymizeIp: true
  }
};

class AnalyticsManager {
  constructor() {
    this.initialized = false;
    this.providers = new Map();
    this.eventQueue = [];
    this.sessionData = {
      sessionId: this.generateSessionId(),
      startTime: Date.now(),
      pageViews: 0,
      events: []
    };
  }

  generateSessionId() {
    return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  // Check if tracking is allowed
  isTrackingAllowed() {
    if (ANALYTICS_CONFIG.privacy.respectDoNotTrack && navigator.doNotTrack === '1') {
      return false;
    }
    
    if (ANALYTICS_CONFIG.privacy.consentRequired) {
      return localStorage.getItem('analytics_consent') === 'true';
    }
    
    return true;
  }

  // Initialize analytics providers
  async initialize() {
    if (this.initialized || !this.isTrackingAllowed()) {
      return;
    }

    try {
      // Initialize Google Analytics 4
      if (ANALYTICS_CONFIG.providers.googleAnalytics) {
        await this.initializeGA4();
      }

      // Initialize Facebook Pixel
      if (ANALYTICS_CONFIG.providers.facebookPixel) {
        await this.initializeFacebookPixel();
      }

      // Initialize custom event tracking
      if (ANALYTICS_CONFIG.providers.customEvents) {
        this.initializeCustomTracking();
      }

      // Initialize performance tracking
      if (ANALYTICS_CONFIG.providers.performanceTracking) {
        this.initializePerformanceTracking();
      }

      this.initialized = true;
      this.processEventQueue();

      console.log('Analytics initialized successfully');
    } catch (error) {
      console.error('Analytics initialization failed:', error);
    }
  }

  // Initialize Google Analytics 4
  async initializeGA4() {
    try {
      // Initialize gtag function and dataLayer first
      window.dataLayer = window.dataLayer || [];
      function gtag(){window.dataLayer.push(arguments);}
      window.gtag = gtag;
      
      // Load gtag library
      const script = document.createElement('script');
      script.src = `https://www.googletagmanager.com/gtag/js?id=${ANALYTICS_CONFIG.trackingIds.googleAnalytics}`;
      script.async = true;
      
      // Wait for script to load
      await new Promise((resolve, reject) => {
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
      });
      
      // Configure gtag after script loads
      gtag('js', new Date());
      gtag('config', ANALYTICS_CONFIG.trackingIds.googleAnalytics, {
        anonymize_ip: ANALYTICS_CONFIG.privacy.anonymizeIp,
        send_page_view: false // We'll handle page views manually
      });

      this.providers.set('ga4', gtag);
      console.log('Google Analytics 4 initialized successfully');
    } catch (error) {
      console.error('Failed to initialize Google Analytics:', error);
    }
  }

  // Initialize Facebook Pixel
  async initializeFacebookPixel() {
    try {
      // Initialize fbq function first
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');

      // Wait a moment for fbq to be available
      await new Promise(resolve => setTimeout(resolve, 100));
      
      if (window.fbq) {
        window.fbq('init', ANALYTICS_CONFIG.trackingIds.facebookPixel);
        this.providers.set('fbq', window.fbq);
        console.log('Facebook Pixel initialized successfully');
      } else {
        throw new Error('Facebook Pixel failed to load');
      }
    } catch (error) {
      console.error('Failed to initialize Facebook Pixel:', error);
    }
  }

  // Initialize custom event tracking
  initializeCustomTracking() {
    this.providers.set('custom', {
      track: (eventName, properties) => {
        this.sessionData.events.push({
          event: eventName,
          properties,
          timestamp: Date.now()
        });
        
        // Store in localStorage for persistence
        try {
          const existingEvents = JSON.parse(localStorage.getItem('analytics_events') || '[]');
          existingEvents.push({
            event: eventName,
            properties,
            timestamp: Date.now(),
            sessionId: this.sessionData.sessionId
          });
          
          // Keep only last 100 events
          if (existingEvents.length > 100) {
            existingEvents.splice(0, existingEvents.length - 100);
          }
          
          localStorage.setItem('analytics_events', JSON.stringify(existingEvents));
        } catch (error) {
          console.warn('Failed to store custom analytics event:', error);
        }
      }
    });
  }

  // Initialize performance tracking
  initializePerformanceTracking() {
    // Track page load performance
    if (window.performance && window.performance.timing) {
      const timing = window.performance.timing;
      const loadTime = timing.loadEventEnd - timing.navigationStart;
      
      if (loadTime > 0) {
        this.track('page_performance', {
          load_time: loadTime,
          dom_ready: timing.domContentLoadedEventEnd - timing.navigationStart,
          first_byte: timing.responseStart - timing.navigationStart
        });
      }
    }

    // Track Core Web Vitals with error handling
    if ('PerformanceObserver' in window) {
      try {
        // Largest Contentful Paint
        new PerformanceObserver((entryList) => {
          const entries = entryList.getEntries();
          const lastEntry = entries[entries.length - 1];
          this.track('core_web_vitals', {
            metric: 'LCP',
            value: lastEntry.startTime
          });
        }).observe({ entryTypes: ['largest-contentful-paint'] });
      } catch (error) {
        console.warn('LCP tracking not supported:', error);
      }

      try {
        // First Input Delay
        new PerformanceObserver((entryList) => {
          const firstInput = entryList.getEntries()[0];
          this.track('core_web_vitals', {
            metric: 'FID',
            value: firstInput.processingStart - firstInput.startTime
          });
        }).observe({ entryTypes: ['first-input'] });
      } catch (error) {
        console.warn('FID tracking not supported:', error);
      }

      try {
        // Cumulative Layout Shift
        let clsValue = 0;
        new PerformanceObserver((entryList) => {
          for (const entry of entryList.getEntries()) {
            if (!entry.hadRecentInput) {
              clsValue += entry.value;
            }
          }
          this.track('core_web_vitals', {
            metric: 'CLS',
            value: clsValue
          });
        }).observe({ entryTypes: ['layout-shift'] });
      } catch (error) {
        console.warn('CLS tracking not supported:', error);
      }
    }
  }

  // Queue events if not initialized
  queueEvent(eventName, properties) {
    this.eventQueue.push({ eventName, properties, timestamp: Date.now() });
  }

  // Process queued events
  processEventQueue() {
    while (this.eventQueue.length > 0) {
      const { eventName, properties } = this.eventQueue.shift();
      this.track(eventName, properties);
    }
  }

  // Main tracking method
  track(eventName, properties = {}) {
    if (!this.isTrackingAllowed()) {
      return;
    }

    if (!this.initialized) {
      this.queueEvent(eventName, properties);
      return;
    }

    const enrichedProperties = {
      ...properties,
      session_id: this.sessionData.sessionId,
      timestamp: Date.now(),
      page_url: window.location.href,
      page_title: document.title,
      referrer: document.referrer,
      user_agent: navigator.userAgent,
      screen_resolution: `${screen.width}x${screen.height}`,
      viewport_size: `${window.innerWidth}x${window.innerHeight}`
    };

    // Send to Google Analytics
    if (this.providers.has('ga4')) {
      try {
        const gtag = this.providers.get('ga4');
        gtag('event', eventName, enrichedProperties);
      } catch (error) {
        console.warn('Failed to send GA4 event:', error);
      }
    }

    // Send to Facebook Pixel
    if (this.providers.has('fbq')) {
      try {
        const fbq = this.providers.get('fbq');
        fbq('track', eventName, enrichedProperties);
      } catch (error) {
        console.warn('Failed to send Facebook Pixel event:', error);
      }
    }

    // Send to custom tracking
    if (this.providers.has('custom')) {
      try {
        const custom = this.providers.get('custom');
        custom.track(eventName, enrichedProperties);
      } catch (error) {
        console.warn('Failed to send custom event:', error);
      }
    }

    // Log in development
    if (window.location.hostname === 'localhost') {
      console.log('Analytics Event:', eventName, enrichedProperties);
    }
  }

  // Specific tracking methods
  trackPageView(path, title) {
    this.sessionData.pageViews++;
    this.track('page_view', {
      page_path: path,
      page_title: title,
      session_page_views: this.sessionData.pageViews
    });
  }

  trackUserEngagement(action, category, label, value) {
    this.track('user_engagement', {
      action,
      category,
      label,
      value
    });
  }

  trackContentInteraction(contentType, contentId, action, metadata = {}) {
    this.track('content_interaction', {
      content_type: contentType,
      content_id: contentId,
      action,
      ...metadata
    });
  }

  trackEcommerce(action, products, transactionData = {}) {
    this.track('ecommerce', {
      action,
      products,
      ...transactionData
    });
  }

  trackError(error, context = {}) {
    this.track('error', {
      error_message: error.message,
      error_stack: error.stack,
      ...context
    });
  }

  // Get analytics data for dashboard
  getAnalyticsData() {
    try {
      const storedEvents = JSON.parse(localStorage.getItem('analytics_events') || '[]');
      return {
        session: this.sessionData,
        recentEvents: storedEvents.slice(-20),
        totalEvents: storedEvents.length
      };
    } catch (error) {
      console.error('Failed to retrieve analytics data:', error);
      return {
        session: this.sessionData,
        recentEvents: [],
        totalEvents: 0
      };
    }
  }

  // Set user consent
  setConsent(consent) {
    localStorage.setItem('analytics_consent', consent.toString());
    if (consent && !this.initialized) {
      this.initialize();
    }
  }
}

// Create analytics manager instance
const analyticsManager = new AnalyticsManager();

export function AnalyticsProvider({ children }) {
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    // Initialize analytics when component mounts
    analyticsManager.initialize().then(() => {
      setIsInitialized(true);
    });
  }, []);

  const value = {
    // Core tracking methods
    track: analyticsManager.track.bind(analyticsManager),
    trackPageView: analyticsManager.trackPageView.bind(analyticsManager),
    trackUserEngagement: analyticsManager.trackUserEngagement.bind(analyticsManager),
    trackContentInteraction: analyticsManager.trackContentInteraction.bind(analyticsManager),
    trackEcommerce: analyticsManager.trackEcommerce.bind(analyticsManager),
    trackError: analyticsManager.trackError.bind(analyticsManager),
    
    // Utility methods
    getAnalyticsData: analyticsManager.getAnalyticsData.bind(analyticsManager),
    setConsent: analyticsManager.setConsent.bind(analyticsManager),
    isInitialized,
    isTrackingAllowed: analyticsManager.isTrackingAllowed()
  };

  return (
    <AnalyticsContext.Provider value={value}>
      {children}
    </AnalyticsContext.Provider>
  );
}

export function useAnalytics() {
  const context = useContext(AnalyticsContext);
  if (!context) {
    throw new Error('useAnalytics must be used within an AnalyticsProvider');
  }
  return context;
}

export default AnalyticsProvider;