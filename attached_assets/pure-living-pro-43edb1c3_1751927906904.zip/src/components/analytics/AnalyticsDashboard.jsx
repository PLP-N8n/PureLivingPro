import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  BarChart3, 
  Users, 
  Eye, 
  Clock, 
  TrendingUp, 
  MousePointer,
  Smartphone,
  Monitor,
  RefreshCw
} from 'lucide-react';
import { useAnalytics } from './AnalyticsProvider';

export default function AnalyticsDashboard() {
  const { getAnalyticsData, isInitialized } = useAnalytics();
  const [analyticsData, setAnalyticsData] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const refreshData = () => {
    const data = getAnalyticsData();
    setAnalyticsData(data);
    setLastUpdated(new Date());
  };

  useEffect(() => {
    if (isInitialized) {
      refreshData();
    }
  }, [isInitialized]);

  if (!isInitialized) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Analytics initializing...</p>
        </CardContent>
      </Card>
    );
  }

  if (!analyticsData) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-muted-foreground">No analytics data available yet.</p>
          <Button onClick={refreshData} className="mt-4">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh Data
          </Button>
        </CardContent>
      </Card>
    );
  }

  const { session, recentEvents, totalEvents } = analyticsData;

  // Process events for insights
  const eventsByType = recentEvents.reduce((acc, event) => {
    acc[event.event] = (acc[event.event] || 0) + 1;
    return acc;
  }, {});

  const contentInteractions = recentEvents.filter(e => e.event === 'content_interaction');
  const pageViews = recentEvents.filter(e => e.event === 'page_view');
  const userEngagements = recentEvents.filter(e => e.event === 'user_engagement');

  // Calculate session duration
  const sessionDuration = Date.now() - session.startTime;
  const sessionMinutes = Math.floor(sessionDuration / 60000);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-card-foreground">Analytics Dashboard</h2>
          <p className="text-muted-foreground">
            Last updated: {lastUpdated.toLocaleTimeString()}
          </p>
        </div>
        <Button onClick={refreshData} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Session Duration</p>
                <p className="text-2xl font-bold text-card-foreground">{sessionMinutes}m</p>
              </div>
              <Clock className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Page Views</p>
                <p className="text-2xl font-bold text-card-foreground">{session.pageViews}</p>
              </div>
              <Eye className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Events</p>
                <p className="text-2xl font-bold text-card-foreground">{totalEvents}</p>
              </div>
              <MousePointer className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Engagement</p>
                <p className="text-2xl font-bold text-card-foreground">{userEngagements.length}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Event Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="w-5 h-5 mr-2" />
              Event Types
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(eventsByType).map(([eventType, count]) => (
                <div key={eventType} className="flex justify-between items-center">
                  <span className="text-sm font-medium text-card-foreground">
                    {eventType.replace('_', ' ').toUpperCase()}
                  </span>
                  <Badge variant="secondary">{count}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {recentEvents.slice(0, 10).map((event, index) => (
                <div key={index} className="flex justify-between items-start text-sm">
                  <div className="flex-1">
                    <p className="font-medium text-card-foreground">
                      {event.event.replace('_', ' ')}
                    </p>
                    {event.properties?.page_path && (
                      <p className="text-muted-foreground text-xs">
                        {event.properties.page_path}
                      </p>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {new Date(event.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content Performance */}
      {contentInteractions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Content Interactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {contentInteractions.slice(0, 6).map((interaction, index) => (
                <div key={index} className="p-3 bg-muted/50 rounded-lg">
                  <p className="font-medium text-sm text-card-foreground">
                    {interaction.properties?.content_type} - {interaction.properties?.action}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    ID: {interaction.properties?.content_id}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(interaction.timestamp).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Session Info */}
      <Card>
        <CardHeader>
          <CardTitle>Session Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Session ID</p>
              <p className="font-mono text-xs text-card-foreground">{session.sessionId}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Start Time</p>
              <p className="text-card-foreground">{new Date(session.startTime).toLocaleString()}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Current URL</p>
              <p className="text-card-foreground text-xs">{window.location.href}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Device Type</p>
              <div className="flex items-center mt-1">
                {window.innerWidth <= 768 ? (
                  <Smartphone className="w-4 h-4 mr-2 text-primary" />
                ) : (
                  <Monitor className="w-4 h-4 mr-2 text-primary" />
                )}
                <span className="text-card-foreground">
                  {window.innerWidth <= 768 ? 'Mobile' : 'Desktop'}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}