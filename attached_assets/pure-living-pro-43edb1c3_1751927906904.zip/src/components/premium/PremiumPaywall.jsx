import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Lock, Crown, Check, Sparkles } from "lucide-react";

const premiumBenefits = [
  "Access to all premium wellness articles",
  "In-depth research & scientific studies",
  "Advanced wellness protocols",
  "Exclusive product recommendations",
  "Priority customer support",
  "Ad-free reading experience"
];

export default function PremiumPaywall({ article }) {
  const handleUpgrade = () => {
    // TODO: Integrate with Stripe or payment processor
    console.log("Upgrade to premium");
  };

  return (
    <div className="relative">
      {/* Preview Content */}
      {article.premium_preview && (
        <div className="mb-8">
          <div className="prose prose-lg max-w-none mb-6">
            <div className="text-sage-700 leading-relaxed">
              {article.premium_preview}
            </div>
          </div>
          
          {/* Fade Effect */}
          <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent pointer-events-none"></div>
        </div>
      )}

      {/* Paywall Card */}
      <Card className="premium-shadow organic-border border-2 border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-amber-200/30 to-transparent rounded-full -mr-16 -mt-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-orange-200/30 to-transparent rounded-full -ml-12 -mb-12"></div>
        
        <CardContent className="p-8 relative">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-amber-500 to-orange-600 organic-border flex items-center justify-center mx-auto mb-6">
              <Crown className="w-10 h-10 text-white" />
            </div>
            
            <Badge className="bg-amber-500 text-white mb-4 px-4 py-2 organic-border">
              <Lock className="w-4 h-4 mr-2" />
              Premium Content
            </Badge>
            
            <h3 className="text-3xl font-bold text-sage-700 mb-4">
              Unlock Premium Wellness Insights
            </h3>
            
            <p className="text-lg text-sage-600 leading-relaxed mb-8">
              This article contains advanced wellness protocols and research-backed insights 
              available exclusively to our Pro members. Join today to access this content 
              and thousands more premium articles.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h4 className="text-xl font-semibold text-sage-700 mb-4 flex items-center">
                <Sparkles className="w-5 h-5 mr-2 text-amber-500" />
                What You'll Get
              </h4>
              <ul className="space-y-3">
                {premiumBenefits.map((benefit, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                    <span className="text-sage-600">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="bg-white/70 p-6 organic-border">
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-sage-700 mb-1">£9.99</div>
                <div className="text-sage-500">per month</div>
                <div className="text-sm text-sage-600 mt-2">Cancel anytime</div>
              </div>
              
              <Button 
                onClick={handleUpgrade}
                className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold py-4 organic-border premium-shadow"
                size="lg"
              >
                <Crown className="w-5 h-5 mr-2" />
                Upgrade to Pro
              </Button>
              
              <p className="text-xs text-sage-500 text-center mt-4">
                ✨ 7-day free trial • No commitment • Instant access
              </p>
            </div>
          </div>

          <div className="text-center">
            <p className="text-sm text-sage-600">
              Already a Pro member? 
              <button className="text-sage-700 font-semibold ml-1 hover:underline">
                Sign in here
              </button>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}