
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Sparkles, Heart } from "lucide-react";
import { motion } from "framer-motion";

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10 dark:opacity-5">
        <motion.div 
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="absolute top-20 left-10 w-32 h-32 bg-sage-500 rounded-full blur-3xl"
        />
        <motion.div 
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="absolute bottom-20 right-10 w-48 h-48 bg-amber-400 rounded-full blur-3xl"
        />
        <motion.div 
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="absolute top-1/2 left-1/3 w-24 h-24 bg-emerald-400 rounded-full blur-2xl"
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-left"
          >
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex items-center justify-center lg:justify-start mb-6"
            >
              <Badge className="bg-sage-100 dark:bg-sage-200/20 text-sage-700 dark:text-sage-600 border-sage-200 dark:border-sage-600/30 px-4 py-2 text-sm font-medium organic-border hover-lift">
                <Sparkles className="w-4 h-4 mr-2" />
                Ancient Wisdom Meets Modern Wellness
              </Badge>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="text-4xl md:text-6xl lg:text-7xl font-bold text-sage-700 dark:text-white leading-tight mb-6"
            >
              Holistic Wellness for
              <span className="block text-transparent bg-gradient-to-r from-sage-600 via-emerald-600 to-amber-600 bg-clip-text">
                Modern Living
              </span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="text-lg md:text-xl text-sage-700/90 dark:text-sage-500 mb-8 max-w-2xl mx-auto lg:mx-0 leading-relaxed"
            >
              Discover the perfect balance of mind, body, and spirit through our curated wellness insights, 
              natural remedies, and mindful living practices designed for today's conscious lifestyle.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.7 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <Link to={createPageUrl("Blog")}>
                <Button className="bg-sage-600 hover:bg-sage-700 dark:bg-sage-500 dark:hover:bg-sage-600 text-white px-8 py-6 text-lg organic-border premium-shadow group hover-lift">
                  Explore Insights
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link to={createPageUrl("WellnessPicks")}>
                <Button variant="outline" className="border-sage-300 dark:border-sage-600 text-sage-700 dark:text-white hover:bg-sage-50 dark:hover:bg-sage-200/10 px-8 py-6 text-lg organic-border hover-lift">
                  <Heart className="w-5 h-5 mr-2" />
                  Our Picks
                </Button>
              </Link>
            </motion.div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 mt-12 pt-8 border-t border-sage-200 dark:border-gray-700">
              <motion.div 
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.8 }}
                transition={{ duration: 0.5 }}
                whileHover={{ scale: 1.05 }}
              >
                <div className="text-2xl md:text-3xl font-bold text-sage-700 dark:text-white">500+</div>
                <div className="text-sm text-sage-700/80 dark:text-sage-500">Wellness Articles</div>
              </motion.div>
              <motion.div 
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.8 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                whileHover={{ scale: 1.05 }}
              >
                <div className="text-2xl md:text-3xl font-bold text-sage-700 dark:text-white">50K+</div>
                <div className="text-sm text-sage-700/80 dark:text-sage-500">Community Members</div>
              </motion.div>
              <motion.div 
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.8 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                whileHover={{ scale: 1.05 }}
              >
                <div className="text-2xl md:text-3xl font-bold text-sage-700 dark:text-white">1000+</div>
                <div className="text-sm text-sage-700/80 dark:text-sage-500">Product Reviews</div>
              </motion.div>
            </div>
          </motion.div>

          {/* Hero Image */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative"
          >
            <div className="relative z-10 premium-shadow organic-border overflow-hidden hover-lift">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/932d9f377_MindfulnessMeditation.jpg"
                alt="Woman in a yoga pose outdoors, embodying holistic wellness."
                className="w-full h-96 md:h-[500px] object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-sage-900/20 to-transparent"></div>
            </div>
            
            {/* Floating Elements */}
            <motion.div 
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 1 }}
              whileHover={{ scale: 1.1 }}
              className="absolute -top-4 -right-4 w-20 h-20 bg-white dark:bg-gray-800 organic-border premium-shadow flex items-center justify-center hover-lift"
            >
              <div className="text-center">
                <div className="text-xl font-bold text-sage-700 dark:text-sage-600">4.9</div>
                <div className="flex justify-center">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <span key={i} className="text-yellow-400 text-xs">★</span>
                  ))}
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 1.2 }}
              whileHover={{ scale: 1.1 }}
              className="absolute -bottom-4 -left-4 w-24 h-24 bg-sage-100 dark:bg-sage-200/20 organic-border premium-shadow flex items-center justify-center hover-lift"
            >
              <div className="text-center">
                <Heart className="w-6 h-6 text-sage-600 dark:text-sage-500 mx-auto mb-1" />
                <div className="text-xs text-sage-600 dark:text-sage-500 font-medium">Trusted</div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
