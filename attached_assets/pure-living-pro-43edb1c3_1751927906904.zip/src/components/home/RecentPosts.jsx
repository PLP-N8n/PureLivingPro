import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Clock, ArrowRight, BookOpen } from "lucide-react";
import { format } from "date-fns";
import { getCloudinaryTransformedUrl } from "@/components/shared/cloudinary";

const categoryColors = {
  "nutrition": "bg-green-100 text-green-800 border-green-200",
  "meditation-mindfulness": "bg-purple-100 text-purple-800 border-purple-200",
  "fitness": "bg-orange-100 text-orange-800 border-orange-200",
  "natural-remedies": "bg-sage-100 text-sage-800 border-sage-200",
  "healthy-recipes": "bg-amber-100 text-amber-800 border-amber-200",
  "supplements": "bg-blue-100 text-blue-800 border-blue-200",
  "skin-selfcare": "bg-pink-100 text-pink-800 border-pink-200"
};

const formatSafeDate = (dateString, fallback = "Recent") => {
  if (!dateString) return fallback;
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return fallback;
    return format(date, "MMM d, yyyy");
  } catch (error) {
    return fallback;
  }
};

export default function RecentPosts({ posts, isLoading }) {
  if (isLoading) {
    return (
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Skeleton className="h-8 w-48 mx-auto mb-4" />
            <Skeleton className="h-12 w-96 mx-auto" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="premium-shadow organic-border">
                <CardContent className="p-0">
                  <Skeleton className="h-48 w-full rounded-t-3xl" />
                  <div className="p-6 space-y-3">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-16 w-full" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-4">
            <BookOpen className="w-6 h-6 text-sage-600 mr-2" />
            <span className="text-sage-600 font-medium uppercase tracking-wider text-sm">
              Latest Insights
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-sage-700 mb-4">
            Fresh Wellness Wisdom
          </h2>
          <p className="text-lg text-sage-600 max-w-2xl mx-auto">
            Stay updated with our latest research-backed articles, practical guides, 
            and inspiring stories from the world of holistic wellness.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {posts.map((post) => (
            <Link key={post.id} to={createPageUrl("BlogPost", post.slug || post.id)} className="group">
              <Card className="premium-shadow organic-border border-0 bg-white group-hover:scale-105 transition-all duration-300 overflow-hidden h-full">
                <CardContent className="p-0 h-full flex flex-col">
                  {/* Featured Image */}
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={getCloudinaryTransformedUrl(post.featured_image, { width: 400, height: 300, crop: 'fill' }) || "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/da8bccf6a_Gemini_Generated_Image_7lhofr7lhofr7lho.jpg"}
                      alt={post.title || "Blog post image"}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                    {post.category && (
                      <Badge className={`absolute top-3 left-3 ${categoryColors[post.category] || 'bg-gray-100'} border organic-border`}>
                        {post.category.replace('-', ' ') || 'Uncategorized'}
                      </Badge>
                    )}
                  </div>

                  {/* Content */}
                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className="text-xl font-bold text-sage-700 mb-3 line-clamp-2 group-hover:text-sage-800 transition-colors">
                      {post.title || "Untitled Post"}
                    </h3>
                    <p className="text-sage-600 mb-4 line-clamp-3 flex-1">
                      {post.excerpt || "No summary available."}
                    </p>
                    
                    <div className="flex items-center justify-between pt-4 border-t border-sage-100">
                      <div className="flex items-center text-sm text-sage-500">
                        <Clock className="w-4 h-4 mr-1" />
                        {post.read_time || 5} min read
                      </div>
                      <div className="text-sm text-sage-500">
                        {formatSafeDate(post.created_date)}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        <div className="text-center">
          <Link to={createPageUrl("Blog")}>
            <Button variant="outline" className="border-sage-300 text-sage-700 hover:bg-sage-50 px-8 py-3 organic-border">
              Read All Articles
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}