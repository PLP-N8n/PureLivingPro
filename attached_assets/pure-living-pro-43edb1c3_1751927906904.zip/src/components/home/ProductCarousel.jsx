
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Star, ExternalLink, TrendingUp, Heart, ArrowRight } from "lucide-react";

const badgeConfig = {
  "editors-pick": { label: "Editor's Pick", color: "bg-sage-500 text-white" },
  "best-seller": { label: "Best Seller", color: "bg-amber-500 text-white" },
  "budget-buy": { label: "Budget Buy", color: "bg-blue-500 text-white" },
  "trending": { label: "Trending", color: "bg-purple-500 text-white" }
};

export default function ProductCarousel({ products, isLoading }) {
  if (isLoading) {
    return (
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Skeleton className="h-8 w-48 mx-auto mb-4" />
            <Skeleton className="h-12 w-96 mx-auto" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i} className="premium-shadow organic-border">
                <CardContent className="p-0">
                  <Skeleton className="h-48 w-full rounded-t-3xl" />
                  <div className="p-6 space-y-3">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-4">
            <TrendingUp className="w-6 h-6 text-sage-600 mr-2" />
            <span className="text-sage-600 font-medium uppercase tracking-wider text-sm">
              Trending Picks
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-sage-700 mb-4">
            Curated Wellness Essentials
          </h2>
          <p className="text-lg text-sage-700/90 max-w-2xl mx-auto">
            Hand-picked products that align with your wellness goals, 
            thoroughly researched and recommended by our wellness experts.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {products.slice(0, 4).map((product) => (
            <Card key={product.id} className="premium-shadow organic-border border-0 bg-white group hover:scale-105 transition-all duration-300 overflow-hidden h-full">
              <CardContent className="p-0 h-full flex flex-col">
                {/* Product Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={product.image_url || "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/c7a35822f_Gemini_Generated_Image_oeihhyoeihhyoeih.jpg"}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    loading="lazy"
                  />
                  {product.badge && badgeConfig[product.badge] && (
                    <Badge className={`absolute top-3 left-3 ${badgeConfig[product.badge].color} organic-border`}>
                      {badgeConfig[product.badge].label}
                    </Badge>
                  )}
                  <div className="absolute top-3 right-3 w-8 h-8 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Heart className="w-4 h-4 text-sage-600" />
                  </div>
                </div>

                {/* Product Info */}
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="font-bold text-sage-700 mb-2 line-clamp-2 group-hover:text-sage-700 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-sm text-sage-700/90 mb-3 line-clamp-2 flex-1">
                    {product.description}
                  </p>
                  
                  {product.rating && (
                    <div className="flex items-center mb-3">
                      <div className="flex items-center">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < product.rating
                                ? "text-yellow-400 fill-current"
                                : "text-gray-300"
                            }`}
                            aria-hidden="true"
                          />
                        ))}
                      </div>
                      <span className="text-sm text-sage-700/80 ml-2">
                        ({product.review_count})
                      </span>
                    </div>
                  )}

                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      {product.discounted_price && product.original_price && (
                        <span className="text-sm text-gray-400 line-through">
                          £{product.original_price}
                        </span>
                      )}
                      <span className="text-lg font-bold text-sage-700">
                        £{product.discounted_price || product.original_price}
                      </span>
                    </div>
                  </div>

                  <a
                    href={product.affiliate_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block mt-auto"
                  >
                    <Button className="w-full bg-sage-600 hover:bg-sage-700 text-white organic-border group/btn">
                      View Product
                      <ExternalLink className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                    </Button>
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Link to={createPageUrl("WellnessPicks")}>
            <Button variant="outline" className="border-sage-300 text-sage-700 hover:bg-sage-50 px-8 py-3 organic-border">
              View All Products
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
