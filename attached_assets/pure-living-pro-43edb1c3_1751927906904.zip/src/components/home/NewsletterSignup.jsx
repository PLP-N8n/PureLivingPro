import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Mail, Sparkles, Check } from "lucide-react";

export default function NewsletterSignup() {
  const [email, setEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email) return;

    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSubscribed(true);
    setIsLoading(false);
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-sage-50 via-white to-amber-50/30">
      <div className="max-w-4xl mx-auto">
        <Card className="premium-shadow organic-border border-0 bg-white/90 backdrop-blur-sm overflow-hidden">
          <CardContent className="p-0">
            <div className="grid lg:grid-cols-2 gap-0">
              {/* Content */}
              <div className="p-8 lg:p-12 flex flex-col justify-center">
                <div className="flex items-center mb-4">
                  <Sparkles className="w-6 h-6 text-sage-600 mr-2" />
                  <span className="text-sage-600 font-medium uppercase tracking-wider text-sm">
                    Newsletter
                  </span>
                </div>
                
                <h3 className="text-3xl lg:text-4xl font-bold text-sage-700 mb-4">
                  Join Our Wellness Circle
                </h3>
                
                <p className="text-lg text-sage-600 mb-8 leading-relaxed">
                  Get weekly wellness insights, exclusive content, and curated product 
                  recommendations delivered straight to your inbox.
                </p>

                {!isSubscribed ? (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="relative">
                      <Label htmlFor="newsletter-email" className="sr-only">Email address</Label>
                      <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-sage-400" />
                      <Input
                        id="newsletter-email"
                        type="email"
                        placeholder="Enter your email address"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="pl-12 py-6 organic-border border-sage-200 focus:border-sage-400 text-lg"
                        required
                        aria-label="Email address for newsletter"
                      />
                    </div>
                    <Button
                      type="submit"
                      className="w-full bg-sage-600 hover:bg-sage-700 text-white py-6 text-lg organic-border premium-shadow"
                      disabled={isLoading}
                    >
                      {isLoading ? "Subscribing..." : "Subscribe to Wellness Updates"}
                    </Button>
                  </form>
                ) : (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Check className="w-8 h-8 text-green-600" />
                    </div>
                    <h4 className="text-xl font-semibold text-sage-700 mb-2">
                      Welcome to Our Wellness Circle!
                    </h4>
                    <p className="text-sage-600">
                      Thank you for subscribing. You'll receive your first wellness update soon.
                    </p>
                  </div>
                )}

                <p className="text-sm text-sage-500 mt-4">
                  ✨ No spam, just pure wellness wisdom • Unsubscribe anytime
                </p>
              </div>

              {/* Image */}
              <div className="relative h-64 lg:h-auto">
                <img
                  src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                  alt="Person meditating peacefully in a well-lit, minimalist room."
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-sage-600/20 to-transparent"></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}