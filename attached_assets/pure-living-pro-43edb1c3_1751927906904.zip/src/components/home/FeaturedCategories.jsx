
import React from "react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { 
  UtensilsCrossed, // Replaces Apple
  BrainCircuit,   // Replaces Brain
  Dumbbell,
  Soup,            // Replaces ChefHat
  Leaf,            // Replaces Flower2 (for Natural Remedies)
  Sparkle,         // New icon for Skin & Self-care, also can replace Pill and Sparkles if desired, but Sparkles is used in header
  Sparkles,        // Kept for the header icon
  ArrowRight
} from "lucide-react";

// Removed createPageUrl as href is now directly provided in category data

const categories = [
  { 
    name: "Nutrition", 
    description: "Fuel your body right", 
    href: "/Blog?category=nutrition",
    icon: UtensilsCrossed,
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/15947cae7_Nutrition.jpg"
  },
  { 
    name: "Mindfulness", 
    description: "Find your inner peace", 
    href: "/Blog?category=meditation-mindfulness",
    icon: BrainCircuit,
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/932d9f377_MindfulnessMeditation.jpg"
  },
  { 
    name: "Fitness", 
    description: "Move for a better life", 
    href: "/Blog?category=fitness",
    icon: Dumbbell,
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/c6ffd6fcf_Fitness.jpg"
  },
  { 
    name: "Healthy Recipes", 
    description: "Eat well, live well", 
    href: "/Blog?category=healthy-recipes",
    icon: Soup,
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/667b13c29_HealthyRecipies.jpg"
  },
  { 
    name: "Natural Remedies", 
    description: "Nature's healing power", 
    href: "/Blog?category=natural-remedies",
    icon: Leaf,
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/de2b44e2b_NaturalRemidies.jpg"
  },
  { 
    name: "Skin & Self-care", 
    description: "Nourish your outer self", 
    href: "/Blog?category=skin-selfcare",
    icon: Sparkle,
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/32b6690f5_SkinCare.jpg"
  }
];

export default function FeaturedCategories() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-4">
            <Sparkles className="w-6 h-6 text-sage-600 mr-2" />
            <span className="text-sage-600 font-medium uppercase tracking-wider text-sm">
              Wellness Categories
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-sage-700 mb-4">
            Explore Your Wellness Journey
          </h2>
          <p className="text-lg text-sage-600 max-w-2xl mx-auto">
            Dive deep into our comprehensive wellness categories, each crafted to support 
            your unique path to holistic health and mindful living.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category) => (
            <Link 
              key={category.href} // Using href as key since slug is no longer present directly
              to={category.href}
              className="group"
            >
              <Card className="premium-shadow organic-border border-0 bg-white/80 backdrop-blur-sm hover:bg-white transition-all duration-500 group-hover:scale-105 group-hover:premium-shadow overflow-hidden">
                <CardContent className="p-0">
                  {/* Image Header */}
                  <div 
                    className="h-32 relative overflow-hidden bg-cover bg-center"
                    style={{ backgroundImage: `url(${category.image})` }}
                  >
                    <div className="absolute inset-0 bg-black/40"></div> {/* Darker overlay for better icon contrast */}
                    <div className="relative z-10 flex items-center justify-center h-full">
                      <div className="w-16 h-16 bg-white/20 backdrop-blur-sm organic-border flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                        <category.icon className="w-8 h-8 text-white" />
                      </div>
                    </div>
                    {/* Decorative elements */}
                    <div className="absolute top-4 right-4 w-8 h-8 bg-white/10 rounded-full"></div>
                    <div className="absolute bottom-4 left-4 w-4 h-4 bg-white/20 rounded-full"></div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-sage-700 mb-2 group-hover:text-sage-800 transition-colors">
                      {category.name}
                    </h3>
                    <p className="text-sage-600 mb-4 leading-relaxed">
                      {category.description}
                    </p>
                    <div className="flex items-center justify-end"> {/* Removed category.posts, so justify-end for arrow */}
                      {/* Removed: <span className="text-sm text-sage-500 font-medium">{category.posts}</span> */}
                      <div className="w-8 h-8 bg-sage-100 rounded-full flex items-center justify-center group-hover:bg-sage-200 transition-colors">
                        <ArrowRight className="w-4 h-4 text-sage-600 group-hover:translate-x-0.5 transition-transform" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
